%% Computational Illustration for Lectures 05/06:
%  Algorithms producing best approximants in C(K)

clear all; clc;

%% the approximation problem

x = chebfun('x');                % we are using chebfun$
f = (sin (4*x - 1) + x + 1).^5;  % the target function
figure(1)
plot(f,'k-')
n = 10;                          % the degree of the polynomial approximant

%% Via linear programming

N = 20;
t = chebpts(N);
M = zeros(N,n+1);
for j=0:n
   Tj = chebpoly(j);
   M(:,j+1) = Tj(t);
end

cvx_begin quiet
variable v_coeffs(n+1)
variable c
minimize c
subject to 
c + (f(t) - M*v_coeffs) >=0;
c - (f(t) - M*v_coeffs) >=0;
cvx_end
v1 = chebfun(v_coeffs,'coeffs');
hold on; plot(v1,'g-')

%% Via Remez algorithm (implemented in chebfun)

v2 = remez(f,n)
hold on; plot(v2,'r-')
figure(2); plot(f-v1,'g-');
hold on; plot(f-v2,'r-')

%% Via semidefinite programming

N = length(f)-1;
f_coeffs = chebcoeffs(f);
cvx_begin quiet
variable v_coeffs(n+1)
variable d
variable Qp(N+1,N+1) semidefinite
variable Qm(N+1,N+1) semidefinite
minimize d
subject to
sum(diag(Qp)) == d + (f_coeffs(1)-v_coeffs(1));
sum(diag(Qm)) == d - (f_coeffs(1)-v_coeffs(1));
for l=1:n
    sum(diag(Qp,l)) == + (f_coeffs(l+1)-v_coeffs(l+1))/2;
    sum(diag(Qm,l)) == - (f_coeffs(l+1)-v_coeffs(l+1))/2;
end
for l=n+1:N
    sum(diag(Qp,l)) == + f_coeffs(l+1)/2;
    sum(diag(Qm,l)) == - f_coeffs(l+1)/2;   
end
cvx_end
v3 = chebfun(v_coeffs,'coeffs');
plot(f-v3,'b-')
