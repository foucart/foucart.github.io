%%
% Given positive integers d and n, find all multidegrees 
% in d variables with total degree at most n

% Inputs:
% d: positive integer (the number of variables)
% n: nonnegative integer 

% Outputs:
% multidegs: a d x nchoose(d+n,d) matrix whose columns are
%     the all d-tuples (k_1,...k_d) of integers
%     with that k_1,...,k_d >= 0 and k_1 +...+ k_d <= n

% Written in October 2024
% Send comments to simon.foucart@centraliens.net

%%
function multidegs = all_degrees(d,n)

if d == 1
    multidegs = 0:n;
else
    multidegs = [];
    for k = 0:n
        aux1 = all_degrees(d-1,n-k);
        aux2 = [k*ones(1,size(aux1,2)); aux1];
        multidegs = [multidegs aux2];
    end
end

end