%%
% Given a monomial m_k of total degree |k|=n 
% and a signature (split into positive and negative parts),
% compute a lower bound for the error of best approximation to m_k 
% by polynomials of total degree <n  
%
% This is done by solving the linear program
%
% maximize_{c_p>=0,c_m>=0} <d_p,c_p> - <d_m,c_m>
% s.to:  M_p c_p - M_m c_m == 0, <1,c_p> + <1,c_m> == 0
%
% where c_p, c_m contain m_k evaluated at the signature points
% and M_p, M_m contain lower-degree monomials evaluated at these points

% Note: to be executed, lower_bound requires CVX 

% Inputs:
% k = (k_1,...,k_d): the multidegree of the monomial
% signature_p: points making the positive parts of the signature
% signature_m: points making the negative parts of the signature
% solver (optional): 'MATLAB' to solve the linear program in MATLAB (default)
%                    'USECVX' to use CVX instead

% Outputs:
% lb: the optimal value of the linear program

% Written in October 2024
% Send comments to simon.foucart@centraliens.net

function lb = lower_bound(k,signature_p,signature_m,solver)

if nargin < 4
    solver = 'USECVX';
end

%% preparation
n = sum(k);
d = length(k);
s_p = size(signature_p,2);
s_m = size(signature_m,2);

%% creating of the vectors d_p and d_m for the objective function
d_p = zeros(s_p,1);
for j=1:s_p
    res = 1;
    for l=1:d
        res = res * signature_p(l,j)^k(l);
    end
    d_p(j) = res;
end
d_m = zeros(s_m,1);
for j=1:s_m
    res = 1;
    for l=1:d
        res = res * signature_m(l,j)^k(l);
    end
    d_m(j) = res;
end

%% creating of the matrices M_p and M_p for the constraints
multidegs = all_degrees(d,n-1);
dim = size(multidegs,2);
M_p = zeros(dim,s_p);
for i=1:dim
    monomial = multidegs(:,i);
    for j=1:s_p
        res = 1;
        for l=1:d
            res = res * signature_p(l,j)^monomial(l);
        end
        M_p(i,j) = res;
    end
end
M_m = zeros(dim,s_m);
for i=1:dim
    monomial = multidegs(:,i);
    for j=1:s_m
        res = 1;
        for l=1:d
            res = res * signature_m(l,j)^monomial(l);
        end
        M_m(i,j) = res;
    end
end

%% solving the optimization program

if solver == 'USECVX'
    cvx_begin 
    variable c_p(s_p) nonnegative
    variable c_m(s_m) nonnegative
    maximize sum(d_p.*c_p) - sum(d_m.*c_m) 
    subject to
    M_p*c_p - M_m*c_m == 0;
    sum(c_p) + sum(c_m) == 1;
    cvx_end
    %return the outputs
    lb = cvx_optval;
end

if solver == 'MATLAB'
    options = optimoptions('linprog','Algorithm','interior-point');
    problem = optimproblem;
    c_p = optimvar('c_p',s_p,1);
    c_m = optimvar('c_m',s_m,1);
    problem.Objective = -sum(d_p.*c_p) + sum(d_m.*c_m);
    problem.Constraints.Con1 = c_p >= 0;
    problem.Constraints.Con2 = c_m >= 0;
    problem.Constraints.Con3 = M_p*c_p - M_m*c_m == 0;
    problem.Constraints.Con4 = sum(c_p) + sum(c_m) == 1;
    [~, optval] = solve(problem, 'Solver', 'linprog', 'Options', options); 
    % return the outputs
    lb = -optval;
end

end