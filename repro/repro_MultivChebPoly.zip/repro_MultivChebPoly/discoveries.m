%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Reproducible MATLAB file accompanying the paper
%        OPTIMIZATION-AIDED CONSTRUCTION OF
%        MULTIVARIATE CHEBYSHEV POLYNOMIALS          
% by M. Dressler, S. Foucart, E, de Klerk, M. Joldes, 
%    J. B. Lasserre, and Y. Xu
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Here, one exploits ChebPoly_dual and ChebPoly_dual
% to discover Chebyshev polynomials for d=3 and n<=6
% CVX is needed for the "validation via lower bound"
% Written in May 2024, updated in October 2024
% Send comments to simon.foucart@centraliens.net

format long

%% %%%%%%%%%%%%%%%%%%%%%%%
%  THE 3D-EUCLIDEAN BALL %
% %%%%%%%%%%%%%%%%%%%%%%%%

%% Case 1: k=(2,2,1)
% note this case is solved explicitly in the paper
Omega = 'B';
k = [2,2,1];
t = 6;
err_primal = ChebPoly_primal(k,Omega,t);
[err_dual,signature_p,signature_m] = ChebPoly_dual(k,Omega,t);
[err_primal err_dual]
% these values are equal and the latter is certified by GloptiPoly:
% the error of best approximation to x1^2*x2^2*x3 
% by polynomials of degree <5 on the ball is 0.0363000
%% validation via a lower bound, too
lb = lower_bound(k,signature_p,signature_m)

%% notice that the signature lies on the sphere x^2+y^2+z^2=1
sum(signature_m.^2)
sum(signature_p.^2)


%% Case 2: k=(4,1,1)
Omega = 'B';
k = [4,1,1];
t = 6;
err_primal = ChebPoly_primal(k,Omega,t);
[err_dual,signature_p,signature_m] = ChebPoly_dual(k,Omega,t);
[err_primal err_dual]
% these values are equal and the latter is certified by GloptiPoly:
% the error of best approximation to x1^4*x2*x3 
% by polynomials of degree <6 on the ball is 0.0192378
%% validation via a lower bound, too
lb = lower_bound(k,signature_p,signature_m)

%% notice that the signature lies on the sphere x^2+y^2+z^2=1
sum(signature_m.^2)
sum(signature_p.^2)


%% Case 3: k=(3,2,1)
Omega = 'B';
k = [3,2,1];
t = 6;
err_primal = ChebPoly_primal(k,Omega,t);
[err_dual,signature_p,signature_m] = ChebPoly_dual(k,Omega,t);
[err_primal err_dual]
% these values are equal and the latter is certified by GloptiPoly:
% the error of best approximation to x1^3*x2^2*x3 
% by polynomials of degree <5 on the ball is 0.0165297
%% validation via a lower bound, too
lb = lower_bound(k,signature_m,signature_p)

%% in this case, we notice that the signature lies on the sphere x^2+y^2+z^2=1
sum(signature_m.^2)
sum(signature_p.^2)



%% %%%%%%%%%%%%%%%%%%%%%%
% THE 3D-CROSS-POLYTOPE %
% %%%%%%%%%%%%%%%%%%%%%%%

%% Case 1: k=(1,1,1)
Omega = 'C';
k = [1,1,1];
t = 8;
err_primal = ChebPoly_primal(k,Omega,t);
[err_dual,signature_p,signature_m] = ChebPoly_dual(k,Omega,t);
[err_primal err_dual]
% these values are equal and the latter is certified by GloptiPoly:
% the error of best approximation to x1*x2*x3 
% by polynomials of degree <3 on the cross-polytope is 0.037037
%% validation via a lower bound, too
lb = lower_bound(k,signature_p,signature_m)

%% notice that the signature lies on the L1-sphere |x|+|y|+|z|=1
sum(abs(signature_m))
sum(abs(signature_p))


%% Case 2: k=(2,1,1)
Omega = 'C';
k = [2,1,1];
t = 9;
err_primal = ChebPoly_primal(k,Omega,t);
[err_dual,signature_p,signature_m] = ChebPoly_dual(k,Omega,t);
[err_primal err_dual]
% these values are equal and the latter is certified by GloptiPoly:
% the error of best approximation to x1^2*x2*x3 
% by polynomials of degree <4 on the cross-polytope is 0.012736
%% validation via a lower bound, too
lb = lower_bound(k,signature_p,signature_m)

%% notice that the signature lies on the L1-sphere |x|+|y|+|z|=1
sum(abs(signature_m))
sum(abs(signature_p))


%% Case 3: k=(3,1,1)
Omega = 'C';
k = [3,1,1];
t = 12;
err_primal = ChebPoly_primal(k,Omega,t);
[err_dual,signature_p,signature_m] = ChebPoly_dual(k,Omega,t);
[err_primal err_dual]
% these values are equal and the latter is certified by GloptiPoly: 
% the error of best approximation to x1^3*x2*x3 
% by polynomials of degree <5 on the cross-polytope is 4.7644e-3
%% validation via a lower bound, too
lb = lower_bound(k,signature_p,signature_m)

%% notice that the signature lies on the L1-sphere |x|+|y|+|z|=1
sum(abs(signature_m))
sum(abs(signature_p))


%% Case 4: k=(2,2,1)
Omega = 'C';
k = [2,2,1];
t = 11;
err_primal = ChebPoly_primal(k,Omega,t);
[err_dual,signature_p,signature_m] = ChebPoly_dual(k,Omega,t);
[err_primal err_dual]
% these values are "about" equal, the latter being certified by GloptiPoly:
% the error of best approximatio to x1^2*x2^2*x3 
% by polynomials of degree <5 on the cross-polytope is 0.003398
%% validation via a lower bound, too
lb = lower_bound(k,signature_p,signature_m)

%% notice that the signature lies on the L1-sphere |x|+|y|+|z|=1
sum(abs(signature_m))
sum(abs(signature_p))


%% Case 5: k=(4,1,1)
Omega = 'C';
k = [4,1,1];
t = 10;
err_primal = ChebPoly_primal(k,Omega,t);
[err_dual,signature_p,signature_m] = ChebPoly_dual(k,Omega,t);
[err_primal err_dual]
% these values are "about" equal---the latter is not certified by GloptiPoly
% it is still thought that the error of best approximation to x1^4*x2*x3 
% by polynomials of degree <6 on the cross-polytope is 1.853e-3 
%% note: the signature could not be extracted (so no lower bound)


%% Case 6: k=(3,2,1)
Omega = 'C';
k = [3,2,1];
t = 11;
err_primal = ChebPoly_primal(k,Omega,t);
[err_dual,signature_p,signature_m] = ChebPoly_dual(k,Omega,t);
[err_primal err_dual]
% these values are equal and the latter is certified by GloptiPoly:
% the error of best approximation to x1^3*x2^2*x3 
% by polynomials of degree <6 on the cross-polytope is "about" 1.087e-3
%% validation via a lower bound, too
lb = lower_bound(k,signature_p,signature_m)

%% the signature may not lie on the L1-sphere |x|+|y|+|z|=1 ...
sum(abs(signature_m))
sum(abs(signature_p))

%% Case 7: k=(2,2,2)
Omega = 'C';
k = [2,2,2];
t = 14;
err_primal = ChebPoly_primal(k,Omega,t);
[err_dual,signature_p,signature_m] = ChebPoly_dual(k,Omega,t);
[err_primal err_dual]
% these values are "about" equal---the latter is not certified by GloptiPoly
% it is still thought that the error of best approximation to x1^2*x2^2*x3^2 
% by polynomials of degree <6 on the cross-polytope is about 0.661e-4
%% note: the signature could not be extracted...


%% %%%%%%%%%%%%%%%
% THE 3D-SIMPLEX %
% %%%%%%%%%%%%%%%%

%% Case 1: k=(2,1,1)
% note this case is solved explicitly in the paper
Omega = 'S';
k = [2,1,1];
t = 8;
err_primal = ChebPoly_primal(k,Omega,t);
[err_dual,signature_p,signature_m] = ChebPoly_dual(k,Omega,t);
[err_primal err_dual]
% these values are equal and the latter is certified by GloptiPoly:
% the error of best approximation to x1^2*x2*x3 
% by polynomials of degree <4 on the simplex is 0.0026885
%% validation via a lower bound, too
lb = lower_bound(k,signature_p,signature_m)

%% notice that the signature lies on the face x+y+z=1
sum(signature_m)
sum(signature_p)

%% Case 2: k=(3,1,1)
Omega = 'S';
k = [3,1,1];
t = 12;
err_primal = ChebPoly_primal(k,Omega,t);
[err_dual,signature_p,signature_m] = ChebPoly_dual(k,Omega,t);
[err_primal err_dual]
% these values are "about" equal---the latter is not certified by GloptiPoly
% it is still thought that the error of best approximation to x1^3*x2*x3 
% by polynomials of degree <5 on the simplex is about 5.984e-4
%% note: the signature could not be extracted...

%% Case 3: k=(2,2,1)
Omega = 'S';
k = [2,2,1];
t = 10;
err_primal = ChebPoly_primal(k,Omega,t);
[err_dual,signature_p,signature_m] = ChebPoly_dual(k,Omega,t);
[err_primal err_dual]
% these values are "about" equal---the latter is not certified by GloptiPoly
% it is still thought the error of best approximation to x1^2*x2^2*x3 
% by polynomials of degree <5 on the simplex is 4.695e-4
%% however, this value is certified by GloptiPoly using a lower t
t = 6;
[err_dual,signature_p,signature_m] = ChebPoly_dual(k,Omega,t);
err_dual
%% but then the extracted signature is not reliable,
% since a lower bound is larger than the upper bound...
lb = lower_bound(k,signature_p,signature_m)
%% using MATLAB's optimization tool, it is infeasible
lb = lower_bound(k,signature_p,signature_m,'MATLAB')

%% notice that the signature lies on the face x+y+z=1
sum(signature_m)
sum(signature_p)

%% Case 4: k=(4,1,1)
Omega = 'S';
k = [4,1,1];
t = 10;
err_primal = ChebPoly_primal(k,Omega,t);
[err_dual,signature_p,signature_m] = ChebPoly_dual(k,Omega,t);
[err_dual err_primal]
% these values are "about" equal---the latter is not certified by GloptiPoly
% it is still thought that the error of best approximation to x1^4*x2*x3 
% by polynomials of degree <6 on the simplex is 1.405e-4 
%% note: the signature could not be extracted...

%% Case 5: k=(3,2,1)
Omega = 'S';
k = [3,2,1];
t = 10;
err_primal = ChebPoly_primal(k,Omega,t);
[err_dual,signature_p,signature_m] = ChebPoly_dual(k,Omega,t);
[err_dual err_primal]
% these values are "about" equal---the latter is not certified by GloptiPoly
% it is still thought that the error of best approximation to x1^3*x2^2*x3 
% by polynomials of degree <6 on the simplex is between 1.0008e-4
%% note: the signature could not be extracted...
