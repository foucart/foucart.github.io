% L1SQNNREG L1-squared nonnegative regularization
% l1sqnnreg(y,A,lambda) finds the solution of
% minimize ||z||_1^2+lambda^2*||Az-y||_2^2 subject to z >= 0
% Usage: [x,Normx,NormRes,NbOuterIter] = l1sqnnreg(y,A,lambda)
% y: column vector, A: matrix, lambda: (large) positive number
% x: column vector (solution of the regularization)
% Normx: the L1-norm of x (i.e., ||x||_1)
% NormRes: the L2-norm of the residual (i.e., ||Ax-y||_2)
% NbOuterIter: number of iterations (not including the inner loop)
% SF (created 23 Aug 2013, modified 29 August 2013)

function [x,Normx,NormRes,NbOuterIter] = l1sqnnreg(y,A,lambda)

[~,N]=size(A);
Aaux=[ones(1,N);lambda*A];
yaux=[0;lambda*y];
[x,~,~,~,output]=lsqnonneg(Aaux,yaux);
Normx=sum(x);
NormRes=norm(A*x-y);
NbOuterIter=output.iterations;

end