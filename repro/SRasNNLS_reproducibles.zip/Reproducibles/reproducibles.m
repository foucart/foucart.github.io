%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This file contains the reproducible experiments mentioned in the article
% "Sparse Recovery by means of Nonnegative Least Squares"
% by S. Foucart and D. Koslicki
% Created 10 Sept 2013
% Last modified 11 Sept 2013
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Each experiment contains a number of sub-experiments. For the longer
% computations, if you wish to simply view the precomputed results 
% (instead of performing the computations locally), scroll down to the 
% "visualization" sections and evaluate the appropriate cells.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%% EXPERIMENT 1: Compare the performances of nonnegative sparse recovery
%  with adjacency matrices of ramdom left-regular bipartite graphs
%  for OMP and for NNLS 

%% Exp1.a: produce the data and save them into Exp1.mat
%  this took about (1h45min) on a 3.6 GHz Intel Core i5 8 GB 1333 MHz DDR3 iMac

clear all; clc;

% size the (normalized) adjacency matrix of a left-regular bipartite graph 
N=1000; %number of left vertices 
m=300;  %number of right vertices
d=12;   %value of the left degree 

% range of sparsities
smin=75; smax=115;

% number of random matrices to generate
NbMatTests=25; 
% number of random vectors to generate
NbVecTests=4;
% total number of tests performed
NbTests=NbMatTests*NbVecTests;

% variables to contain the experiment results
NbSucOMP=zeros(smax-smin+1,1);
NbSucNNLS=zeros(smax-smin+1,1);
NbIterOMP=zeros(smax-smin+1,1);
NbIterNNLS=zeros(smax-smin+1,1);
timeOMP=zeros(smax-smin+1,1);
timeNNLS=zeros(smax-smin+1,1);
% no consclusion is drawn from the comparison of execution times

for s=smin:smax
    %for each sparsity value
    fprintf('sparsity: %d\n',s)

for k=1:NbMatTests
    %for NbMatTests different measurement matrices
    
    %construction of the matrix
    A=zeros(m,N);
    for j=1:N
        neighbors_j=sort(randsample(m,d));
        A(neighbors_j,j)=ones(d,1)/d;
    end
    
    for L=1:NbVecTests
        %for NbVecTests different vectors with the given measurement matrix
        %construction of the sparse nonnegative vector x and its measurement vector y
        supp=sort(randsample(N,s));                   %support of x
        x=zeros(N,1); x(supp)=rand(s,1); x=x/sum(x);  %x is L1-normalized
        y=A*x;                                        %measurement vector
        %reconstruction by OMP
         tic;
         [xOMP,~,~,nOMP]=omp(y,A);
         t=toc;
         timeOMP(s-smin+1)=timeOMP(s-smin+1)+t;
         if norm(x-xOMP,1)<1e-2
             NbSucOMP(s-smin+1)=NbSucOMP(s-smin+1)+1;
             NbIterOMP(s-smin+1)=NbIterOMP(s-smin+1)+nOMP;
         end
        %reconstruction by NNLS
         lambda=500;             %arbitrary choice for the regularization parameter
         tic;
         [xNNLS,~,~,nNNLS]=l1sqnnreg(y,A,lambda);
         t=toc;
         timeNNLS(s-smin+1)=timeNNLS(s-smin+1)+t;
         if norm(x-xNNLS,1)<1e-2
             NbSucNNLS(s-smin+1)=NbSucNNLS(s-smin+1)+1;
             NbIterNNLS(s-smin+1)=NbIterNNLS(s-smin+1)+nNNLS;
         end
    end
    
end

end

save('Exp1.mat')

%% Exp1.b: Visualisation of the results

try load('Exp1.mat')
catch
    load('Exp1_default.mat')
end

% Figure 1: succesfull recoveries
FreqSucOMP=NbSucOMP/(NbTests)*100;
FreqSucNNLS=NbSucNNLS/(NbTests)*100;
figure(1)
plot(smin:smax,FreqSucOMP, 'b-',...
    smin:smax,FreqSucNNLS, 'r.-')
legend('OMP','NNLS')
xlabel('Sparsity')
ylabel('Percentage of successful recoveries')
title('Nonnegative recovery - Adjacency matrices')

% Figure 2: number of iterations
% consider only the range where 50% recovery is guarantees for both OMP and NNLS 
range=find( (FreqSucOMP>50).*(FreqSucNNLS>50) ); 
figure(2)
plot(smin-1+range,NbIterOMP(range)./NbSucOMP(range),'b-',...
    smin-1+range,NbIterNNLS(range)./NbSucNNLS(range),'r.-')
legend('OMP','NNLS')
xlabel('Sparsity')
ylabel('Average number of iterations')
title('Nonnegative recovery - Adjacency matrices')


%% EXPERIMENT 2: a k-mer frequency matrix with k=4
%  it shows that nonnegative recovery via NNBP succeeds on some index set
%  while arbitrarily signed recovery via BP fails on this index set 

% load the k-mer matrix
clear all; clc; 
Matrix=load('NormalizedFourMersMatrix.mat');
A=Matrix.A;
[m,N]=size(A);

% select a fixed support
S=load('S.mat');
S=S.S;
s=length(S);

%% Exp2.a: verify that all nonnegative vectors supported on S are recovered by NNBP
%  by verifying condition (F') using CVX (CVX needs to be installed on your computer)
%  the result of the minimization should be positive

w=0.001*rand(1,N);
Sbar=setdiff(1:N,S);
    cvx_begin
    variable v(N);
    minimize( max(v(Sbar)) )
    subject to
    A*v==0;
    w*v==1;
cvx_end

%% Exp2.b: verify that some vectors supported on S are not recovered by BP
%  although redundant with Exp2.a, verify that the nonnegative vectors
%  supported on S are recovered by NNBP

NbTests=100;
BPErrors=zeros(1,NbTests);
NNBPErrors=zeros(1,NbTests);
sprintf('\n')
for i=1:NbTests

% define an arbirtarily signed vector with support S
x=zeros(N,1); x(S)=randn(s,1); x=x/norm(x,1);
% define a nonnegative vector with this support
xplus=zeros(N,1); xplus(S)=rand(s,1); xplus=xplus/sum(xplus);
% define the measurement vectors
y=A*x;
yplus=A*xplus;

if mod(i,10)==0
    fprintf('Test number: %d\n',i)
end

% BP
cvx_begin quiet
variable xsharp(N);
minimize( norm(xsharp,1) )
subject to
A*xsharp==y;
cvx_end
BPErrors(i)=norm(x-xsharp,1);
% NNBP
cvx_begin quiet
variable xplussharp(N);
minimize( norm(xplussharp,1) )
subject to
A*xplussharp==yplus;
xplussharp>=0;
cvx_end
NNBPErrors(i)=norm(xplus-xplussharp,1);
end

% visualization of the results
figure(3)
plot(1:length(BPErrors),BPErrors,1:length(NNBPErrors),NNBPErrors)
xlabel('Test number')
ylabel('L1-error')
legend('BP',sprintf('NNBP\nFraction of BP failed: %1.3f', length(find(BPErrors>0.01))/NbTests))


%% EXPERIMENT 3: Test the L1-squared nonnegative regularization
%  with the adjacency matrices of a left-regular bipartite graph
%  focus on how the reconstruction error and the execution time depend
%  on the parameter lambda
%  compare with the nonnegative basis pursuit denoising of YALL1

clear all; clc;

% construction of a measurement matrix
N=1000; %number of left vertices 
m=300;  %number of right vertices
d=12;   %value of the left degree 
A=zeros(m,N);
for j=1:N
    neighbors_j=sort(randsample(m,d));
    A(neighbors_j,j)=ones(d,1)/d;
end

%% Exp3.a: small sparsity - L1-squared nonnegative regularization has an edge

s=50; supp=sort(randsample(N,s)); %the support of a sparse vector
x=zeros(N,1); x(supp)=rand(s,1);  %the nonnegative sparse vector
y=A*x;                            %the measurement vector

% reconstruction using YALL1 
opts.tol = 1e-4; opts.rho= 1e-5; opts.nonneg=1;
tic; xyall = yall1(A, y, opts); tyall=toc;

% reconstruction using lsqnnreg for different values of lambda
Lambda=1000:200:5000;
Error=zeros(1,length(Lambda));
Time=zeros(1,length(Lambda));
for k=1:length(Lambda)
    tic; xl1sq=l1sqnnreg(y,A,Lambda(k)); t=toc;
    Error(k)=norm(x-xl1sq,1);
    Time(k)=t;
end

% visualization of the results
figure(4)
plot(Lambda,Error,Lambda,norm(x-xyall,1)*ones(1,length(Lambda)));
legend('L1-error for NNREG', 'L1-error for BPD')
title('L1-error as a function of lambda')
xlabel('lambda')
ylabel('Error')
figure(5)
plot(Lambda,Time,Lambda,tyall*ones(1,length(Lambda)));
legend('Execution time for NNREG', 'Execution time for BPD')
title('Execution time as a function of lambda')
xlabel('lambda')
ylabel('Seconds')

%% Exp3.b: larger sparsity - L1-squared nonnegative regularization loses its edge
% For larger sparsities, there is a sharp transition between a 
% relatively fast execution for small values of lambda and a much longer 
% execution for larger values of lambda.
% The test may need to be run several times to see this occur

s=120; supp=sort(randsample(N,s)); %the support of a sparse vector
x=zeros(N,1); x(supp)=rand(s,1);   %the nonnegative sparse vector
y=A*x;                             %the measurement vector

% reconstruction using YALL1 
opts.tol = 1e-4; opts.rho= 1e-5; opts.nonneg=1;
tic; xyall = yall1(A, y, opts); tyall=toc;

% reconstruction using lsqnnreg for different values of lambda
Lambda=1000:200:5000;
Error=zeros(1,length(Lambda));
Time=zeros(1,length(Lambda));
for k=1:length(Lambda)
    tic; xl1sq=l1sqnnreg(y,A,Lambda(k)); t=toc;
    Error(k)=norm(x-xl1sq,1);
    Time(k)=t;
end

% visualization of the results
figure(6)
plot(Lambda,Error,Lambda,norm(x-xyall,1)*ones(1,length(Lambda)));
legend('L1-error for NNREG', 'L1-error for BPD')
title('L1-error as a function of lambda')
xlabel('lambda')
ylabel('Error')
figure(7)
plot(Lambda,Time,Lambda,tyall*ones(1,length(Lambda)));
legend('Execution time for NNREG', 'Execution time for BPD')
title('Execution time as a function of lambda')
xlabel('lambda')
ylabel('Seconds')

%% Exp3.c: L1-squared nonnegative regularization with noise
%  with noise added, the execution alternates between fast to slow rather erratically

s=120; supp=sort(randsample(N,s)); %the support of a sparse vector
x=zeros(N,1); x(supp)=rand(s,1);   %the nonnegative sparse vector
y=A*x+1e-5*randn(m,1);             %the measurement vector

% reconstruction using YALL1 
opts.tol = 1e-4; opts.rho= 1e-5; opts.nonneg=1;
tic; xyall = yall1(A, y, opts); tyall=toc;

% reconstruction using lsqnnreg for different values of lambda
Lambda=1000:200:5000;
Error=zeros(1,length(Lambda));
Time=zeros(1,length(Lambda));
for k=1:length(Lambda)
    tic; xl1sq=l1sqnnreg(y,A,Lambda(k)); t=toc;
    Error(k)=norm(x-xl1sq,1);
    Time(k)=t;
end

% visualization of the results
figure(8)
plot(Lambda,Error,Lambda,norm(x-xyall,1)*ones(1,length(Lambda)));
legend('L1-error for NNREG', 'L1-error for BPD')
title('L1-error as a function of lambda')
xlabel('lambda')
ylabel('Error')
figure(9)
plot(Lambda,Time,Lambda,tyall*ones(1,length(Lambda)));
legend('Execution time for NNREG', 'Execution time for BPD')
title('Execution time as a function of lambda')
xlabel('lambda')
ylabel('Seconds')

%% EXPERIMENT 4: Test the L1-squared nonnegative regularization 
%  with a k-mer frequency matrix with k=5
%  focus on how (|x^lambda|_1-|x^sharp|_1) / |x^sharp|_1 depends on lambda
%  the numbers of iterations are also recorded

%% Exp4.a: in the noiseless case, the behavior of (|x^lambda|_1-|x^sharp|_1) / |x^sharp|_1 
% as constant/lambda^2 provided by the lower bound in Eq.(3) seems to be the correct one

clear all; clc; 
Matrix=load('NormalizedFiveMersMatrix.mat');
A=Matrix.A;
[m,N]=size(A);

% construct a sparse nonnegative vector and its measurement vector
s=50; supp=sort(randsample(N,s)); %the support of the vector
x=zeros(N,1); x(supp)=rand(s,1);  %the nonnegative sparse vector
y=A*x;                            %the measurement vector

% solve the nonnegative basis pursuit denoising using YALL1 to get x^sharp  
clear opts; opts.tol = 1e-12; opts.nonneg=1;
xyall = yall1(A, y, opts);

% solve the L1-squared nonnegative regularization to get x^lambda
lambdamin=500; lambdamax=1500; lambdastep=10;
Lambda=lambdamin:lambdastep:lambdamax;
RelError=zeros(1,length(Lambda));
NbIterL1sq=zeros(1,length(Lambda));
for k=1:length(Lambda)
    [xl1sq,~,~,nL1sq]=l1sqnnreg(y,A,Lambda(k)); 
    RelError(k)=1-norm(xl1sq,1)/norm(xyall,1);
    NbIterL1sq(k)=nL1sq;
end

% visualization of the results
figure(10)
coefs=polyfit(log(Lambda),log(RelError),1);
plot(log(Lambda),log(RelError))
legend(strcat({'The slope of the line is '},num2str(coefs(1))))
xlabel('Log of lambda')
ylabel('Log of the relative error')
title('Relative L1-error vs lambda - l1sqnnreg and k-mer frequency matrix')
% this support the behavior of the type Relative error = constant/lambda^2
figure(11)
plot(Lambda,NbIterL1sq)
xlabel('Lambda')
ylabel('Number of iterations')
title('Iterations vs lambda - l1sqnnreg and k-mer frequency matrix')
% the number of iterations does not change much with lambda

%% Exp4.b: in the noisy case, the behavior in 1/lambda^2 is not clear-cut anymore

y=A*x+1e-5*randn(m,1);  %add noise to the measurement vector

% solve the nonnegative basis pursuit denoising using YALL1 to get x^sharp  
clear opts; opts.tol = 1e-12; opts.nonneg=1;
xyall = yall1(A, y, opts);

% solve the L1-squared nonnegative regularization to get x^lambda
lambdamin=500; lambdamax=1500; lambdastep=10;
Lambda=lambdamin:lambdastep:lambdamax;
RelError=zeros(1,length(Lambda));
NbIterL1sq=zeros(1,length(Lambda));
for k=1:length(Lambda)
    [xl1sq,~,~,nL1sq]=l1sqnnreg(y,A,Lambda(k)); 
    RelError(k)=1-norm(xl1sq,1)/norm(xyall,1);
    NbIterL1sq(k)=nL1sq;
end

% visualization of the results
figure(12)
coefs=polyfit(log(Lambda),log(RelError),1);
plot(log(Lambda),log(RelError))
legend(strcat({'If this is a line, its slope is '},num2str(coefs(1))))
xlabel('Log of lambda')
ylabel('Log of the relative error')
title('Relative L1-error vs lambda - l1sqnnreg, k-mer frequency matrix, and noise')
figure(13)
plot(Lambda,NbIterL1sq)
xlabel('Lambda')
ylabel('Number of iterations')
title('Iterations vs lambda - l1sqnnreg, k-mer frequency matrix, and noise')


%% EXPERIMENT 5: Tests for the L1-squared regularization 
%  with Gaussian matrices
%  focus on how |x^lambda -x|_1 depends on lambda

%% Exp5.a: produce the data and save them to Exp5.mat
%  this took about 50min on a 3.6 GHz Intel Core i5 8 GB 1333 MHz DDR3 iMac

clear all; clc;
N=1000; m=300;

NbTests=10; %number of different matrices to test
for i=1:NbTests
    A=randn(m,N)/sqrt(m);
    lambdamin=500; lambdamax=1000; lambdastep=10;
    Lambda=lambdamin:lambdastep:lambdamax;
    
    s=30;  %a set of tests for a sparsity equal to 30
    supp30=sort(randsample(N,s)); x30=zeros(N,1); x30(supp30)=randn(s,1);
    y30=A*x30;
    Error30(i,:)=zeros(1,length(Lambda));
    NbIter30(i,:)=zeros(1,length(Lambda));
    Time30(i,:)=zeros(1,length(Lambda));
    for j=1:length(Lambda)
        tic; [xlambda,~,~,nlambda]=l1sqreg(y30,A,Lambda(j)); t=toc;
        Error30(i,j)=norm(x30-xlambda,1);
        NbIter30(i,j)=NbIter30(i,j)+nlambda;
        Time30(i,j)=Time30(i,j)+t;
    end
    
    s=40;  %a set of tests for a sparsity equal to 40
    supp40=sort(randsample(N,s)); x40=zeros(N,1); x40(supp40)=randn(s,1);
    y40=A*x40;
    Error40(i,:)=zeros(1,length(Lambda));
    NbIter40(i,:)=zeros(1,length(Lambda));
    Time40(i,:)=zeros(1,length(Lambda));
    for j=1:length(Lambda)
        tic; [xlambda,~,~,nlambda]=l1sqreg(y40,A,Lambda(j)); t=toc;
        Error40(i,j)=norm(x40-xlambda,1);
        NbIter40(i,j)=NbIter40(i,j)+nlambda;
        Time40(i,j)=Time40(i,j)+t;
    end
    
    s=50;  %a set of tests for a sparsity equal to 50
    supp50=sort(randsample(N,s)); x50=zeros(N,1); x50(supp50)=randn(s,1);
    y50=A*x50;
    Error50(i,:)=zeros(1,length(Lambda));
    NbIter50(i,:)=zeros(1,length(Lambda));
    Time50(i,:)=zeros(1,length(Lambda));
    for j=1:length(Lambda)
        tic; [xlambda,~,~,nlambda]=l1sqreg(y50,A,Lambda(j)); t=toc;
        Error50(i,j)=norm(x50-xlambda,1);
        NbIter50(i,j)=NbIter50(i,j)+nlambda;
        Time50(i,j)=Time50(i,j)+t;
    end
    
end

save('Exp5.mat')

%% Exp5.b: visualization of the result for a single example with sparsity 30

try load('Exp5.mat')
catch
    load('Exp5_default.mat')
end

figure(14)
AX=plotyy(Lambda,NbIter30(1,:),Lambda,Error50(1,:));
title('Number of iterations and error as a function of lambda')
set(get(AX(1),'Ylabel'),'String','Number of iterations') 
set(get(AX(2),'Ylabel'),'String','L1-error')
xlabel('lambda')

%% Exp5.c: verification that the error behaves in 1/lambda^2

%  produce the quadratic polynomial interpolating the data for s=30
for i=1:NbTests
    InterpCoef30(i,:)=polyfit(log(Lambda),log(Error30(i,:)),2);  
end
sprintf('For s=30, \n the maximum absolute quadratic coefficient is small (%2.4d) \n and the linear coefficient varies varies between %2.4d and %2.4d', max(abs(InterpCoef30(:,1))), min(InterpCoef30(:,2)), max(InterpCoef30(:,2)))

%  produce the quadratic polynomial interpolating the data for s=40
for i=1:NbTests
    InterpCoef40(i,:)=polyfit(log(Lambda),log(Error40(i,:)),2);  
end
sprintf('For s=40, \n the maximum absolute quadratic coefficient is small (%2.4d) \n and the linear coefficient varies varies between %2.4d and %2.4d', max(abs(InterpCoef40(:,1))), min(InterpCoef40(:,2)), max(InterpCoef40(:,2)))

%  produce the quadratic polynomial interpolating the data for s=50
for i=1:NbTests
    InterpCoef50(i,:)=polyfit(log(Lambda),log(Error50(i,:)),2);  
end
sprintf('For s=50, \n the maximum absolute quadratic coefficient is small (%2.4d) \n and the linear coefficient varies varies between %2.4d and %2.4d', max(abs(InterpCoef50(:,1))), min(InterpCoef50(:,2)), max(InterpCoef50(:,2)))

%%


