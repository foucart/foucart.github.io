% L1SQREG L1-squared regularization
% l1sqreg(y,A,lambda) finds the solution of
% minimize ||z||_1^2+lambda^2*||Az-y||_2^2
% Usage: [x,Normx,NormRes,NbOuterIter] = l1sqreg(y,A,lambda)
% y: column vector, A: matrix, lambda: (large) positive number
% x: column vector (solution  of the regularization), 
% Normx: the L1-norm of x (i.e., ||x||_1)
% NormRes: the L2-norm of the residual (i.e., ||Ax-y||_2)
% NbOuterIter: number of iterations (not including the inner loop)
% SF (created 23 Aug 2013, modified 29 August 2013)

function [x,Normx,NormRes,NbOuterIter] = l1sqreg(y,A,lambda)

[~,N]=size(A);
Aaux=[ones(1,2*N);lambda*A, -lambda*A];
yaux=[0;lambda*y];
[xaux,~,~,~,output]=lsqnonneg(Aaux,yaux);
x=xaux(1:N)-xaux(N+1:2*N);
Normx=sum(xaux);
NormRes=norm(A*x-y);
NbOuterIter=output.iterations;

end