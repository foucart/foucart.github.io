% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% %
% Reproducible file for the paper
% COMPUTATION OF CHEBYSHEV POLYNOMIALS ON UNION OF INTERVALS
% by S. Foucart and J. B. Lasserre
% Written by S. Foucart in June 2018
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% %

%% Note: you will need Chebfun and CVX,
% ideally with an academic license to allow the use of Mosek

%% Experiment 1: Chebyshev polynomials of the first kind
% verification of the code and production of Figure 1

clear all; clc;
cvx_quiet true
cvx_solver mosek

N = 5;
K1 = {[-1 -1/2],[-1/5 1/5],[1/2 1]};
K2 = {[-1 -1/2],[1/10 1/5],[2/3 1]};

% unweigthed, unrestricted (all zeros inside of K)
figure(1)
cheb1(N,K1,'figure');
% unweigthed, unrestriced (some zeros outside of K)
figure(2)
cheb1(N,K2,'figure');
% unweighted, restricted
figure(3)
cheb1(N,K2,'restricted','figure');

% with weigths
x = chebfun('x');
num = 1+x^2;
den = 2-x^2;
% weigthed, unrestricted (all zeros inside of K)
figure(4)
cheb1(N,K1,'w_num',num,'w_den',den,'figure');
% weigthed, unrestriced (some zeros outside of K)
figure(5)
cheb1(N,K2,'w_num',num,'w_den',den,'figure');
% weigthed, restricted
figure(6)
cheb1(N,K2,'w_num',num,'w_den',den,'restricted','figure');


%% Experiment 2: Chebyshev polynomials of the second kind
% verification of the code and production of Figure 2

clear all; clc;
cvx_quiet true
cvx_solver mosek

N = 5;
K1 = {[-1 -1/2],[-1/5 1/5],[1/2 1]};
K2 = {[-1 -1/2],[1/10 1/5],[2/3 1]};
d = 150;

% umweighted
figure(7)
[~,lb1,ub1]=cheb2(N,K1,d,'figure');
delta1 = 1-lb1/ub1;
figure(8)
[~,lb2,ub2]=cheb2(N,K2,d,'figure');
delta2 = 1-lb2/ub2;
% weigthed
x = chebfun('x');
w = (1+x^2)/(2-x^2);
figure(9)
[~,lb3,ub3]=cheb2(N,K1,d,'weight',w,'figure');
delta3 = 1-lb3/ub3;
figure(10)
[~,lb4,ub4]=cheb2(N,K2,d,'weight',w,'figure');
delta4 = 1-lb4/ub4;
