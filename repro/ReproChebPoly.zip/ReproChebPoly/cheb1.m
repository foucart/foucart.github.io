%% cheb1.m
% Find the Chebyshev polynomial of the first kind
% on a finite union of intervals
%
% Implements the semidefinite program proposed in the article
% "Computation of Chebyshev Polynomials on Union of Intervals"
% by S. Foucart and J. B. Lasserre
% CVX and Chebfun are needed to use this function
%
% Usage: [T,normT] = cheb1(N,K,...)
%
% N: the degree of the Chebyshev polynomial
% K: the union of intervals, entered as a cell of intervals
% Other optional inputs:
% a weight function w
%   enter its numerator and denominator as chebfuns 
%   after the fields 'w_num' and 'w_den', respectively
%   default is w=1, same as cheb1(N,K,'w_num',chebfun('1'),'w_den',chebfun('1'))
% the option to output the restricted Chebyshev polynomial
%   type 'restricted' if so desired, i.e., cheb1(N,K,'restricted')
% the option to plot the output
%   type 'figure' if so desired, i.e., cheb1(N,K,'figure')
%
% T: the N-th Chebyshev polynomial of the first kind on K
% normT: the max-norm of T on K

% Written by Simon Foucart in June 2018
% Send comments to simon.foucart@centraliens.net

function [T,normT] = cheb1(N,K,varargin)

% separate the special case N=0
if N==0
    T = chebfun('1');
    normT = 1;
end
% TODO: deal will the case N=1, which is problematic

% plotting the Chebyshev polynomial required?
loc = find(strcmpi(varargin,'figure'));
figureIsPresent = any(loc);

% restricted Chebyshev polynomial required?
loc = find(strcmpi(varargin,'restricted'));
restrictedIsPresent = any(loc);

% get the numerator of the weight function
loc = find(strcmpi(varargin,'w_num'));
w_numIsPresent = any(loc);
if w_numIsPresent
    num = varargin{loc+1};
    deg_num = length(num)-1;
else
    num = chebfun('1');
    deg_num = 0;
end

% get the denominator of the weight function
loc = find(strcmpi(varargin,'w_den'));
w_denIsPresent = any(loc);
if w_denIsPresent
    den = varargin{loc+1};
    deg_den = length(den)-1;
else
    den = chebfun('1');
    deg_den = 0;
end

% define auxiliary quantities
L = length(K);
M = max(deg_num,deg_den+N);
coeffs_num = [chebcoeffs(num); zeros(M-deg_num,1)];
W = zeros(M+1,N+1);
for n=0:N
    temp = chebcoeffs(den*chebpoly(n));
    W(1:length(temp),n+1) =  temp;
end

%% Unrestricted case

if N>0 && ~restrictedIsPresent
    
    % the main SDP minimization
    cvx_begin
    % define the variables
    variable c
    variable p_aux(N)
    expression p
    p = [p_aux;1];
    % imposing P to be monic by setting p = [p_aux;1/2^(N-1)]
    % would give worse results than renormalizing at the end
    variable Qp(M+1,M+1,L) hermitian semidefinite;
    variable Qm(M+1,M+1,L) hermitian semidefinite;
    variable Rp(M,M,L) hermitian semidefinite;
    variable Rm(M,M,L) hermitian semidefinite;
    % minimize the objective function
    minimize c
    % formulate the constraints
    for l=1:L
        alpha = (acos(K{l}(1)) + acos(K{l}(2)))/2;
        beta  = (acos(K{l}(1)) - acos(K{l}(2)))/2;
        % m>0
        for m=1:M
            sum(diag(Qp(:,:,l),-m))...
                + exp(+1i*alpha)/2*sum(diag(Rp(:,:,l),-m+1))...
                - cos(beta)*sum(diag(Rp(:,:,l),-m))...
                + exp(-1i*alpha)/2*sum(diag(Rp(:,:,l),-m-1))...
                == coeffs_num(m+1)*c/2 + W(m+1,:)*p/2;
            sum(diag(Qm(:,:,l),-m))...
                + exp(+1i*alpha)/2*sum(diag(Rm(:,:,l),-m+1))...
                - cos(beta)*sum(diag(Rm(:,:,l),-m))...
                + exp(-1i*alpha)/2*sum(diag(Rm(:,:,l),-m-1))...
                == coeffs_num(m+1)*c/2 - W(m+1,:)*p/2;
        end
        % m=0
        sum(diag(Qp(:,:,l)))...
            + exp(+1i*alpha)/2*sum(diag(Rp(:,:,l),1))...
            - cos(beta)*sum(diag(Rp(:,:,l)))...
            + exp(-1i*alpha)/2*sum(diag(Rp(:,:,l),-1))...
            == coeffs_num(1)*c + W(1,:)*p;
        sum(diag(Qm(:,:,l)))...
            + exp(+1i*alpha)/2*sum(diag(Rm(:,:,l),1))...
            - cos(beta)*sum(diag(Rm(:,:,l)))...
            + exp(-1i*alpha)/2*sum(diag(Rm(:,:,l),-1))...
            == coeffs_num(1)*c - W(1,:)*p;
    end
    cvx_end
    
    % return the outputs
    T = chebfun(p/2^(N-1),'coeffs');
    normT = c/2^(N-1);
    
end

%% Restricted case

if N>0 && restrictedIsPresent
    
    % produce all possible sign vectors of size L-1
    signs = 2*(dec2bin(2^(L-1)-1:-1:0)-'0')-1;
    % solve 2^(L-1) SDP minimizations
    for k=1:2^(L-1)
        cvx_begin
        % define the variables
        variable c
        variable p_aux(N)
        expression p
        p = [p_aux;1];
        variable Qp(M+1,M+1,L) hermitian semidefinite;
        variable Qm(M+1,M+1,L) hermitian semidefinite;
        variable Rp(M,M,L) hermitian semidefinite;
        variable Rm(M,M,L) hermitian semidefinite;
        % Q and R are the extra matrices induced by the gaps
        variable Q(N+1,N+1,L-1) hermitian semidefinite;
        variable R(N,N,L-1) hermitian semidefinite;
        % minimize the objective function
        minimize c
        % formulate the constraints relative to the intervals...
        for l=1:L
            alpha = (acos(K{l}(1)) + acos(K{l}(2)))/2;
            beta  = (acos(K{l}(1)) - acos(K{l}(2)))/2;
            % m>0
            for m=1:M
                sum(diag(Qp(:,:,l),-m))...
                    + exp(+1i*alpha)/2*sum(diag(Rp(:,:,l),-m+1))...
                    - cos(beta)*sum(diag(Rp(:,:,l),-m))...
                    + exp(-1i*alpha)/2*sum(diag(Rp(:,:,l),-m-1))...
                    == coeffs_num(m+1)*c/2 + W(m+1,:)*p/2;
                sum(diag(Qm(:,:,l),-m))...
                    + exp(+1i*alpha)/2*sum(diag(Rm(:,:,l),-m+1))...
                    - cos(beta)*sum(diag(Rm(:,:,l),-m))...
                    + exp(-1i*alpha)/2*sum(diag(Rm(:,:,l),-m-1))...
                    == coeffs_num(m+1)*c/2 - W(m+1,:)*p/2;
            end
            % m=0
            sum(diag(Qp(:,:,l)))...
                + exp(+1i*alpha)/2*sum(diag(Rp(:,:,l),1))...
                - cos(beta)*sum(diag(Rp(:,:,l)))...
                + exp(-1i*alpha)/2*sum(diag(Rp(:,:,l),-1))...
                == coeffs_num(1)*c + W(1,:)*p;
            sum(diag(Qm(:,:,l)))...
                + exp(+1i*alpha)/2*sum(diag(Rm(:,:,l),1))...
                - cos(beta)*sum(diag(Rm(:,:,l)))...
                + exp(-1i*alpha)/2*sum(diag(Rm(:,:,l),-1))...
                == coeffs_num(1)*c - W(1,:)*p;
        end
        %... and the extra constraints relative to the gaps
        for l=1:L-1
            alpha = (acos(K{l}(2)) + acos(K{l+1}(1)))/2;
            beta  = (acos(K{l}(2)) - acos(K{l+1}(1)))/2;
            % m>0
            for m=1:N
                sum(diag(Q(:,:,l),-m))...
                    + exp(+1i*alpha)/2*sum(diag(R(:,:,l),-m+1))...
                    - cos(beta)*sum(diag(R(:,:,l),-m))...
                    + exp(-1i*alpha)/2*sum(diag(R(:,:,l),-m-1))...
                    == signs(k,l)*p(m+1)/2;
            end
            % m=0
            sum(diag(Q(:,:,l)))...
                + exp(+1i*alpha)/2*sum(diag(R(:,:,l),1))...
                - cos(beta)*sum(diag(R(:,:,l)))...
                + exp(-1i*alpha)/2*sum(diag(R(:,:,l),-1))...
                == signs(k,l)*p(1);
        end
        cvx_end
        
        allT{k} = chebfun(p/2^(N-1),'coeffs');
        allnormT(k) = c/2^(N-1);
        
    end
    
    % return the outputs
    [normT,idx] = min(allnormT);
    T = allT{idx};
    
end

%% produce a plot, if required
if figureIsPresent
    plot(T,'LineWidth',2);
    hold on
    for l=1:L
        Kl = K{l}(1):0.001:K{l}(2);
        plot(Kl,normT*zeros(size(Kl)),'k','LineWidth',2);
        plot(Kl,normT*num(Kl)./den(Kl),':k',...
            Kl,-normT*num(Kl)./den(Kl),':k','LineWidth',1);
    end
    hold off
end

end