%% cheb2.m
% Find the Chebyshev polynomial of the second kind
% on a finite union of intervals
%
% Implements the semidefinite program proposed in the article
% "Computation of Chebyshev Polynomials on Union of Intervals"
% by S. Foucart and J. B. Lasserre
% CVX and Chebfun are needed to use this function
%
% Usage: [V,lb,ub] = cheb2(N,K,d,...)
%
% N: the degree of the Chebyshev polynomial
% K: the union of intervals, entered as a cell of intervals
% d: the parameter for the size of the semidefinite matrices
% Other optional inputs:
% a weight function w
%   enter it as a chebfun after the field 'weight' 
%   default is w=1, same as cheb1(N,K,'weight',chebfun('1'))
% the option to plot the output
%   type 'figure' if so desired, i.e., cheb1(N,K,'figure')
%
%  V: ersatz N-th Chebyshev polynomial of the second kind on K
% lb: a lower bound for the weighted L1-norm of the genuine Chebyshev polynomial
%     obtained as the minimum of the semidefinite program
% ub: an upper bound for the weighted L1-norm of the genuine Chebyshev polynomial
%     obtained as the weighted L1-norm of V

% Written by Simon Foucart in June 2018
% Send comments to simon.foucart@centraliens.net

function [V,lb,ub] = cheb2(N,K,d,varargin)

% plotting the Chebyshev polynomial required?
loc = find(strcmpi(varargin,'figure'));
figureIsPresent = any(loc);

% get the weight function
loc = find(strcmpi(varargin,'weight'));
weightIsPresent = any(loc);
if weightIsPresent
    w = varargin{loc+1};;
else
    w = chebfun('1');
end

% define auxiliary quantities
L = length(K);
halflengths = zeros(1,L);
for l=1:L
    halflengths(l) = (K{l}(2)-K{l}(1))/2;
end
% the matrices W^l
W = zeros(N+1,N+1,L);
for l=1:L
    for n=0:N
        Tn_l = chebfun(chebpoly(n),K{l});
        temp1 = chebcoeffs(Tn_l,'kind',2);
        W(1:length(temp1),n+1,l) =  temp1;
    end
end
% the matrices J^l
J = zeros(d+1,N+1,L);
if weightIsPresent
    for l=1:L
        w_l = chebfun(chebcoeffs(chebfun(w,K{l})),'coeffs');
        for k=0:d
            for n=0:N
                J(k+1,n+1,l) = sum(chebpoly(k)*chebpoly(n,2)/w_l);
            end
        end
    end
else
    for l=1:L
        for k=0:d
            for n=0:N
                if mod(k-n,2) == 0
                    J(k+1,n+1,l) = 2*(n+1)/((n+1)^2-k^2);
                end
            end
        end
    end
end

% the main SDP minimization
cvx_begin
% define the variables
variable p_aux(N)
expression p
p = [p_aux;1];
variable yp(L,d+1)
variable ym(L,d+1)
% minimize the objective function
minimize halflengths * (yp(:,1)+ym(:,1))
% formulate the constraints
subject to
for l=1:L
    toeplitz(yp(l,:)) == semidefinite(d+1);
    toeplitz(ym(l,:)) == semidefinite(d+1);
    J(:,:,l)*W(:,:,l)*p == yp(l,:)'-ym(l,:)';
end
cvx_end

% return the outputs
V = chebfun(p/2^(N-1),'coeffs');
lb = cvx_optval/2^(N-1);
for l=1:L
    temp2(l) = sum(abs(chebfun(V/w,K{l})));
end
ub = sum(temp2);

if figureIsPresent
    plot(V,'LineWidth',2);
    hold on
    for l=1:L
        Kl = K{l}(1):0.001:K{l}(2);
        plot(Kl,zeros(size(Kl)),'k','LineWidth',2);
    end
    hold off
end

end
