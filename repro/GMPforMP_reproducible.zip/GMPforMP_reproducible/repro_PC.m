%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Reproducible file accompanying the paper [1]
% DETERMINING PROJECTION CONSTANTS OF UNIVARIATE POLYNOMIAL SPACES 
% by S. Foucart and J. B. Lasserre 
% Written by S. Foucart in December 2017
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% CVX [2] and Chebfun [3] are needed to execute the cells below, and being
% able to chose Gurobi as a solver for linear programs is a clear advantage
format long

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% Experiment 1: verifying the result of Chalmers--Metcalf [4], i.e., that 
% the projection constants for the quadratics is 1.220173064217988

%% Experiment 1a: upper bound
% Output: 1.220193546648052 in about 5min

cvx_quiet true
cvx_solver gurobi
x = chebfun('x');
basis_e = {x.^0,x.^2};
basis_o = {x};
K = 250; 
L = 250;
tic;
[ub1a,meas_e1a,meas_o1a] = PCUB_sym(basis_e,basis_o,K,L);
t1a = toc;
ub1a

%% Experiment 1a bis: still the upper bound, but with more precision
% Output: 1.220193350554356 in about 35min

cvx_quiet true
cvx_solver gurobi
x = chebfun('x');
basis_e = {x.^0,x.^2};
basis_o = {x};
K = 500; 
L = 250;
tic;
[ub1a,meas_e1a,meas_o1a] = PCUB_sym(basis_e,basis_o,K,L);
t1a = toc;
ub1a
save('Exp1a.mat')

%% Experiment 1b: lower bound
% Output: 1.220124734692712 in under 15min

cvx_quiet true
cvx_solver default
x = chebfun('x');
basis_e = {x.^0,x.^2};
basis_o = {x};
L = 100;
S = 50;
tic;
[lb1b,moments_e1b,moments_o1b] = PCLB_sym(basis_e,basis_o,S,L);
t1b = toc;
lb1b
save('Exp1b.mat')

%% Visualization of the optimal measures

% import the data for the approximate minimal projection 
try load('Exp1a.mat')
catch
    load('Exp1a_default.mat')
end
% define the parameters for the true minimal projection from [4]
A = -0.055043;
B = 0.83054;
C = 0.29260;
D = 0.38887;
a1 = 0.14588;
b1 = 0.97774;
d1 = -3.3894;
a2 = 0.12834*a1;
b2 = 0.12834*(-b1);
d2 = 0.12834*d1;
c1 = -(a1+d1);
c2 = +(a2+d2);
s11 = 0.14159;
s12 = 0.35435;
s21 = 0.82395;
s22 = 0.94689;  
w1 = 1.80787;
w2 = -w1;

% the atomic parts of the two sets of measures seem to be the same 
[full(meas_e1a(1,1))  A; full(meas_e1a(1,K))   B; full(meas_e1a(1,end)) A]
[full(meas_o1a(1,1)) -C; full(meas_o1a(1,end)) C]
[full(meas_e1a(2,1))  D; full(meas_e1a(2,K))  -B; full(meas_e1a(2,end)) D]

% now look at their continuous parts --- they seem to be different!
% here are the continuous parts g1,g2,g3 of the measures from [4]
t = linspace(-1,1,1001);
g1 = (a1*abs(t)+b1)./(1+w1*abs(t)).^3 .* (t>=-s12 & t<=-s11 )...
    +(a1*abs(t)+b1)./(1+w1*abs(t)).^3 .* (t<=s12 & t>=s11 )...
    +(a2*abs(t)+b2)./(1+w2*abs(t)).^3 .* (t>=-s22 & t<=-s21)...
    +(a2*abs(t)+b2)./(1+w2*abs(t)).^3 .* (t<=s22 & t>=s21);
g2 = c1*t./(1+w1*abs(t)).^3 .* (t>=-s12 & t<=-s11 )...
    +c1*t./(1+w1*abs(t)).^3 .* (t<=s12 & t>=s11 )...
    +c2*t./(1+w2*abs(t)).^3 .* (t>=-s22 & t<=-s21)...
    +c2*t./(1+w2*abs(t)).^3 .* (t<=s22 & t>=s21);
g3 = (d1*abs(t)-b1)./(1+w1*abs(t)).^3 .* (t>=-s12 & t<=-s11 )...
    +(d1*abs(t)-b1)./(1+w1*abs(t)).^3 .* (t<=s12 & t>=s11 )...
    +(d2*abs(t)-b2)./(1+w2*abs(t)).^3 .* (t>=-s22 & t<=-s21)...
    +(d2*abs(t)-b2)./(1+w2*abs(t)).^3 .* (t<=s22 & t>=s21);
% here are the continuous parts h1,h2,h3 of the measures we computed
aux1 = meas_e1a(1,:);
aux1(1)=0; aux1(K)=0; aux1(end)=0;
idx1 = find(aux1);
supp1 = (2*idx1-1-2*K)/(2*K-1); 
h1 = aux1(idx1)*K*(s12-s11+s22-s21);
% 
aux2 = meas_o1a(1,:);
aux2(1)=0; aux2(end)=0;
idx2 = find(aux2);
supp2 = (2*idx2-1-2*K)/(2*K-1);
h2 = aux2(idx2)*K*(s12-s11+s22-s21);
% 
aux3 = meas_e1a(2,:);
aux3(1)=0; aux3(K)=0; aux3(end)=0;
idx3 = find(aux3);
supp3 = (2*idx3-1-2*K)/(2*K-1);
h3 = aux3(idx3)*K*(s12-s11+s22-s21);
% 

% and here are the plots of (g1,h1), (g2,h2), and (g3,h3)
figure(1);
plot(t,g1,'k');
title('\mu_1','Fontsize',24)
ax = gca;
ax.XTick = [-1 0 1];
ax.YTick = [0 1];
hold on
plot(supp1,h1,'ko');
print('-depsc2','Mu1.eps')
figure(2);
plot(t,g2,'b');
title('\mu_2','Fontsize',24)
ax = gca;
ax.XTick = [-1 0 1];
ax.YTick = [-3 0 3];
hold on;
plot(supp2,h2,'bs');
print('-depsc2','Mu2.eps')
figure(3);
plot(t,g3,'r');
title('\mu_3','Fontsize',24)
ax = gca;
ax.XTick = [-1 0 1];
ax.YTick = [-1 0 2];
hold on;
plot(supp3,h3,'rd');
print('-depsc2','Mu3.eps')

%% An aside: see how Chalmers--Metcalf and our computed minimal projections 
% act on a given function f

x = chebfun('x');
f = @(z) abs(z);  % change this example function as you please 

atomic1 = A*f(-1)+B*f(0)+A*f(1);
atomic2 = -C*f(-1)+C*f(1);
atomic3 = D*f(-1)-B*f(0)+D*f(1);
f11 = @(z) f(z).*(a1*abs(z)+b1)./(1+w1*abs(z)).^3;
f12 = @(z) f(z).*(a2*abs(z)+b2)./(1+w2*abs(z)).^3;
continuous1 = integral( f11, -s12, -s11 ) ...
            + integral( f11, s11, s12) ...
            + integral( f12, -s22, -s21 ) ...
            + integral( f12, s21, s22 );
f21 = @(z) f(z).*(c1*z)./(1+w1*abs(z)).^3;
f22 = @(z) f(z).*(c2*z)./(1+w2*abs(z)).^3;
continuous2 = integral( f21, -s12, -s11 ) ...
            + integral( f21, s11, s12 ) ...
            + integral( f22, -s22, -s21 ) ...
            + integral( f22, s21, s22 );
f31 = @(z) f(z).*(d1*abs(z)-b1)./(1+w1*abs(z)).^3;
f32 = @(z) f(z).*(d2*abs(z)-b2)./(1+w2*abs(z)).^3;
continuous3 = integral( f31, -s12, -s11 ) ...
            + integral( f31, s11, s12 ) ...
            + integral( f32, -s22, -s21 ) ...
            + integral( f32 , s21, s22 );
% Chalmers--Metcal projection applied to f
PCM_f = (atomic1+continuous1)*x.^0 ...
      + (atomic2+continuous2)*x.^1 ...
      + (atomic3+continuous3)*x.^2;
% Our computed minimal projection applied to f
PUB_f = (f(linspace(-1,1,2*K-1))*meas_e1a(1,:)')*x.^0 ...
      + (f(linspace(-1,1,2*K-1))*meas_o1a(1,:)')*x.^1 ...
      + (f(linspace(-1,1,2*K-1))*meas_e1a(2,:)').*x.^2;
% view the difference 
figure(4); plot(PCM_f-PUB_f)


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Experiment 2: checking that span{1,x^2,x^3} has projection constant = 1

%% Experiment 2a: upper bound
% Output: 1.000030843465043 in under 1sec

cvx_quiet true
cvx_solver gurobi
x = chebfun('x');
basis_e = {x.^0,x.^2};
basis_o = {x.^3};
K = 50; 
L = 300;
tic;
[ub2a,meas_e2a,meas_o2a] = PCUB_sym(basis_e,basis_o,K,L);
t2a = toc;
ub2a

%% Experiment 2b: lower bound
% Output: 1.000000004413316 in under 6min

cvx_quiet true
cvx_solver default
x = chebfun('x');
basis_e = {x.^0,x.^2};
basis_o = {x.^3};
L = 200;
S = 30;
tic;
[lb2b,moments_e2b,moments_o2b] = PCLB_sym(basis_e,basis_o,S,L);
t2b = toc;
lb2b


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Experiment 3: the space span{1,x,x^3}

%% Experiment 3a: upper bound
% Output: 1.472372370583215 in about 2min

cvx_quiet true
cvx_solver gurobi
x = chebfun('x');
basis_e = {x.^0};
basis_o = {x,x.^3};
K = 250; 
L = 250;
tic;
[ub3a,meas_e3a,meas_o3a] = PCUB_sym(basis_e,basis_o,K,L);
t3a = toc;
ub3a
save('Exp3a.mat')

%% Experiment 3b: lower bound
% Output: 1.472300776125535 in 4hrs 25min

cvx_quiet true
cvx_solver default
x = chebfun('x');
basis_e = {x.^0};
basis_o = {x,x.^3};
L = 100;
grid_aux = linspace(0,pi,2*L);
grid_aux = grid_aux(grid_aux<pi/2);
grid = cos(grid_aux);
S = 100;
tic;
[lb3b,moments_e3b,moments_o3b] = PCLB_sym(basis_e,basis_o,S,L,'othergrid',grid);
t3b = toc;
lb3b
save('Exp3b.mat')


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% Experiment 4: the space span{T_0,T_2,T_3}

%% Experiment 4a: upper bound
% Output: 1.446086358484626 in about 20min

cvx_quiet true
cvx_solver gurobi
basis_e = {chebpoly(0),chebpoly(2)};
basis_o = {chebpoly(3)};
K = 400;
L = 400;
tic;
[ub4a,meas_e4a,meas_o4a] = PCUB_sym(basis_e,basis_o,K,L);
t4a = toc;
ub4a
save('Exp4a.mat')

%% Experiment 4b: lower bound
% Output: 1.446000431100673 in 3hrs 37min

cvx_quiet true
cvx_solver default
basis_e = {chebpoly(0),chebpoly(2)};
basis_o = {chebpoly(3)};
L = 100;
S = 100;
tic;
[lb4b,moments_e4b,moments_o4b] = PCLB_sym(basis_e,basis_o,S,L,'chebextrs');
t4b = toc;
lb4b
save('Exp4b.mat')


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% Experiment 5: the space span{U_0,U_2,U_3}

%% Experiment 5a: upper bound
% Output: 1.152251239479510 in 1hr 40 min

cvx_quiet true
cvx_solver gurobi
basis_e = {chebpoly(0,2),chebpoly(2,2)};
basis_o = {chebpoly(3,2)};
K = 400;
L = 400;
tic;
[ub5a,meas_e5a,meas_o5a] = PCUB_sym(basis_e,basis_o,K,L);
t5a = toc;
ub5a
save('Exp5a.mat')

%% Experiment 5b: lower bound
% Output: 1.152225915740389 in 1hr 17min

cvx_quiet true
cvx_solver default
basis_e = {chebpoly(0,2),chebpoly(2,2)};
basis_o = {chebpoly(3,2)};
L = 100;
S = 70;
tic;
[lb5b,moments_e5b,moments_o5b] = PCLB_sym(basis_e,basis_o,S,L);
t5b = toc;
lb5b
save('Exp5b.mat')


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Experiment 6: the space span{x,x^2,x^3}

%% Experiment 6a: upper bound
% Output: 1.332582475792102 in about 7min

cvx_quiet true
cvx_solver gurobi
x = chebfun('x');
basis_e = {x.^2};
basis_o = {x,x.^3};
K = 400; 
L = 300;
tic;
[ub6a,meas_e6a,meas_o6a] = PCUB_sym(basis_e,basis_o,K,L);
t6a = toc;
ub6a
save('Exp6a.mat')

%% Experiment 6b: lower bound
% Output: 1.332502333394488 in 4hrs 35min

cvx_quiet true
cvx_solver default
x = chebfun('x');
basis_e = {x.^2};
basis_o = {x,x.^3};
L = 100;
grid_aux = linspace(0,pi,2*L);
grid_aux = grid_aux(grid_aux<pi/2);
grid = cos(grid_aux);
S = 100;
tic;
[lb6b,moments_e6b,moments_o6b] = PCLB_sym(basis_e,basis_o,S,L,'othergrid',grid);
t6b = toc;
lb6b
save('Exp6b.mat')


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Experiment 7: the space span{T_1,T_2,T_3}

%% Experiment 7a: upper bound
% Output: 1.406594867230373 in 1hr 1min 

cvx_quiet true
cvx_solver gurobi
basis_e = {chebpoly(2)};
basis_o = {chebpoly(1),chebpoly(3)};
K = 500; 
L = 500;
tic;
[ub7a,meas_e7a,meas_o7a] = PCUB_sym(basis_e,basis_o,K,L);
t7a = toc;
ub7a
save('Exp7a.mat')

%% Experiment 7b: lower bound
% Output: 1.406512140233150 in 3hrs 25 min

cvx_quiet true
cvx_solver default
basis_e = {chebpoly(2)};
basis_o = {chebpoly(1),chebpoly(3)};
L = 100;
S = 160;
tic;
[lb7b,moments_e7b,moments_o7b] = PCLB_sym2(basis_e,basis_o,S,L,'chebextrs');
t7b = toc;
lb7b
save('Exp7b.mat')


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Experiment 8: the space span{U_1,U_2,U_3}

%% Experiment 8a: upper bound
% Output: 1.235498432908274 in 1hr 40min

cvx_quiet true
cvx_solver gurobi
basis_e = {chebpoly(2,2)};
basis_o = {chebpoly(1,2),chebpoly(3,2)};
K = 500; 
L = 500;
tic;
[ub8a,meas_e8a,meas_o8a] = PCUB_sym(basis_e,basis_o,K,L);
t8a = toc;
ub8a
save('Exp8a.mat')

%% Experiment 8b: lower bound
% Output: 1.235403433655280 in 1h 6min 

cvx_quiet true
cvx_solver default
basis_e = {chebpoly(2,2)};
basis_o = {chebpoly(1,2),chebpoly(3,2)};
L = 100;
S = 70;
tic;
[lb8b,moments_e8b,moments_o8b] = PCLB_sym(basis_e,basis_o,S,L);
t8b = toc;
lb8b
save('Exp8b.mat')


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Experiment 9: the space of cubic polynomials

%% Experiment 9a: upper bound
% Output: 1.356965236543993 in about 1h 27min

cvx_quiet true
cvx_solver gurobi
x = chebfun('x');
basis_e = {x.^0,x.^2};
basis_o = {x,x.^3};
K = 1000; 
L = 250;
tic;
[ub9a,meas_e9a,meas_o9a] = PCUB_sym(basis_e,basis_o,K,L);
t9a = toc;
ub9a
save('Exp9a.mat')

%% Experiment 9b: lower bound
% Output: 1.356676734173714 in 2hrs 7min

cvx_quiet true
cvx_solver default
x = chebfun('x');
basis_e = {x.^0,x.^2};
basis_o = {x,x.^3};
L = 100;
S = 80;
tic;
[lb9b,moments_e9b,moments_o9b] = PCLB_sym(basis_e,basis_o,S,L,'chebextrs');
t9b = toc;
lb9b
save('Exp9b.mat')

%% Visualization of the optimal measures

% import the data for the approximate minimal projection 
try load('Exp9a.mat')
catch
    load('Exp9a_default.mat')
end
% the atomic parts of the measures, located at -1 and 1 (nothing at 0), are
[full(meas_e9a(1,1)) full(meas_e9a(1,end));...
    full(meas_o9a(1,1)) full(meas_o9a(1,end));...
    full(meas_e9a(2,1)) full(meas_e9a(2,end));...
    full(meas_o9a(2,1)) full(meas_o9a(2,end))]
% now look at the continuous parts h1,h2,h3,h4 of our computed measures
aux1 = meas_e9a(1,:);
aux1(1)=0; aux1(end)=0;
aux2 = meas_o9a(1,:);
aux2(1)=0; aux2(end)=0;
aux3 = meas_e9a(2,:);
aux3(1)=0; aux3(end)=0;
aux4 = meas_o9a(2,:);
aux4(1)=0; aux4(end)=0;

figure(5);
plot(linspace(-1,1,2*K-1),aux1,'k');
pbaspect([2 1 1])
title('\mu_1','Fontsize',24)
ax = gca;
ax.XTick = [-1 0 1];
ax.YTick = [0 0.03];
print('-depsc2','CubMu1.eps')
figure(6);
plot(linspace(-1,1,2*K-1),aux2,'b');
pbaspect([2 1 1])
title('\mu_2','Fontsize',24)
ax = gca;
ax.XTick = [-1 0 1];
ax.YTick = [-0.04 0 0.04];
print('-depsc2','CubMu2.eps')
figure(7);
plot(linspace(-1,1,2*K-1),aux3,'r');
pbaspect([2 1 1])
title('\mu_3','Fontsize',24)
ax = gca;
ax.XTick = [-1 0 1];
ax.YTick = [-0.03 0 0.04];
print('-depsc2','CubMu3.eps')
figure(8);
plot(linspace(-1,1,2*K-1),aux4,'g');
pbaspect([2 1 1])
title('\mu_4','Fontsize',24)
ax = gca;
ax.XTick = [-1 0 1];
ax.YTick = [-0.04 0 0.04];
print('-depsc2','CubMu4.eps')


%% The conjecture of Prophet--Chalmers--Metcalf seems to be wrong

a = meas_e9a(2,:);
M = -diag(ones(2*K-1,1)) + 3*diag(ones(2*K-2,1),1)...
    -3*diag(ones(2*K-3,1),2) + diag(ones(2*K-4,1),3);

cvx_quiet true
cvx_solver gurobi
cvx_begin
variable f(2*K-1)
minimize a*f
subject to
M*f >= 0;
f <= 1;
f >= -1;
cvx_end

cvx_optval


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Experiment 10: the space of quartic polynomials

%% Experiment 10a: upper bound
% Output: 1.459515423080376 in about 4min

cvx_quiet true
cvx_solver gurobi
x = chebfun('x');
basis_e = {x.^0,x.^2,x.^4};
basis_o = {x,x.^3};
K = 250; 
L = 250;
tic;
[ub10a,meas_e10a,meas_o10a] = PCUB_sym(basis_e,basis_o,K,L);
t10a = toc;
ub10a
save('Exp10a.mat')

%% Experiment 10b: lower bound
% Output: 1.459027158700071 in 7hrs 8min

cvx_quiet true
cvx_solver default
x = chebfun('x');
basis_e = {x.^0,x.^2,x.^4};
basis_o = {x,x.^3};
L = 100;
S = 100;
tic;
[lb10b,moments_e10b,moments_o10b] = PCLB_sym(basis_e,basis_o,S,L,'chebextrs');
t10b = toc;
lb10b
save('Exp10b.mat')


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Experiment 11: the space of quintic polynomials

%% Experiment 11a: upper bound
% Output: 1.538958774839360 in about 40min

cvx_quiet true
cvx_solver gurobi
x = chebfun('x');
basis_e = {x.^0,x.^2,x.^4};
basis_o = {x,x.^3,x.^5};
K = 400; 
L = 300;
tic;
[ub11a,meas_e11a,meas_o11a] = PCUB_sym(basis_e,basis_o,K,L);
t11a = toc;
ub11a
save('Exp11a.mat')

%% Experiment 11b: lower bound
% Output: 1.538175026268233 in about 6hrs 3min

cvx_quiet true
cvx_solver default
x = chebfun('x');
basis_e = {x.^0,x.^2,x.^4};
basis_o = {x,x.^3,x.^5};
L = 100;
S = 100;
tic;
[lb11b,moments_e11b,moments_o11b] = PCLB_sym(basis_e,basis_o,S,L,'chebextrs');
t11b = toc;
lb11b
save('Exp11b.mat')


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Experiment 12: the space of polynomials of degree 6

%% Experiment 12a: upper bound
% Output: 1.603839458215962 in 7hrs 8min

cvx_quiet true
cvx_solver gurobi
x = chebfun('x');
basis_e = {x.^0,x.^2,x.^4,x.^6};
basis_o = {x,x.^3,x.^5};
K = 500; 
L = 500;
tic;
[ub12a,meas_e12a,meas_o12a] = PCUB_sym(basis_e,basis_o,K,L);
t12a = toc;
ub12a
save('Exp12a.mat')

%% Experiment 12b: lower bound
% Output: 1.602719693139147 in 7hrs 31min

cvx_quiet true
cvx_solver default
x = chebfun('x');
basis_e = {x.^0,x.^2,x.^4,x.^6};
basis_o = {x,x.^3,x.^5};
L = 100;
S = 100;
tic;
[lb12b,moments_e12b,moments_o12b] = PCLB_sym(basis_e,basis_o,S,L,'chebextrs');
t12b = toc;
lb12b
save('Exp12b.mat')


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Experiment 13: the space of polynomials of degree 7

%% Experiment 13a: upper bound
% Output: 1.658592227740074 in about 34hrs !!

cvx_quiet true
cvx_solver gurobi
x = chebfun('x');
basis_e = {x.^0,x.^2,x.^4,x.^6};
basis_o = {x,x.^3,x.^5,x.^7};
K = 500; 
L = 500;
tic;
[ub13a,meas_e13a,meas_o13a] = PCUB_sym(basis_e,basis_o,K,L);
t13a = toc;
ub13a
save('Exp13a.mat')

%% Experiment 13b: lower bound
% Output: 1.656939396435399 in 8hrs 32min

cvx_quiet true
cvx_solver default
x = chebfun('x');
basis_e = {x.^0,x.^2,x.^4,x.^6};
basis_o = {x,x.^3,x.^5,x.^7};
L = 100;
S = 100;
tic;
[lb13b,moments_e13b,moments_o13b] = PCLB_sym(basis_e,basis_o,S,L,'chebextrs');
t13b = toc;
lb13b
save('Exp13b.mat')

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Experiment 14: the space of polynomials of degree 8

%% Experiment 14a: upper bound
% Output: 1.707315466123576 in about 48min

cvx_quiet true
cvx_solver gurobi
x = chebfun('x');
basis_e = {x.^0,x.^2,x.^4,x.^6,x.^8};
basis_o = {x,x.^3,x.^5,x.^7};
K = 400; 
L = 250;
tic;
[ub14a,meas_e14a,meas_o14a] = PCUB_sym(basis_e,basis_o,K,L);
t14a = toc;
ub14a
save('Exp14a.mat')


%% Experiment 14b: lower bound
% Output: 1.704838940292495 in 9hrs 20min

cvx_quiet true
cvx_solver default
x = chebfun('x');
basis_e = {x.^0,x.^2,x.^4,x.^6,x.^8};
basis_o = {x,x.^3,x.^5,x.^7};
L = 100;
S = 100;
tic;
[lb14b,moments_e14b,moments_o14b] = PCLB_sym(basis_e,basis_o,S,L,'chebextrs');
t14b = toc;
lb14b
save('Exp14b.mat')

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Experiment 15: the space of polynomials of degree 9

%% Experiment 15a: upper bound
% Output: 1.751075195728429 in 1hr 15min

cvx_quiet true
cvx_solver gurobi
x = chebfun('x');
basis_e = {x.^0,x.^2,x.^4,x.^6,x.^8};
basis_o = {x,x.^3,x.^5,x.^7,x.^9};
K = 400; 
L = 250;
tic;
[ub15a,meas_e15a,meas_o15a] = PCUB_sym(basis_e,basis_o,K,L);
t15a = toc;
ub15a
save('Exp15a.mat')

%% Experiment 15b: lower bound
% Output: 1.747748292546442 in 9hrs 53min

cvx_quiet true
cvx_solver default
x = chebfun('x');
basis_e = {x.^0,x.^2,x.^4,x.^6,x.^8};
basis_o = {x,x.^3,x.^5,x.^7,x.^9};
L = 100;
S = 100;
tic;
[lb15b,moments_e15b,moments_o15b] = PCLB_sym(basis_e,basis_o,S,L,'chebextrs');
t15b = toc;
lb15b
save('Exp15b.mat')

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Experiment 16: the space of polynomials of degree 10

%% Experiment 16a: upper bound
% Output: 1.790767740969850 in 17hrs 50min

cvx_quiet true
cvx_solver gurobi
x = chebfun('x');
basis_e = {x.^0,x.^2,x.^4,x.^6,x.^8,x.^10};
basis_o = {x,x.^3,x.^5,x.^7,x.^9};
K = 400; 
L = 250;
tic;
[ub16a,meas_e16a,meas_o16a] = PCUB_sym(basis_e,basis_o,K,L);
t16a = toc;
ub16a
save('Exp16a.mat')

%% Experiment 16b: lower bound
% Output: 1.786584392553774 in 10hrs 45min

cvx_quiet true
cvx_solver default
x = chebfun('x');
basis_e = {x.^0,x.^2,x.^4,x.^6,x.^8,x.^10};
basis_o = {x,x.^3,x.^5,x.^7,x.^9};
L = 100;
S = 100;
tic;
[lb16b,moments_e16b,moments_o16b] = PCLB_sym(basis_e,basis_o,S,L,'chebextrs');
t16b = toc;
lb16b
save('Exp16b.mat')


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Experiment 17: the space of polynomials of degree 11

%% Experiment 17a: upper bound
% Output: 1.827014368957646 in 95hrs

cvx_quiet true
cvx_solver gurobi
x = chebfun('x');
basis_e = {x.^0,x.^2,x.^4,x.^6,x.^8,x.^10};
basis_o = {x,x.^3,x.^5,x.^7,x.^9,x.^11};
K = 400; 
L = 250;
tic;
[ub17a,meas_e17a,meas_o17a] = PCUB_sym(basis_e,basis_o,K,L);
t17a = toc;
ub17a
save('Exp17a.mat')

%% Experiment 17b: lower bound
% Output: 1.821690592300548 in 11hrs 9min

cvx_quiet true
cvx_solver default
x = chebfun('x');
basis_e = {x.^0,x.^2,x.^4,x.^6,x.^8,x.^10};
basis_o = {x,x.^3,x.^5,x.^7,x.^9,x.^11};
L = 100;
S = 100;
tic;
[lb17b,moments_e17b,moments_o17b] = PCLB_sym(basis_e,basis_o,S,L,'chebextrs');
t17b = toc;
lb17b
save('Exp17b.mat')


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Experiment 18: the space of polynomials of degree 12

%% Experiment 18a: upper bound
% Output: 1.862162114587615 in about 9hrs 

cvx_quiet true
cvx_solver gurobi
x = chebfun('x');
basis_e = {x.^0,x.^2,x.^4,x.^6,x.^8,x.^10,x.^12};
basis_o = {x,x.^3,x.^5,x.^7,x.^9,x.^11};
K = 300; 
L = 150;
tic;
[ub18a,meas_e18a,meas_o18a] = PCUB_sym(basis_e,basis_o,K,L);
t18a = toc;
ub18a
save('Exp18a.mat')


%% Experiment 18b: lower bound
% Output: 1.853801964680200 in 11hrs 33min

cvx_quiet true
cvx_solver default
x = chebfun('x');
basis_e = {x.^0,x.^2,x.^4,x.^6,x.^8,x.^10,x.^12};
basis_o = {x,x.^3,x.^5,x.^7,x.^9,x.^11};
L = 100;
S = 100;
tic;
[lb18b,moments_e18b,moments_o18b] = PCLB_sym(basis_e,basis_o,S,L,'chebextrs');
t18b = toc;
lb18b
save('Exp18b.mat')


%% References
%
% 1. S. Foucart and J. B. Lasserre, 
% "Determining projection constants of univariate polynomial spaces",
% Preprint.
%
% 2. CVX Research, Inc., 
% "CVX: MATLAB software for disciplined convex programming, version 2.1", 
% http://cvxr.com/cvx, 2014.
%
% 3. L. N. Trefethen et al., 
% "Chebfun Version 5, The Chebfun Development Team", 
% http://www.chebfun.org, 2014.
%
% 4. B. L. Chalmers and F. T. Metcalf,
% "Determination of a minimal projection from $C[-1,1]$ onto the quadratics",
% Numerical Functional Analysis and Optimization, 11(1-2), 1-10, 1990.
%