%%
% PCLB_sym2.m
% Computes a Lower Bound for the Projection Constant of a polynomial space
% by solving a semidefinite program (exploiting symmetry) 
% originating from, but not explicitly stated in,
% DETERMINING PROJECTION CONSTANTS OF UNIVARIATE POLYNOMIAL SPACES
% by S. Foucart and J. B. Lasserre

% Find a lower bound for
% min ||P||_{infty -> infty}
% over all projections from C[-1,1] onto a subspace U made of polynomials
% 
% Usage: [lb,moments_e,moments_o] = PCLB_sym2(basis_e,basis_o,S,L,Grid,g)
%
% basis_e: the part of a basis for U consisting of even polynomials, 
% entered as a cell of chebfuns
% basis_o: the part of a basis for U consisting of odd polynomials, 
% entered as a cell of chebfuns
% S: the size of the truncated Toeplitz matrices containing moments
% L: the number of points for the grid discretizing the interval [0,1]
% Grid: either 'chebzeros', 'chebextrs', or 'othergrid' 
%       (optional, default='chebzeros')
% g: when 'othergrid' is chosen, a vector containg the grid points 
%
% lb: the value of the lower bound
% moments_e: the moments of the optimal measures dual to basis_e
% moments_o: the moments of the optimal measures dual to basis_o
%
% Written by Simon Foucart in December 2017
% Last updated in December 2017
% Send comments to simon.foucart@centraliens.net

function [lb,moments_e,moments_o] = PCLB_sym2(basis_e,basis_o,S,L,Grid,g)

% define parameters associated to the bases,
% i.e,. the integers M_e, M_o, and d, 
% as well as matrices U_e and U_o

M_e = length(basis_e);
M_o = length(basis_o);
d = 0;
for m=1:M_e
    if length(basis_e{m})-1 > d
        d = length(basis_e{m})-1;
    end
end
for m=1:M_o
    if length(basis_o{m})-1 > d
        d = length(basis_o{m})-1;
    end
end
U_e = zeros(d+1,M_e);
for m=1:M_e
    coeffs = chebcoeffs(basis_e{m});
    U_e(1:length(coeffs),m) = coeffs;
end
U_o = zeros(d+1,M_o);
for m=1:M_o
    coeffs = chebcoeffs(basis_o{m});
    U_o(1:length(coeffs),m) = coeffs;
end

% define parameters associated to the discretization of the interval,
% i.e., collocation matrices W_e and W_o
if nargin < 5
    Grid = 'chebzeros';
end
if Grid == 'chebzeros' 
    grid = chebpts(2*L,1);
    grid = grid(grid>0);
elseif Grid == 'chebextrs'
    grid = chebpts(2*L-1);
    grid = grid(grid>=0);
elseif Grid == 'othergrid'
    grid = g;
end
W_e = zeros(L,M_e);
W_o = zeros(L,M_o);
for m=1:M_e
   W_e(:,m) = basis_e{m}(grid); 
end
for m=1:M_o
   W_o(:,m) = basis_o{m}(grid); 
end

% formulate the semidefinite program
cvx_begin

variable Yp_e(M_e,S)
variable Ym_e(M_e,S)
variable Yp_o(M_o,S)
variable Ym_o(M_o,S)
variable Zp(L,S)
variable Zm(L,S)
variable c

minimize c

subject to
% duality constraints
(Yp_e(:,1:d+1)-Ym_e(:,1:d+1))*U_e == eye(M_e);
(Yp_o(:,1:d+1)-Ym_o(:,1:d+1))*U_o == eye(M_o);
% consistency contraints
W_e*(Yp_e-Ym_e) + W_o*(Yp_o-Ym_o) == Zp-Zm;
% moment constraints
for m=1:M_e
    toeplitz(Yp_e(m,:)) == semidefinite(S);
    toeplitz(Ym_e(m,:)) == semidefinite(S);
end
for m=1:M_o
    toeplitz(Yp_o(m,:)) == semidefinite(S);
    toeplitz(Ym_o(m,:)) == semidefinite(S);
end
for l=1:L
    toeplitz(Zp(l,:)) == semidefinite(S);
    toeplitz(Zm(l,:)) == semidefinite(S);
end
% symmetry constraints
Yp_e(:,2:2:S) == Ym_e(:,2:2:S);
Yp_o(:,1:2:S-1) == Ym_o(:,1:2:S-1); 
% slack constraints
Zp(:,1) + Zm(:,1) <= c;

cvx_end

% return the outputs
lb = cvx_optval;
moments_e = Yp_e-Ym_e;
moments_o = Yp_o-Ym_o;

end