%%
% PCLB_sym.m
% Computes a Lower Bound for the Projection Constant of a polynomial space
% by solving the semidefinite program (exploiting symmetry) outlined in
% DETERMINING PROJECTION CONSTANTS OF UNIVARIATE POLYNOMIAL SPACES
% by S. Foucart and J. B. Lasserre

% Find a lower bound for
% min ||P||_{infty -> infty}
% over all projections from C[-1,1] onto a subspace U made of polynomials
% 
% Usage: [lb,moments_e,moments_o] = PCLB_sym(basis_e,basis_o,S,L,Grid,g)
%
% basis_e: the part of a basis for U consisting of even polynomials, 
% entered as a cell of chebfuns
% basis_o: the part of a basis for U consisting of odd polynomials, 
% entered as a cell of chebfuns
% S: the size of the truncated Toeplitz matrices containing moments
% L: the number of points for the grid discretizing the interval [0,1]
% Grid: either 'chebzeros', 'chebextrs', or 'othergrid' 
%       (optional, default='chebzeros')
% g: when 'othergrid' is chosen, a vector containg the grid points 
%
% lb: the value of the lower bound
% moments_e: the moments of the optimal measures dual to basis_e
% moments_o: the moments of the optimal measures dual to basis_o
%
% Written by Simon Foucart in December 2017
% Last updated in December 2017
% Send comments to simon.foucart@centraliens.net


function [lb,moments_e,moments_o] = PCLB_sym(basis_e,basis_o,S,L,Grid,g)

% define parameters associated to the bases,
% i.e,. the integers M_e, M_o, and d, 
% as well as the matrices U_e and U_o
M_e = length(basis_e);
M_o = length(basis_o);
d = 0;
for m=1:M_e
    if length(basis_e{m})-1 > d
        d = length(basis_e{m})-1;
    end
end
for m=1:M_o
    if length(basis_o{m})-1 > d
        d = length(basis_o{m})-1;
    end
end
x = chebfun('x');
U_e = zeros(d+1,M_e);
for m=1:M_e
    coeffs = chebcoeffs(basis_e{m}((x+1)/2));
    U_e(1:length(coeffs),m) = coeffs;
end
U_o = zeros(d+1,M_o);
for m=1:M_o
    coeffs = chebcoeffs(basis_o{m}((x+1)/2));
    U_o(1:length(coeffs),m) = coeffs;
end

% define parameters associated to the discretization of the interval,
% i.e., the collocation matrices W_e and W_o
if nargin < 5
    Grid = 'chebzeros';
end
if Grid == 'chebzeros' 
    grid = chebpts(2*L,1);
    grid = grid(grid>0);
elseif Grid == 'chebextrs'
    grid = chebpts(2*L-1);
    grid = grid(grid>=0);
elseif Grid == 'othergrid'
    grid = g;
end
W_e = zeros(L,M_e);
W_o = zeros(L,M_o);
for m=1:M_e
   W_e(:,m) = basis_e{m}(grid); 
end
for m=1:M_o
   W_o(:,m) = basis_o{m}(grid); 
end

% formulate the semidefinite program
cvx_begin

variable Y_e(M_e,S)
variable Y_o(M_o,S)
variable Z(L,S)
variable c

minimize c

subject to
% duality constraints
Y_e(:,1:d+1)*U_e == eye(M_e);
Y_o(:,1:d+1)*U_o == eye(M_o);
% slack constraints
for l=1:L
   toeplitz(Z(l,:)-W_e(l,:)*Y_e) == semidefinite(S);
   toeplitz(Z(l,:)+W_e(l,:)*Y_e) == semidefinite(S);
   toeplitz(Z(l,:)-W_o(l,:)*Y_o) == semidefinite(S);
   toeplitz(Z(l,:)+W_o(l,:)*Y_o) == semidefinite(S);
end
Z(:,1) <= c;

cvx_end

% return the outputs
lb = cvx_optval;
moments_e = Y_e;
moments_o = Y_o;

end