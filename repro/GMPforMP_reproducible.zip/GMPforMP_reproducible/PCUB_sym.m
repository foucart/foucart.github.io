%%
% PCUB_sym.m
% Computes an Upper Bound for the Projection Constant of a polynomial space
% by solving the linear program (exploiting symmetry) outlined in
% DETERMINING PROJECTION CONSTANTS OF UNIVARIATE POLYNOMIAL SPACES
% by S. Foucart and J. B. Lasserre

% Find an upper bound for
% min ||P||_{infty -> infty}
% over all projections from C[-1,1] onto a subspace U made of polynomials
% 
% Usage: [ub,meas_e,meas_o] = PCUB_sym(basis_e,basis_o,K,L,Grid)
%
% basis_e: the part of a basis for U consisting of even polynomials, 
% entered as a cell of chebfuns
% basis_o: the part of a basis for U consisting of odd polynomials, 
% entered as a cell of chebfuns
% K: the number of points for the discretization of the measures
% L: the number of points for the grid discretizing the interval [0,1]
% Grid: either 'chebzeros' or 'chebextrs' (optional, default='chebzeros')
%
% ub: the value of the upper bound
% meas_e: the measures dual to basis_e appearing in the minimal projection
% meas_o: the measures dual to basis_o appearing in the minimal projection
%
% Written by Simon Foucart in December 2017
% Last updated in December 2017
% Send comments to simon.foucart@centraliens.net


function [ub,meas_e,meas_o] = PCUB_sym(basis_e,basis_o,K,L,Grid)

% define parameters associated to the bases,
% i.e,. the integers M_e, M_o, and d
M_e = length(basis_e);
M_o = length(basis_o);
d = 0;
for m=1:M_e
    if length(basis_e{m})-1 > d
        d = length(basis_e{m})-1;
    end
end
for m=1:M_o
    if length(basis_o{m})-1 > d
        d = length(basis_o{m})-1;
    end
end

% define parameters associated to the discretization of the measures,
% i.e., the collocation matrices V_e and V_o
% note: we chose to discretize with an equispaced grid
discr = linspace(0,1,K);
V_e = zeros(K,M_e);
V_o = zeros(K,M_o);
for m=1:M_e
   V_e(:,m) = basis_e{m}(discr); 
end
for m=1:M_o
   V_o(:,m) = basis_o{m}(discr); 
end

% define parameters associated to the discretization of the interval,
% i.e., the collocation matrices W_e and W_o
if nargin < 5
    Grid = 'chebzeros';
end
if Grid == 'chebzeros' 
    grid = chebpts(2*L,1);
    grid = grid(grid>0);
end
if Grid == 'chebextrs'
    grid = chebpts(2*L-1);
    grid = grid(grid>=0);
end
W_e = zeros(L,M_e);
W_o = zeros(L,M_o);
for m=1:M_e
   W_e(:,m) = basis_e{m}(grid); 
end
for m=1:M_o
   W_o(:,m) = basis_o{m}(grid); 
end

% formulate the linear optimization program
cvx_begin

variable A_e(M_e,K)
variable A_o(M_o,K)
variable B(L,K)
variable c

minimize c

subject to
% duality constraints
A_e*V_e == eye(M_e);
A_o*V_o == eye(M_o);
% slack constraints
vec(B+W_e*A_e) >= 0;
vec(B-W_e*A_e) >= 0;
vec(B+W_o*A_o) >= 0;
vec(B-W_o*A_o) >= 0;
B*ones(K,1) <= c;

cvx_end

% return the outputs
if Grid == 'chebzeros'
    ub = cvx_optval/(1-pi^2/32*d^2/L^2);
end
if Grid == 'chebextrs'
    ub = cvx_optval/(1-pi^2/32*d^2/(L-1)^2);
end
meas_e = [ fliplr(A_e(:,2:end))/2, A_e(:,1), A_e(:,2:end)/2];
meas_o = [-fliplr(A_o(:,2:end))/2, A_o(:,1), A_o(:,2:end)/2];

end