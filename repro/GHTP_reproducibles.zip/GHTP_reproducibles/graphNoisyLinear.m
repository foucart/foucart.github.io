% This script is used to generate graphs for the paper
% J.-L. Bouchot, S. Foucart, P. Hitczenko, "Hard Thresholding Pursuit
% Algorithms: Number of Iterations", 2013

% This script loads the data related to the noisy linear vectors and
% generates the graphs as in the paper. It can be modified and adapted to
% your own tests.

% Author:               Jean-Luc Bouchot, Simon Foucart, Pawel Hitczenko
% Creation date:        05/25/2013
% Modification date:    06/11/2013
% Version:              1
% Copyright:            Math Department, Drexel University, for scholar and
% educational use only

close all
clear all
clc

%% Load the NORMALISED data
% Change here is you have other data such as the number of measurements or
% the size of the input vector
dataname = 'linearNoisy_N1000_m200.mat';
load(dataname);

% For the moment, we need to make sure we keep only the part for which the
% tests are done running.
lastDoneNoise = oneNoiseLvl-1; % We'll have to adapt this once the work is done.

avgSintSnHTP = avgSintSnHTP/totTests;
avgSintSnGHTP = avgSintSnGHTP/totTests;
avgSintSnOMP = avgSintSnOMP/totTests;

avgRelErrorHTP = avgRelErrorHTP*sparsity/totTests;
avgRelErrorGHTP = avgRelErrorGHTP*sparsity/totTests;
avgRelErrorOMP = avgRelErrorOMP*sparsity/totTests;


%% Plots

%% Average relative error
lastDisplayed = 0.5;
lastDisplayed = find(noises >= lastDisplayed);
lastDisplayed = lastDisplayed(1);
figure
hold on
plot(noises(1:lastDoneNoise), avgRelErrorHTP(1:lastDoneNoise), 'k--', 'LineWidth', 2)
plot(noises(1:lastDoneNoise), avgRelErrorGHTP(1:lastDoneNoise), 'r-', 'LineWidth', 2)
plot(noises(1:lastDoneNoise), avgRelErrorOMP(1:lastDoneNoise), 'b--', 'LineWidth', 6)
xlabel('Normalized measurement error', 'FontSize', 16)
ylabel('Normalized reconstruction error', 'FontSize', 16)
legend({'HTP', 'GHTP', 'OMP'}, 'FontSize', 16,4)
set(gca, 'fontsize', 16, 'XTick',0:0.1:noises(lastDisplayed+1))
axis([0 noises(lastDisplayed+1) 0 8])

%% Average number of correct indices in the output
lastNoise = 0.5;
lastIdx = find(noises >= lastNoise); % It is not really important to go further
lastIdx = lastIdx(1);
figure
hold on
plot(noises(1:lastIdx), avgSintSnHTP(1:lastIdx), 'k--', 'LineWidth', 2)
plot(noises(1:lastIdx), avgSintSnGHTP(1:lastIdx), 'r-', 'LineWidth', 2)
plot(noises(1:lastIdx), avgSintSnOMP(1:lastIdx), 'b--', 'LineWidth', 6)
xlabel('Normalized measurement error', 'FontSize', 16)
ylabel('Number of correct indices', 'FontSize', 16)
legend({'HTP', 'GHTP', 'OMP'}, 'FontSize', 16,1)
set(gca, 'fontsize', 16, 'XTick',0:0.5:noises(lastIdx))
axis([0 noises(lastIdx+1) sparsity-3 sparsity+1])