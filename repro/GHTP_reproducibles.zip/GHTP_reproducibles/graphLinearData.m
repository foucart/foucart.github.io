% This script is used to generate graphs for the paper
% J.-L. Bouchot, S. Foucart, P. Hitczenko, "Hard Thresholding Pursuit
% Algorithms: Number of Iterations", 2013

% This script loads the data related to the noiseless linear vectors and
% generates the graphs as in the paper. It can be modified and adapted to
% your own tests.

% Author:               Jean-Luc Bouchot, Simon Foucart, Pawel Hitczenko
% Creation date:        05/15/2013
% Modification date:    06/11/2013
% Version:              1
% Copyright:            Math Department, Drexel University, for scholar and
% educational use only

%% Load the NORMALISED data
% Change here is you have other data such as the number of measurements or
% the size of the input vector
dataname = 'normalised_linearVectors_N1000_m200.mat';
load(dataname);


%% Plots

%% Percentage of success
figure
hold on
plot(sparsities, nbSuccess_htp, 'k--', 'LineWidth', 2)
plot(sparsities, nbSuccess_ghtp, 'r+-', 'LineWidth', 2)
plot(sparsities, nbSuccess_omp, 'bo-', 'LineWidth', 2)
xlabel('Sparsity', 'FontSize', 16)
ylabel('Percentage of success', 'FontSize', 16)
legend({'HTP', 'GHTP', 'OMP'}, 'FontSize', 16)
set(gca, 'fontsize', 16)

%% Number of correct indices

% Choose sparsities to be displayed
% sIdx = (4:5:length(sparsities));
% sIdx = sIdx(end:-1:1);
% sIdx = [40, 35, 30, 25, 20];
sIdx = [20, 25, 30, 35, 40, 45];
% sIdx = [50, 45, 40, 35, 30, 25, 20];

toDispSparsities = sparsities(sIdx);

legendCell = cellstr(num2str(toDispSparsities(end:-1:1)', 's=%-d'));
xlab = 'Number of iterations';
ylab = 'Number of correct indices';

idxToDisp = 1:(max(toDispSparsities)+15);

figure
plot(idxToDisp(1:20), nbCorrectIdxPerIter_htp(sIdx,idxToDisp(1:20)), 'LineWidth', 2)
lh = legend(legendCell, 'FontSize', 12,2);
set(lh,'ydir','reverse');
xlabel(xlab, 'FontSize', 16)
ylabel(ylab, 'FontSize', 16)
title('Linear vectors - HTP', 'FontSize', 16)
set(gca, 'fontsize', 16, 'YTick',0:5:50)
axis([0 20 0 50])

figure
plot(idxToDisp, nbCorrectIdxPerIter_ghtp(sIdx,idxToDisp), 'LineWidth', 2)
lh = legend(legendCell, 'FontSize', 12,2);
set(lh,'ydir','reverse');
xlabel(xlab, 'FontSize', 16)
ylabel(ylab, 'FontSize', 16)
title('Linear vectors - GHTP', 'FontSize', 16)
set(gca, 'fontsize', 16, 'YTick',0:5:50)
axis([0 60 0 50])

figure
plot(idxToDisp, nbCorrectIdxPerIter_omp(sIdx,idxToDisp), 'LineWidth', 2)
lh = legend(legendCell, 'FontSize', 12,2);
set(lh,'ydir','reverse');
xlabel(xlab, 'FontSize', 16)
ylabel(ylab, 'FontSize', 16)
title('Linear vectors - OMP', 'FontSize', 16)
set(gca, 'fontsize', 16, 'YTick',0:5:50)
axis([0 60 0 50])

%% Maximum number of iterations for given sparsities
figure
hold on
maxSparsity = 45;
plot(sparsities(1:maxSparsity), max_nbIter_htp(1:maxSparsity), 'k--', 'LineWidth', 2)
plot(sparsities(1:maxSparsity), max_nbIter_ghtp(1:maxSparsity), 'r+-', 'LineWidth', 2)
plot(sparsities(1:maxSparsity), max_nbIter_omp(1:maxSparsity), 'bo-', 'LineWidth', 2)
xlabel('Sparsity', 'FontSize', 16)
ylabel('Maximum number of iterations', 'FontSize', 16)
legend({'HTP', 'GHTP', 'OMP'}, 'FontSize', 16,2)
set(gca, 'fontsize', 16, 'XTick',0:5:maxSparsity)
axis([0 maxSparsity 0 80])


%% Below are figures not presented in the article


%% Average number of iterations for given sparsities
figure
hold on
plot(sparsities, nbIter_htp, 'k--', 'LineWidth', 2)
plot(sparsities, nbIter_ghtp, 'r+-', 'LineWidth', 2)
plot(sparsities, nbIter_omp, 'bo-', 'LineWidth', 2)
xlabel('Sparsity', 'FontSize', 16)
ylabel('Average number of iterations', 'FontSize', 16)
legend({'HTP','GHTP', 'OMP'}, 'FontSize', 16)
set(gca, 'fontsize', 16)

%% Minimum number of correct indices per iteration for certain sparsities
idxToDisp = 1:(max(toDispSparsities)+20);

xlab = 'Number of iterations';
ylab = 'Minimum number of correct indices';

figure
plot(idxToDisp(1:20), min_nbCorrectIdxPerIter_htp(sIdx,idxToDisp(1:20)), 'LineWidth', 2)
lh = legend(legendCell, 'FontSize', 16,2);
set(lh,'ydir','reverse');
xlabel(xlab, 'FontSize', 16)
ylabel(ylab, 'FontSize', 16)
title('Linear vectors - HTP', 'FontSize', 16)
set(gca, 'fontsize', 16)

figure
plot(idxToDisp, min_nbCorrectIdxPerIter_ghtp(sIdx,idxToDisp), 'LineWidth', 2)
lh = legend(legendCell, 'FontSize', 16,2);
set(lh,'ydir','reverse');
xlabel(xlab, 'FontSize', 16)
ylabel(ylab, 'FontSize', 16)
title('Linear vectors - GHTP', 'FontSize', 16)
set(gca, 'fontsize', 16)

figure
plot(idxToDisp, min_nbCorrectIdxPerIter_omp(sIdx,idxToDisp), 'LineWidth', 2)
lh = legend(legendCell, 'FontSize', 16,2);
set(lh,'ydir','reverse');
xlabel(xlab, 'FontSize', 16)
ylabel(ylab, 'FontSize', 16)
title('Linear vectors - OMP', 'FontSize', 16)
set(gca, 'fontsize', 16)