This package contains the files needed to reproduce the numerical experiments in the paper:
J.-L. Bouchot, S. Foucart, P. Hitczenko, "Hard Thresholding Pursuit Algorithms: Number of Iterations", 2013

Tests were carried out on Gaussian, linear, and flat sparse vectors in an idealized (i.e., noiseless) situation and in realistic (i.e., noisy) situations.

To generate the noiseless data, run the files:
* testGaussianVectors.m
* testlinearvectors.m
* testflatvectors.m 

To generate the noisy data, run the files:
* noisyLinear.m
* noisyFlat.m

Once the data have been generated, the graphs are produced by running the files:
* graphGaussianData.m
* graphLinearData.m
* graphFlatData.m
* graphNoisyLinear.m
* graphNoisyFlat.m

Besides the scripts mentioned above, the package also contains the .mat files of already-generated data, as well as 
* htp.m: an implementation of Hard Thresholding Pursuit
* ghtp_gt.m: an implementation of Graded Hard Thresholding Pursuit (with ground truth)
* omp_gt.m: an implementation of Orthogonal Matching Pursuit (with ground truth)

More detailed explanations are given in the different MATLAB files. Please e-mail suggestions/remarks to:
jean-luc.bouchot@drexel.edu
foucart@math.drexel.edu
phitczen@math.drexel.edu

