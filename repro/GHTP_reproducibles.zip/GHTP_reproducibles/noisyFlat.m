% This script is used to generate data for the paper
% J.-L. Bouchot, S. Foucart, P. Hitczenko, "Hard Thresholding Pursuit
% Algorithms: Number of Iterations", 2013

% We consider here the robustness facing noise when dealing with flat
% vectors. This file generates the data to be used to graph the results.
% The three algorithms OMP, HTP and GHTP are compared.

% Author:               Jean-Luc Bouchot, Simon Foucart, Pawel Hitczenko
% Creation date:        05/05/2013
% Modification date:    06/11/2013
% Version:              1
% Copyright:            Math Department, Drexel University, for scholar and
% educational use only


clear all;
close all;
clc;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% PARAMETERS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
vecSize     = 1000; % Size of the vector in the 'original' input space
nbMeasures  = 200; % size of the measurement vector

NbMat       = 100; % nb of random matrices per sparsities
NbSupport   = 10; % Nb of randomly chosen support per matrix
totTests    = NbMat*NbSupport;


sparsity    = 25;  % Fix one in the safe region

x0          = []; % Where to start the algorithm
MaxNbIter   = nbMeasures;


tolSuccess  = 1e-4; % Tolerance on the relative error for a recovered vector to be consider a success
verbose     = false;


noises	  	= 0.01:0.01:5; % The different noises we want to test
nbNoise     = length(noises);



fname = ['flatNoisy_N', num2str(vecSize), '_m', num2str(nbMeasures), '.mat']

%% Allocate variables
avgSintSnGHTP = zeros(nbNoise,1);
avgSintSnHTP = zeros(nbNoise,1);
avgSintSnOMP = zeros(nbNoise,1);
minSintSnGHTP = 10000*ones(nbNoise,1);
minSintSnHTP = 10000*ones(nbNoise,1);
minSintSnOMP = 10000*ones(nbNoise,1);
maxSintSnGHTP = zeros(nbNoise,1);
maxSintSnHTP = zeros(nbNoise,1);
maxSintSnOMP = zeros(nbNoise,1);
avgRelErrorGHTP = zeros(nbNoise,1);
avgRelErrorHTP = zeros(nbNoise,1);
avgRelErrorOMP = zeros(nbNoise,1);
minRelErrorGHTP = 10000*ones(nbNoise,1);
minRelErrorHTP = 10000*ones(nbNoise,1);
minRelErrorOMP = 10000*ones(nbNoise,1);
maxRelErrorGHTP = zeros(nbNoise,1);
maxRelErrorHTP = zeros(nbNoise,1);
maxRelErrorOMP = zeros(nbNoise,1);

if exist(fname, 'file')
    
    load(fname);
    firstNoiseLvl = oneNoiseLvl;
    avgSintSnGHTP(firstNoiseLvl:end) = 0;
    avgSintSnHTP(firstNoiseLvl:end) = 0;
    avgSintSnOMP(firstNoiseLvl:end) = 0;
    minSintSnGHTP(firstNoiseLvl:end) = 10000;
    minSintSnHTP(firstNoiseLvl:end) = 10000;
    minSintSnOMP(firstNoiseLvl:end) = 10000;
    maxSintSnGHTP(firstNoiseLvl:end) = 0;
    maxSintSnHTP(firstNoiseLvl:end) = 0;
    maxSintSnOMP(firstNoiseLvl:end) = 0;
    avgRelErrorGHTP(firstNoiseLvl:end) = 0;
    avgRelErrorHTP(firstNoiseLvl:end) = 0;
    avgRelErrorOMP(firstNoiseLvl:end) = 0;
    minRelErrorGHTP(firstNoiseLvl:end) = 10000;
    minRelErrorHTP(firstNoiseLvl:end) = 10000;
    minRelErrorOMP(firstNoiseLvl:end) = 10000;
    maxRelErrorGHTP(firstNoiseLvl:end) = 0;
    maxRelErrorHTP(firstNoiseLvl:end) = 0;
    maxRelErrorOMP(firstNoiseLvl:end) = 0;
    
else
    firstNoiseLvl = 1;
end;

%% Launch tests

for oneNoiseLvl=firstNoiseLvl:nbNoise
    normErr = noises(oneNoiseLvl)
    
    for oneTrial = 1:NbMat
        
        A = randn( nbMeasures, vecSize )/sqrt(nbMeasures); 
        
        for oneSupp = 1:NbSupport
        
            S = randsample(vecSize, sparsity);
            err = randn(nbMeasures,1);
            err = err/norm(err)*normErr;
            
            x = zeros(vecSize,1);
            x(S) = 1;
            
            y = A*x + err;

            % Use GHTP
            [xstar,Sstar,NormRes] = ghtp_gt( y, A, x, x0, MaxNbIter, tolSuccess, verbose ); 
            avgSintSnGHTP(oneNoiseLvl) = avgSintSnGHTP(oneNoiseLvl) + length(intersect(S,Sstar));
            minSintSnGHTP(oneNoiseLvl) = min(minSintSnGHTP(oneNoiseLvl), length(intersect(S,Sstar)));
            maxSintSnGHTP(oneNoiseLvl) = max(maxSintSnGHTP(oneNoiseLvl), length(intersect(S,Sstar)));
            avgRelErrorGHTP(oneNoiseLvl) = avgRelErrorGHTP(oneNoiseLvl) + norm(x-xstar);
            minRelErrorGHTP(oneNoiseLvl) = min(minRelErrorGHTP(oneNoiseLvl), norm(x-xstar));
            maxRelErrorGHTP(oneNoiseLvl) = max(maxRelErrorGHTP(oneNoiseLvl), norm(x-xstar));
            
            % Use HTP
            [xstar,Sstar,NormRes,NbIter, Ss, NormRess] = htp(y,A,sparsity,x0,MaxNbIter,0);  
            avgSintSnHTP(oneNoiseLvl) = avgSintSnHTP(oneNoiseLvl) + length(intersect(S,Sstar));
            minSintSnHTP(oneNoiseLvl) = min(minSintSnHTP(oneNoiseLvl), length(intersect(S,Sstar)));
            maxSintSnHTP(oneNoiseLvl) = max(maxSintSnHTP(oneNoiseLvl), length(intersect(S,Sstar)));
            avgRelErrorHTP(oneNoiseLvl) = avgRelErrorHTP(oneNoiseLvl) + norm(x-xstar);
            minRelErrorHTP(oneNoiseLvl) = min(minRelErrorHTP(oneNoiseLvl), norm(x-xstar));
            maxRelErrorHTP(oneNoiseLvl) = max(maxRelErrorHTP(oneNoiseLvl), norm(x-xstar));
            
            % Use OMP
            [xstar,Sstar,NormRes,NbIter, Ss, NormRess] = omp_gt(y, A, x, find(x0 ~=0), MaxNbIter, tolSuccess, verbose); 
            avgSintSnOMP(oneNoiseLvl) = avgSintSnOMP(oneNoiseLvl) + length(intersect(S,Sstar));
            minSintSnOMP(oneNoiseLvl) = min(minSintSnOMP(oneNoiseLvl), length(intersect(S,Sstar)));
            maxSintSnOMP(oneNoiseLvl) = max(maxSintSnOMP(oneNoiseLvl), length(intersect(S,Sstar)));
            avgRelErrorOMP(oneNoiseLvl) = avgRelErrorOMP(oneNoiseLvl) + norm(x-xstar);
            minRelErrorOMP(oneNoiseLvl) = min(minRelErrorOMP(oneNoiseLvl), norm(x-xstar));
            maxRelErrorOMP(oneNoiseLvl) = max(maxRelErrorOMP(oneNoiseLvl), norm(x-xstar));

        end;
            
        
    end; % Generate new random matrix
    
    save(fname);
    
end;

%% Plots
avgSintSnHTP = avgSintSnHTP/totTests;
avgSintSnGHTP = avgSintSnGHTP/totTests;

avgRelErrorHTP = avgRelErrorHTP/norm(x)/totTests;
avgRelErrorGHTP = avgRelErrorGHTP/norm(x)/totTests;

figure; plot(noises, avgRelErrorHTP); legend('Avg Rel Error - HTP')
figure; plot(noises, avgRelErrorGHTP); legend('Avg Rel Error - GHTP')
figure; plot(noises,avgSintSnHTP); legend('S \cap Sn - HTP')
figure; plot(noises,avgSintSnGHTP); legend('S \cap Sn - GHTP')
