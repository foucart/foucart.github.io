%%
% L1Sat.m
% Computes an L1-minimizer subject to saturated measurement constraints
% by solving the linear optimization program proposed in
% "Sparse recovery from saturated measurements"
% by S. Foucart and Tom Needham

% Usage: xstar = L1Sat(y,A,mu)
%
% y: mx1 vector of saturated measurements 
% A: mXN measurement matrix
% mu: the saturation paramater
%
% xstar: NX1 vector minimizing ||z||_1 subject to S(Az)=y
%
% Written by Simon Foucart in February 2016
% Last updated in February 2016
% Send comments to simon.foucart@centraliens.net


function xstar = L1Sat(y,A,mu)

[m,N] = size(A);
Inonsat = find( abs(y) < mu );
Ipossat = find( y >= +mu );
Inegsat = find( y <= -mu );

cvx_quiet true;
cvx_begin

variable z(N);
variable c(N);

minimize sum(c)

subject to
c - z >= 0;
c + z >= 0;
A(Inonsat,:)*z == y(Inonsat);
A(Ipossat,:)*z >= y(Ipossat);
A(Inegsat,:)*z <= y(Inegsat);

cvx_end

xstar = z;

end