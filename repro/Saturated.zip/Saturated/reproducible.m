%% Reproducible file accompanying the manuscript
% "Sparse recovery from saturated measurements"
% by Simon Foucart and Tom Needham
% Created by S.F. in February 2016


%% The saturation function S(t)
% Throughout this script, we use the simple expression for S(t) below: 
% sign(t).*min(abs(t),mu)
% Here is its plot:

mu = 5;
t=-10:0.05:10;
figure(1);
plot(t,sign(t).*min(abs(t),mu),'LineWidth',3)
xlim([-10 10])
ylim([-8 8])
hold on
plot(t,t,'--k')


%% Recovery from saturated measurements via L1-minimization
% when the magnitude of the vector to recover varies
% Note that CVX is needed when callin the function L1Sat

N = 200; m = 80; s = 10;                                % problem sizes
mag = 0.1:0.1:4;                                        % range of magnitudes
nTests = 10;                                            % number of test vectors
mu1 = 1; sigma1 = 1;                                    % first set of parameters
mu2 = 1/2; sigma2 = 1;                                  % second set of parameters
mu3 = 1; sigma3 = 1/2;                                  % third set of parameters
errors1 = zeros(nTests,length(mag));                    % to hold the recovery errors
errors2 = zeros(nTests,length(mag));
errors3 = zeros(nTests,length(mag));
for n = 1:nTests
    A = randn(m,N);                                     % measurement matrices
    A1 = sigma1*A;
    A2 = sigma2*A;
    A3 = sigma3*A;
    perm = randperm(N); S = sort(perm(1:s));            % support of vector to recover
    x_aux = zeros(N,1); x_aux(S) = randn(s,1);          % auxiliary vector
    x_dir = x_aux/norm(x_aux);                          % vector to recover (direction)
    for k = 1:length(mag)
        x = mag(k)*x_dir;                               % vector to recover (magnitude)
        y1 = sign(A1*x).*min(abs(A1*x),mu1);             % vectors of saturated mesaurements
        y2 = sign(A2*x).*min(abs(A2*x),mu2);
        y3 = sign(A3*x).*min(abs(A3*x),mu3);
        xstar1 = L1Sat(y1,A1,mu1);                      % outputs of the recovery algorithm
        xstar2 = L1Sat(y2,A2,mu2);
        xstar3 = L1Sat(y3,A3,mu3);
        errors1(n,k) = norm(x-xstar1);                  % recovery errors
        errors2(n,k) = norm(x-xstar2);
        errors3(n,k) = norm(x-xstar3);
    end
end
save('Exp.mat')

% Visualization of the reconstruction errors
figure(2);
plot(mag,sum(errors1)/nTests,'-b',mag,sum(errors2)/nTests,'--g',...
    mag,sum(errors3)/nTests,'-.r','LineWidth',3)
xlabel('Magnitude of x')
ylabel('Reconstruction error')
title(strcat('N=', num2str(N), ', m=', num2str(m), ', s=', num2str(s)))
legend(strcat('\mu=', num2str(mu1), ', \sigma=', num2str(sigma1)),...
    strcat('\mu=', num2str(mu2), ', \sigma=', num2str(sigma2)),...
    strcat('\mu=', num2str(mu3), ', \sigma=', num2str(sigma3)))

%%