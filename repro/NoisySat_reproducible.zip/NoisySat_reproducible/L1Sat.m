%% 
% Computes an approximation to a sparse vector acquired through saturated
% measurements
%
% Determines the output of the noise-cognizant L1-minimization
% for approximating an effectively sparse vector acquired through saturated
% measurments as described in the paper
% "Sparse recovery from inaccurate saturated measurements"
% by Simon Foucart and Jiangyuan Li
%
% Usage: [x_sharp,e_sharp] = L1Sat(y_sat,A,mu,eta,gamma_z,gamma_w)
%
% y: mx1 vector of saturated measurements in [-mu,+mu]
% A: mxN measurement matrix
% mu: positive number representing the threshold determining the saturation process
% eta: positive number (over)estimating the magnitude of the presaturation error
% gamma_z: positive number imposing a constraint on the norm of the recovered vector
% gamma_w: positive number imposing a constraint on the norm of the recovered error
% (optional: default=0, corresponding to the noise-igonring L1-minimization)
%
% x_sharp: Nx1 vector approximating the original sparse vector
% e_sharp: mx1 vector representing the recovered presaturation error

% Written by S. Foucart and J. Li in August 2017
% Send comments to simon.foucart@centraliens.net

function [x_sharp,e_sharp] = L1Sat(y_sat,A,mu,eta,gamma_z,gamma_w)

[m,N] = size(A);
Inonsat = find( abs(y_sat) < mu );
Ipossat = find( y_sat >= +mu );
Inegsat = find( y_sat <= -mu );

if nargin < 6
    
    cvx_begin
    
    variable z(N);
    variable c(N);
    
    minimize sum(c)
    
    subject to
    c - z >= 0;
    c + z >= 0;
    A(Inonsat,:)*z == y_sat(Inonsat);
    A(Ipossat,:)*z >= +mu;
    A(Inegsat,:)*z <= -mu;
    norm(z) <= gamma_z*mu*sqrt(m);
    
    cvx_end
    
    x_sharp = z;
    e_sharp = zeros(m,1);
    
else
    
    cvx_begin
    
    variable z(N);
    variable c(N);
    variable w(m);
    
    minimize sum(c)
    
    subject to
    c - z >= 0;
    c + z >= 0;
    A(Inonsat,:)*z + w(Inonsat) == y_sat(Inonsat);
    A(Ipossat,:)*z + w(Ipossat) >= +mu;
    A(Inegsat,:)*z + w(Inegsat) <= -mu;
    norm(z) <= gamma_z*mu*sqrt(m);
    norm(w) <= gamma_w*eta;
    
    cvx_end
    
    x_sharp = z;
    e_sharp = w;
    
end

end