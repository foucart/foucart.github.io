%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Reproducible file for the article [1]
% "Sparse recovery from inaccurate saturated measurements"
% by Simon Foucart and Jiangyuan Li
% Created by S. Foucart and J. Li in August 2017
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% CVX [2] is needed to run all the experiments in this reproducible
% the following command prevents screen displays from CVX
cvx_quiet true
% to chose a specific solver, select one of the following commands
% cvx_solver gurobi
% cvx_solver mosek
% cvx_solver sdpt3
% cvx_solver sedumi
% if none is selected, then the default will be sdpt3

%%
%% Experiment 1: Influence of the magnitude of the measurement error
clc; clearvars -except cvx_quiet cvx_solver

N = 200; m = 80; s = 5;        % problem sizes
mu = 1;                        % value of the saturation threshold
gamma_z = 10;                  % first parameter in the recovery procedure
gamma_w = 2;                   % second parameter in the recovery procedure
mag = 0.3:0.3:15;              % range of magnitudes of vectors to be recovered
eta = [0.01, 0.03, 0.1, 0.3];  % (over)estimates for the magnitudes of presaturation errors
errors = cell(length(eta),1);  % cell to hold the recovery errors
nTests = 50;                   % number of random sparse vectors to recover

for i=1:length(eta)
    errors{i} = zeros(nTests,length(mag));  % matrix holding recovery errors
    for n = 1:nTests
        % creation of the sparse vector to be recovered
        S = sort(randperm(N,s));                % support of the sparse vector
        x = zeros(N,1); x(S) = randn(s,1);
        x = x/norm(x);                          % direction of the sparse vector
        % creation of the measurement matrix
        A = randn(m,N)/sqrt(m);
        for k = 1:length(mag)
            % sparse vector to recover, with varying magnitude
            xk = mag(k)*x;
            % presaturation error, properly normalized
            ek = randn(m,1);
            ek = eta(i)*ek/norm(ek)/2;
            % measurement vector before and after saturation
            yk = A*xk + ek;
            yk_sat = sign(yk).*min(abs(yk),mu);
            % output of noise-cognizant minimization
            xksharp = L1Sat(yk_sat,A,mu,eta(i),gamma_z,gamma_w);
            errors{i}(n,k) = norm(xk-xksharp);
        end
    end
end
save('Exp1.mat')

%% Visualization of the results of Experiment 1

try load('Exp1.mat')
catch
    load('Exp1_default.mat')
end

figure(1)
plot(mag,sum(errors{4})/nTests,'y',...
    mag,sum(errors{3})/nTests,'g',...
    mag,sum(errors{2})/nTests,'b',...
    mag,sum(errors{1})/nTests,'r',...
    'LineWidth',2)
xlabel('\xi','FontSize',22)
ylabel('\epsilon','FontSize',22)
title(strcat('N=',num2str(N),', m=', num2str(m),', s=', num2str(s),', \mu=',num2str(mu),...
    ', \gamma=', num2str(gamma_w), ', \gamma', 39,'=', num2str(gamma_z),...
    '\newline', '  (average over ', 32, num2str(nTests), ' random tests)'),'FontSize',16)
legend({strcat('\eta=',num2str(eta(4))),...
    strcat('\eta=',num2str(eta(3))),...
    strcat('\eta=',num2str(eta(2))),...
    strcat('\eta=',num2str(eta(1)))},...
    'Location', 'northwest','FontSize',18)


%% Experiment 2: Influence of the parameters of the L1-minimization
clc; clearvars -except cvx_quiet cvx_solver

N = 200; m = 80; s = 5;        % problem sizes
mu = 1;                        % value of the saturation threshold
gamma_w = 1:0.05:3;            % range for the first parameter
gamma_z = 5:0.5:15;            % range for the second parameter

% pick a sparse vector x1 in the small magnitude regime
S1 = sort(randperm(N,s));
x1 = zeros(N,1); x1(S1) = randn(s,1);
x1 = 5*x1/norm(x1);
% pick a sparse vector x2 in the intermediate magnitude regime
S2 = sort(randperm(N,s));
x2 = zeros(N,1); x2(S2) = randn(s,1);
x2 = 13*x2/norm(x2);

% create the measurement matrix
A = randn(m,N)/sqrt(m);
% create presaturation errors
eta = 0.2;
e1 = randn(m,1); e1 = eta*e1/norm(e1)/2;
e2 = randn(m,1); e2 = eta*e2/norm(e2)/2;
% measurement vectors before and after saturation
y1 = A*x1 + e1;
y1_sat = sign(y1).*min(abs(y1),mu);
y2 = A*x2 + e2;
y2_sat = sign(y2).*min(abs(y2),mu);
% recovery of the two sparse vectors
errors1 = zeros(length(gamma_z),length(gamma_w));
errors2 = zeros(length(gamma_z),length(gamma_w));
for i=1:length(gamma_z)
    for j=1:length(gamma_w)
        gz = gamma_z(i);
        gw = gamma_w(j);
        x1sharp = L1Sat(y1_sat,A,mu,eta,gz,gw);
        x2sharp = L1Sat(y2_sat,A,mu,eta,gz,gw);
        errors1(i,j) = norm(x1-x1sharp)/norm(x1);
        errors2(i,j) = norm(x2-x2sharp)/norm(x2);
    end
end
save('Exp2.mat')

%% Visualization of the results of Experiment 2

try load('Exp2.mat')
catch
    load('Exp2_default.mat')
end

figure(2)
mesh(gamma_w,gamma_z,errors1)
xlabel('\gamma','FontSize',22)
ylabel(strcat('\gamma',39),'FontSize',22)
zlabel('\epsilon','FontSize',22)
title(strcat('N=',num2str(N),', m=', num2str(m),', s=', num2str(s),...
    ', \mu=',num2str(mu),', \eta=',num2str(eta),', \xi=',num2str(norm(x1,2))),...
    'FontSize',22)
figure(3)
mesh(gamma_w,gamma_z,errors2)
xlabel('\gamma','FontSize',22)
ylabel(strcat('\gamma',39),'FontSize',22)
zlabel('\epsilon','FontSize',22)
title(strcat('N=',num2str(N),', m=', num2str(m),', s=', num2str(s),...
    ', \mu=',num2str(mu),', \eta=',num2str(eta),', \xi=',num2str(norm(x2,2))),...
    'FontSize',22)


%% Experiment 3: Comparing noise-cognizant and noise-ignoring L1-minimizations
clc; clearvars -except cvx_quiet cvx_solver

N = 200; m = 80; s = 5;        % problem sizes
mu = 1;                        % value of the saturation threshold
gamma_z = 10;                  % first parameter in the recovery procedure
gamma_w = 2;                   % second parameter in the recovery procedure
mag = 0.3:0.3:15;              % range of magnitudes of vectors to be recovered
eta = 0.03;                    % (over)estimate for the magnitude of presaturation error
nTests = 50;                   % number of random vectors to recover


errors_nc = zeros(nTests,length(mag));  % matrix holding noise-cognizant recovery errors 
errors_ni = zeros(nTests,length(mag));  % matrix holding noise-ignoring recovery errors
times_nc = zeros(nTests,length(mag));   % matrix holding noise-cognizant recovery times 
times_ni = zeros(nTests,length(mag));   % matrix holding noise-ignoring recovery times

for n = 1:nTests
    % creation of the sparse vector to be recovered
    S = sort(randperm(N,s));
    x = zeros(N,1); x(S) = randn(s,1);
    x = x/norm(x);
    % creation of the measurement matrix
    A = randn(m,N)/sqrt(m);
    for k = 1:length(mag)
        % sparse vector to recover, with varying magnitude
        xk = mag(k)*x;
        % presaturation error, properly normalized
        ek = randn(m,1);
        ek = eta*ek/norm(ek)/2;
        % measurement vector before and after saturation
        yk = A*xk + ek;
        yk_sat = sign(yk).*min(abs(yk),mu);
        % output of noise-cognizant and noise-ignoring minimizations
        tic;
        xk_nc = L1Sat(yk_sat,A,mu,eta,gamma_z,gamma_w);
        times_nc(n,k) = toc;
        errors_nc(n,k) = norm(xk-xk_nc);
        tic;
        xk_ni = L1Sat(yk_sat,A,mu,eta,gamma_z);
        times_ni(n,k) = toc;
        errors_ni(n,k) = norm(xk-xk_ni);
    end
end
save('Exp3.mat')

%% Visualization of the results of Experiment 3

try load('Exp3.mat')
catch
    load('Exp3_default.mat')
end

figure(4)
plot(mag,sum(errors_nc)/nTests,'b',...
    mag,sum(errors_ni)/nTests,'k',...
    'LineWidth',2)
xlabel('\xi','FontSize',22)
ylabel('\epsilon','FontSize',22)
title(strcat('N=',num2str(N),', m=', num2str(m),', s=', num2str(s),', \mu=',num2str(mu),...
    ', \gamma=', num2str(gamma_w), ', \gamma', 39,'=', num2str(gamma_z),' ,\eta=',num2str(eta),...
    '\newline','        (average over ', 32, num2str(nTests), ' random tests)'),'FontSize',16)
legend({strcat('noise-cognizant (time=',num2str(sum(sum(times_nc))/60,'%4.2f'),' min)'),...
    strcat('noise-ignoring   (time=',num2str(sum(sum(times_ni))/60,'%4.2f'),' min')},...
    'Location', 'northwest','FontSize',18)


%%
%% References
%
% [1] S. Foucart and J. Li.
% Sparse recovery from inaccurate saturated measurements.
% Preprint.
%
% [2] CVX Research, Inc.
% CVX: matlab software for disciplined convex programming, version 2.1.
% http://cvxr.com/cvx, 2014.

