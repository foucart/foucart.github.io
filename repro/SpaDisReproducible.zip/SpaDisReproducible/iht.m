% iht  runs the Iterative Hard Thresholding
%
% Usage: [x,S,normRes,nIter] = iht(y,A,s,x0,maxnIter,tolRes)
%
% y: the measurement vector
% A: the measurement matrix 
% s: the sparsity parameter
% x0: initial vector (optional, default=0)
% maxnIter: number of iterations not to be exceeded (optional, default=500)
% tolRes: threshold for the L2-norm of the residual to stop the algorithm (optional, default=1e-4)
%
% x: column vector
% S: support of x
% normRes: the norm of the residual
% nbIter: the number of performed iterations
%
% SF and MFM (created 27 May 2012, modified 9 Sept 2014)

function [x,S,normRes,nIter] = iht(y,A,s,x0,maxnIter,tolRes)

[~,N]=size(A);
if nargin < 6
   tolRes = 1e-4; 
end
if nargin < 5
   maxnIter = 500;
end
if nargin < 4
   x0=zeros(N,1); 
end

x = x0;
res = y-A*x;
normRes = norm(res);
nIter=0;

while ( nIter < maxnIter && normRes > tolRes )
    u = x+A'*res;
    [~,sorted_idx] = sort(abs(u),'descend');
    S = sorted_idx(1:s);
    x=zeros(N,1); x(S)=u(S);
    res = y-A*x;
    normRes=norm(res);
    nIter = nIter+1;
end

end