%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This file contains the reproducible experiments accompanying the article
% SPARSE DISJOINTED RECOVERY FROM NONINFLATING MEASUREMENTS
% by Foucart, Minner, and Needham
% Created 3 Sept 2014
% Last modified 12 Sept 2014
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Experiment 1
% finding best s-sparse d-disjointed approximations
x = [1; 0; 1; 2^(1/4); 1; 0; 2^(-1/2)];
s = 3; d = 1;
% best approximation in the 2-norm --- note that it does not contain the
% largest absolute entry of x 
[z2,S2,error2] = baSpaDis(x,s,d,2); 
z2 = z2'
% best approximation in the 4-norm --- note that it is different from the
% best approximation in the 2-norm
[z4,S4,error4] = baSpaDis(x,s,d,4); 
z4 = z4'

%% Experiment 2 
% recovery of a single sparse disjointed via iterative thresholding algorithms

% set the paramaters for the experiments
N = 1000; m = 200; s = 12; d = 65;
% create a sparse disjointed vector
rng(6)  % specify the random number generator to always produce the same experiment 
suppCollapsed = sort(randsample(N-d*(s-1),s));
supp = suppCollapsed + d*(0:s-1)';
x = zeros(N,1);
x(supp) = randn(s,1);
% define the measurement matrix and the measurement vector
A = randn(m,N)/sqrt(m);
y = A*x;
% recover using classical IHT
xiht = iht(y,A,s);
recoveryErrorIHT = norm(x-xiht)
% recover using IHT adapted to the sparse disjointed case
xihtSpaDis = ihtSpaDis(y,A,s,d);
recoveryErrorIHTSpaDis = norm(x-xihtSpaDis)
% visualize the recovered vectors versus the original vector
figure(1)
subplot(1,2,1)
plot(1:N,x,'b*',1:N,xiht,'ro')
legend('Original vector','Recovered vector')
title('Classical IHT')
subplot(1,2,2)
plot(1:N,x,'b*',1:N,xihtSpaDis,'ro')
legend('Original vector','Recovered vector')
title('IHT adapted to the sparse disjointed case')

%% Experiment 3
% percentage of recovery success via iterative thresholding algorithms

% set the paramaters for the experiments (two values of d are considered)
nTests = 100;
N = 1000; m = 200; 
d1 = 10; d2 = 20;
smin = 1; smax = 20; 
recoveryErrorsIHT1 = nan(nTests,smax-smin+1);
recoveryErrorsIHT2 = nan(nTests,smax-smin+1);
recoveryErrorsIHTSpaDis1 = nan(nTests,smax-smin+1);
recoveryErrorsIHTSpaDis2 = nan(nTests,smax-smin+1);
tic;
for n=1:nTests
   n
   for s = smin:smax
      % create sparse disjointed vectors
      suppCollapsed = sort(randsample(N-d1*(s-1),s));
      supp = suppCollapsed + d1*(0:s-1)';
      x1 = zeros(N,1);
      x1(supp) = randn(s,1);
      suppCollapsed = sort(randsample(N-d2*(s-1),s));
      supp = suppCollapsed + d2*(0:s-1)';
      x2 = zeros(N,1);
      x2(supp) = randn(s,1);
      % define the measurement matrix and the measurement vector
      A = randn(m,N)/sqrt(m);
      y1 = A*x1;
      y2 = A*x2;
      % recover using classical IHT
      x1iht = iht(y1,A,s);
      recoveryErrorsIHT1(n,s-smin+1) = norm(x1-x1iht);
      x2iht = iht(y2,A,s);
      recoveryErrorsIHT2(n,s-smin+1) = norm(x2-x2iht);
      % recover using IHT adapted to the sparse disjointed case
      x1ihtSpaDis = ihtSpaDis(y1,A,s,d1);
      recoveryErrorsIHTSpaDis1(n,s-smin+1) = norm(x1-x1ihtSpaDis);
      x2ihtSpaDis = ihtSpaDis(y2,A,s,d2);
      recoveryErrorsIHTSpaDis2(n,s-smin+1) = norm(x2-x2ihtSpaDis);
   end
end
timeExp3 = toc;
% percentage of recovery success
tol = 1e-3;
percentageSuccessIHT1 = 100* sum( recoveryErrorsIHT1 < tol ) / nTests ;
percentageSuccessIHT2 = 100* sum( recoveryErrorsIHT2 < tol ) / nTests ;
percentageSuccessIHTSpaDis1 = 100* sum( recoveryErrorsIHTSpaDis1 < tol ) / nTests ;
percentageSuccessIHTSpaDis2 = 100* sum( recoveryErrorsIHTSpaDis2 < tol ) / nTests ;
save('Exp3.mat')

%% visualization of the results
try load('Exp3.mat')
catch
    load('Exp3_default.mat')
end
figure(2)
% success of IHT and IHTSpaDis for d=d1
subplot(1,2,1)
plot(smin:smax,percentageSuccessIHT1,'b',smin:smax,percentageSuccessIHTSpaDis1,'g')
legend('Classical IHT',['IHT adapted' 10 'to the sparse' 10 'disjointed case'],...
   'Location', 'SouthWest')
title(strcat('Percentage of successful recoveries for d=',num2str(d1)))
xlabel('sparsity level s')
ylabel('percentage of successful recoveries')
% success of IHT and IHTSpaDis for d=d2
subplot(1,2,2)
plot(smin:smax,percentageSuccessIHT2,'b',smin:smax,percentageSuccessIHTSpaDis2,'g')
legend('Classical IHT',['IHT adapted' 10 'to the sparse' 10 'disjointed case'],...
   'Location', 'SouthWest')
title(strcat('Percentage of successful recoveries for d=',num2str(d2)))
xlabel('sparsity level s')
ylabel('percentage of successful recoveries')
