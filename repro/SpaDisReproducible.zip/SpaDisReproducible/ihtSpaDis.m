% ihtSpaDis  runs the Sparse Disjointed Iterative Hard Thresholding
%
% Usage: [x,S,normRes,nIter] = ihtSpaDis(y,A,s,d,x0,maxnIter,tolRes)
%
% y: the measurement vector
% A: the measurement matrix 
% s: the sparsity parameter
% d: the disjointness parameter
% x0: initial vector (optional, default=0)
% maxnIter: number of iterations not to be exceeded (optional, default=500)
% tolRes: threshold for the L2-norm of the residual to stop the algorithm (optional, default=1e-4)
%
% x: column vector
% S: support of x
% normRes: the norm of the residual
% nbIter: the number of performed iterations
%
% SF and MFM (created 3 Sept 2014, modified 12 Sept 2014)

function [x,S,normRes,nIter] = ihtSpaDis(y,A,s,d,x0,maxnIter,tolRes)

[~,N]=size(A);
if nargin < 7
   tolRes = 1e-4; 
end
if nargin < 6
   maxnIter = 500;
end
if nargin < 5
   x0=zeros(N,1); 
end

x = x0;
res = y-A*x;
normRes = norm(res);
nIter=0;

while ( nIter < maxnIter && normRes > tolRes )
    u = x+A'*res;
    x = baSpaDis(u,s,d);
    res = y-A*x;
    normRes=norm(res);
    nIter = nIter+1;
end

if nIter == maxnIter
    fprintf('Maximum number of iterations reached \n')
end

if normRes <= tolRes
    fprintf('Tolerance on the norm of the residual reached \n')
end

end