% baSpaDis  Computes best sparse disjointed approximations by dynamic programming
%
% Finds the best approximation to a vector x 
% by an s-sparse d-disjointed vector in the p-norm,
% i.e., the minimizer z of norm(x,z,p)
% subject to z is s-sparse d-disjointed
%
% Usage: [z,S,error] = baSpaDis(x,s,d,p)
%
% x: the vector to be approximated
% s: the sparsity level
% d: the disjointness parameter
% p: the exponent of the norm (optional, default=2)
%
% z: the best s-sparse d-disjointed approximation
% S: the support of the best approximation
% error: the error of best approximation, i.e., norm(x-z,p)

% Written by Simon Foucart and Michael Minner
% Send comments to simon.foucart@centraliens.net

function [z,S,error] = baSpaDis(x,s,d,p)

if nargin < 4
   p=2;
end

N = length(x);
absxp = abs(x).^p;
values = nan(N,s+1);
pointers = nan(N,s+1);

% initialize of the table of values
% first column
values(:,1) = cumsum(absxp);
% first d+1 rows
for n=1:d+1
   values(n,2:s+1) = (sum(absxp(1:n))-max(absxp(1:n))) * ones(1,s);
end

% fill in the table of values, row by row
for n=d+2:N
   for rr=2:s+1   %rr represents r+1
      val1 = values(n-1,rr)+absxp(n);
      val2 = values(n-d-1,rr-1)+sum(absxp(n-d:n-1));
      if val1 < val2
         values(n,rr) = val1;
         pointers(n,rr) = 0;   % "0" means that the arrow points north
      else
         values(n,rr) = val2;
         pointers(n,rr) = 1;   % "1" means that the arrow points northeast
      end
   end
end

% return the error of best approximation
error = values(N,s+1)^(1/p);

% construct the support by backtracking
n = N;
rr = s+1;
S = [];
while ( n > d+1 && rr > 1 ) 
   if pointers(n,rr) == 0
      n = n-1;
   else 
      S = [n,S]; % where is the right place?
      n = n-d-1;
      rr = rr-1; 
   end
end
if rr > 1
   [~,j] = max(absxp(1:n));
   S = [j,S];
end

% return the best approximation
z = zeros(N,1);
z(S) = x(S);

end