%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Reproducible file accompanying the paper
% ITERATIVE HARD THRESHOLDING FOR LOW-RANK RECOVERY FROM
% RANK-ONE PROJECTIONS
% by S. Foucart and S. Subramanian
% Written by S. Subramanian and S. Foucart in April 2018
% Modified in October 2018
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% CVX [2] is needed to perform nuclear norm minimizations


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Experiment 1: Influence of the parameters s and t

clear all; clc;

% define the problem sizes
N1 = 20;
N2 = 20;
r = 3;
m = 5*r*max(N1,N2);

% set numbers of random trials, success tolerance, matrix to store results
n_Meas = 10;    % number of rank-one projections
n_Matr = 10;    % number of low-rank matrices per rank-one projection
tol_suc = 1e-3;
f = floor(min(N1,N2)/r);
Res = zeros(f,f);

tic;
for meas = 1:n_Meas
    % tracks experiment progress
    fprintf('Number of measurement schemes tested = %d \n',meas-1);
    % define rank-one projections via A=[a_1|...|a_m] and B=[b_1|...|b_m]
    A = randn(N1,m)/sqrt(m);
    B = randn(N2,m)/sqrt(m);
    for matr = 1:n_Matr
        % the low-rank matrix to be recovered
        X = randn(N1,r)*randn(r,N2);
        % its measurement vector
        y = sum(A.*(X*B))';
        for s_over_r = 1:f
            for t_over_r = 1:f
                % tracks experiment progress
                fprintf('s/r=%d, t/r=%d \n', s_over_r, t_over_r);
                % reconstruction by modified IHT
                X_MIHT = MIHT(A,B,y,r,s_over_r,t_over_r);
                % record success if relative error smaller than tolerance
                Res(s_over_r,t_over_r) = Res(s_over_r,t_over_r) + ...
                    ( norm(X-X_MIHT,'fro') < tol_suc*norm(X,'fro') );
            end
        end
    end
end
t1 = toc;

save('Exp1.mat')


%% Visualization of the results of Experiment 1

try load('Exp1.mat')
catch
    load('Exp1_default.mat')
end

figure
surf(Res'/n_Meas/n_Matr,'FaceAlpha',0.5);
xlabel('s/r ','FontSize',22);
ylabel('t/r','FontSize',22);
zlabel('Frequency of success','FontSize',22);
title(strcat('Recovery success (averaged over', 32, num2str(n_Meas*n_Matr),' trials)',...
    '\newline','N_1=',num2str(N1), ', N_2=',num2str(N2), ', r=',num2str(r), ', m=',num2str(m)),'FontSize',16);


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Experiment 2: Performance comparison for several algorithms

clear all; clc;
cvx_quiet true

% define the problem sizes
dim_min = 30;                          % minimal dimension to be tested 
dim_max = 40;                          % maximal dimension to be tested
dim_inc = 10;                          % increment for the dimension
n_dim = floor((dim_max-dim_min)/dim_inc) + 1; % number of dimensions tested
rk_min = 2;                            % minimal rank to be tested
rk_max = 3;                            % maximal rank to be tested
rk_inc = 1;                            % increment for the rank
n_rk = floor((rk_max-rk_min)/rk_inc) + 1;     % number of ranks tested

% set numbers of random trials, success tolerance
n_Meas = 10;        % number of rank-one projections
n_Matr = 5;        % number of low-rank matrices per rank-one projection
tol_suc = 1e-3;

tic;
for i = 1:n_dim
    N = dim_min + (i-1)*dim_inc;
    N1 = N; N2 = N;
    for j = 1:n_rk
        r = rk_min + (j-1)*rk_inc;
        % define numbers of measurements
        m_inc = 4;
        m_min = 2*r*N;
        m_max = 7*r*N;
        n_m = floor((m_max-m_min)/m_inc) + 1;
        m_range{i,j} = m_min:m_inc:m_max;
        Res_MIHT_def{i,j} = zeros(1,n_m);
        Res_MIHT_2r{i,j} = zeros(1,n_m);
        Res_NIHT{i,j} = zeros(1,n_m);
        Res_NNM{i,j} = zeros(1,n_m);
        for k = 1:n_m
            m = m_min + (k-1)*m_inc;
            % tracks experiment progress 
            fprintf('Test with N=%d, r=%d, and m=%d (start: m=%d, end: m=%d) \n',...
                N, r, m, m_min, m_max);
            for meas = 1:n_Meas
                % define rank-one projections via A=[a_1|...|a_m] and B=[b_1|...|b_m]
                A = randn(N1,m)/sqrt(m);
                B = randn(N2,m)/sqrt(m);
                for matr = 1:n_Matr
                    % the low-rank matrix to be recovered
                    X = randn(N1,r)*randn(r,N2);
                    norm_X = norm(X,'fro');
                    % its measurement vector
                    y = sum(A.*(X*B))';
                    % perform the reconstructions
                    X_MIHT_def = MIHT(A,B,y,r);
                    X_MIHT_2r = MIHT(A,B,y,r,[],2);
                    X_NIHT = NIHT(A,B,y,r);
                    X_NNM = NNM(A,B,y);
                    % success if relative error smaller than tolerance
                    Res_MIHT_def{i,j}(k) = Res_MIHT_def{i,j}(k) + ...
                        ( norm(X-X_MIHT_def,'fro') < tol_suc*norm_X );
                    Res_MIHT_2r{i,j}(k) = Res_MIHT_2r{i,j}(k) + ...
                        ( norm(X-X_MIHT_2r,'fro') < tol_suc*norm_X );
                    Res_NIHT{i,j}(k) = Res_NIHT{i,j}(k) + ...
                        ( norm(X-X_NIHT,'fro') < tol_suc*norm_X );
                    Res_NNM{i,j}(k) = Res_NNM{i,j}(k) + ...
                        ( norm(X-X_NNM,'fro') < tol_suc*norm_X );
                end
            end
        end    
    end
end
t2 = toc;

save('Exp2.mat')


%%  Visualization of the results of Experiment 2

try load('Exp2.mat')
catch
    load('Exp2_default.mat')
end

% plot figures for each test
for i = 1:n_dim
    N = dim_min + (i-1)*dim_inc;
    for j = 1:n_rk
        r = rk_min + (j-1)*rk_inc;
        figure
        plot(m_range{i,j},Res_NNM{i,j}/n_Meas/n_Matr,'k:x',...
            m_range{i,j},Res_MIHT_2r{i,j}/n_Meas/n_Matr,'b--o',...
            m_range{i,j},Res_MIHT_def{i,j}/n_Meas/n_Matr,'r-d',...
            m_range{i,j},Res_NIHT{i,j}/n_Meas/n_Matr,'g-.+');
        legend('NNM','MIHT (t=2r)','MIHT (default)','NIHT','Location','southeast');
        title(strcat('Recovery success (averaged over', 32, num2str(n_Meas*n_Matr),' trials)',...
            '\newline','N_1=',num2str(N), ', N_2=',num2str(N), ...
            ', r=',num2str(r)),'FontSize',16);
    xlabel('Number of measurements (m)','FontSize',22);
    ylabel('Frequency of success','FontSize',22); 
    end
end


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Experiment 3: Speed comparison for several algorithms

clear all; clc;
cvx_quiet true

% define the problem sizes
dim_min = [22 40];                  % minimal dimensions to be tested
dim_max = [50 70];                  % maximal dimensions to be tested
dim_inc = [1  1];                   % increments in the dimension 
rk_min = 2;                         % minimal rank to be teste
rk_max = 3;                         % maximal rank to be tested
rk_inc = 1;                         % increment in the rank
n_rk = floor((rk_max-rk_min)/rk_inc) + 1;  % number of ranks tested
 
%
n_Meas = 10;                         % number of rank-one projections
n_Matr = 5;                         % number of low-rank matrices per rank-one projection
tol_suc = 1e-3;

for i = 1:n_rk
    r = rk_min + (i-1)*rk_inc;
    for j = 1:size(dim_min,2)
        N_range{i,j} = dim_min(j):dim_inc(j):dim_max(j);
        L = length(N_range{i,j});
        % Tables to hold results for each {i,j}
        Time_MIHT_def{i,j} = zeros(1,L);
        Time_MIHT_2r{i,j} = zeros(1,L);
        Time_NIHT{i,j} = zeros(1,L);
        Time_NNM{i,j} = zeros(1,L);
        Iter_MIHT_def{i,j} = zeros(1,L);
        Iter_MIHT_2r{i,j} = zeros(1,L);
        Iter_NIHT{i,j} = zeros(1,L);
        for k = 1:L
            N = N_range{i,j}(k);
            % tracks experiment progress
            fprintf('Test with r=%d and N=%d (start: N=%d, end: N=%d) \n',...
                r, N, dim_min(j), dim_max(j));
            N1 = N; N2 = N;
            c = 7;
            m = c*r*N;   % to enforce a regime of successful recovery
            for meas = 1:n_Meas
                % define rank-one projections via A=[a_1|...|a_m] and B=[b_1|...|b_m]
                A = randn(N1,m)/sqrt(m);
                B = randn(N2,m)/sqrt(m);
                for matr = 1:n_Matr
                    % the low-rank matrix to be recovered
                    X = randn(N1,r)*randn(r,N2);
                    norm_X = norm(X,'fro');
                    % its measurement vector
                    y = sum(A.*(X*B))';
                    % perform the reconstructions 
                    % add times and iterations only if successful
                    tic; 
                    [X_MIHT_def,n_MIHT_def] = MIHT(A,B,y,r); 
                    t_MIHT_def = toc;
                    suc = ( norm(X-X_MIHT_def,'fro') < tol_suc*norm_X );
                    Time_MIHT_def{i,j}(k) = Time_MIHT_def{i,j}(k) + t_MIHT_def*suc;
                    Iter_MIHT_def{i,j}(k) = Iter_MIHT_def{i,j}(k) + n_MIHT_def*suc;
                    tic;
                    [X_MIHT_2r,n_MIHT_2r] = MIHT(A,B,y,r,[],2);
                    t_MIHT_2r = toc;
                    suc = ( norm(X-X_MIHT_2r,'fro') < tol_suc*norm_X );
                    Time_MIHT_2r{i,j}(k) = Time_MIHT_2r{i,j}(k) + t_MIHT_2r*suc;
                    Iter_MIHT_2r{i,j}(k) = Iter_MIHT_2r{i,j}(k) + n_MIHT_2r*suc;
                    tic;
                    [X_NIHT,n_NIHT] = NIHT(A,B,y,r);
                    t_NIHT = toc;
                    suc = ( norm(X-X_NIHT,'fro') < tol_suc*norm_X );
                    Time_NIHT{i,j}(k) = Time_NIHT{i,j}(k) + t_NIHT*suc;
                    Iter_NIHT{i,j}(k) = Iter_NIHT{i,j}(k) + n_NIHT*suc;
                    tic;
                    X_NNM = NNM(A,B,y);
                    t_NNM = toc;
                    suc = ( norm(X-X_NNM,'fro') < tol_suc*norm_X );
                    Time_NNM{i,j}(k) = Time_NNM{i,j}(k) + t_NNM*suc;
                end
            end
        end
    end
end
% total reconstruction time (does not include creation of matrices, etc)
t3 = sum(sum(cellfun(@sum,Time_MIHT_def)))+...
    sum(sum(cellfun(@sum,Time_MIHT_2r)))+...
    sum(sum(cellfun(@sum,Time_NIHT)))+...
    sum(sum(cellfun(@sum,Time_NNM)));

save('Exp3.mat')


%%  Visualization of the results of Experiment 3

try load('Exp3.mat')
catch
    load('Exp3_default.mat')
end

for i = 1:n_rk
    r = rk_min + (i-1)*rk_inc;
    for j = 1:size(dim_min,2)
        % plots displaying numbers of iterations
        figure
        plot(N_range{i,j},Iter_MIHT_2r{i,j}/n_Meas/n_Matr,'b--o',...
            N_range{i,j},Iter_MIHT_def{i,j}/n_Meas/n_Matr,'r-d',...
            N_range{i,j},Iter_NIHT{i,j}/n_Meas/n_Matr,'g-.+');
        legend('MIHT (t=2r)','MIHT (default)','NIHT','Location', 'northwest');
        title(strcat(...
            'Number of iterations (averaged over ', 32, num2str(n_Meas*n_Matr),' trials)',...
            '\newline', 'r=', num2str(r), ', m =', num2str(c), 'rN'),'FontSize',16);
        xlabel('Dimension N','FontSize',22);
        ylabel('Number of iterations','FontSize',22);  
        % plots displaying execution times
        figure
        plot(N_range{i,j},Time_NNM{i,j}/n_Meas/n_Matr,'k:x',...
            N_range{i,j},Time_MIHT_2r{i,j}/n_Meas/n_Matr,'b--o',...
            N_range{i,j},Time_MIHT_def{i,j}/n_Meas/n_Matr,'r-d',...
            N_range{i,j},Time_NIHT{i,j}/n_Meas/n_Matr,'g-.+');
        legend('NNM','MIHT (t=2r)','MIHT (default)','NIHT');
        title(strcat(...
            'Execution time (averaged over ', 32, num2str(n_Meas*n_Matr),' trials)',...
            '\newline', 'r=', num2str(r), ', m =', num2str(c), 'rN'),'FontSize',16);
        xlabel('Dimension N','FontSize',22);
        ylabel('Time T (in sec)','FontSize',22);
        % plots displaying execution times again, but in logarithmic scale
        logN = log(N_range{i,j});
        logT_NNM = log(Time_NNM{i,j}/n_Meas/n_Matr);
        coefsT_NNM = polyfit(logN,logT_NNM,1);
        logT_NNM_fitted = coefsT_NNM(1)*logN + coefsT_NNM(2);
        logT_MIHT_2r = log(Time_MIHT_2r{i,j}/n_Meas/n_Matr);
        coefsT_MIHT_2r = polyfit(logN,logT_MIHT_2r,1);
        logT_MIHT_2r_fitted = coefsT_MIHT_2r(1)*logN + coefsT_MIHT_2r(2);
        logT_MIHT_def = log(Time_MIHT_def{i,j}/n_Meas/n_Matr);
        coefsT_MIHT_def = polyfit(logN,logT_MIHT_def,1);
        logT_MIHT_def_fitted = coefsT_MIHT_def(1)*logN + coefsT_MIHT_def(2);
        logT_NIHT = log(Time_NIHT{i,j}/n_Meas/n_Matr);
        coefsT_NIHT = polyfit(logN,logT_NIHT,1);
        logT_NIHT_fitted = coefsT_NIHT(1)*logN + coefsT_NIHT(2);
        figure
        plot(logN,logT_NNM,'kx',logN,logT_NNM_fitted,'k:',...
            logN,logT_MIHT_2r,'bo',logN,logT_MIHT_2r_fitted,'b--',...
            logN,logT_MIHT_def,'rd',logN,logT_MIHT_def_fitted,'r-',...
            logN,logT_NIHT,'g+',logN,logT_NIHT_fitted,'g-.');
        legend('NNM', strcat('slope=', num2str(coefsT_NNM(1),'%4.2f')),...
            'MIHT (t=2r)', strcat('slope=', num2str(coefsT_MIHT_2r(1),'%4.2f')),...
            'MIHT (default)', strcat('slope=', num2str(coefsT_MIHT_def(1),'%4.2f')),...
            'NIHT', strcat('slope=', num2str(coefsT_NIHT(1),'%4.2f')),...
            'Location', 'northwest');
        title(strcat(...
            'Execution time (averaged over ', 32, num2str(n_Meas*n_Matr),' trials)',...
            '\newline', 'r=', num2str(r), ', m =', num2str(c), 'rN'),'FontSize',16);
        xlabel('Logarithm of N','FontSize',22);
        ylabel('Logarithm of T','FontSize',22);
    end
end
   

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Experiment 4: Robustness
% Reconstruction error as a function of the L1-norm of the measurement error

clear all; clc;

% define the problem sizes
N1 = 40;
N2 = 40;
r = 3;
m = 7*r*max(N1,N2);

% prepare the loop
n_Meas = 10;
n_Matr = 5;
norme_max = 1e-1;
k_max = 20;
Err_MIHT_2r = zeros(k_max,1);
Err_MIHT_def = zeros(k_max,1);
Err_NIHT = zeros(k_max,1);

tic ;
for meas = 1:n_Meas
    % tracks experiment progress
    fprintf('Number of measurement schemes tested = %d \n',meas-1);
    A = randn(N1,m)/sqrt(m);
    B = randn(N2,m)/sqrt(m);
    for matr = 1:n_Matr
        X = randn(N1,r)*randn(r,N2);
        norm_X = norm(X,'fro');
        for k=1:k_max
            norme = (k/k_max)*norme_max;
            e = randn(m,1);
            e = norme/norm(e,1)*e;
            y = sum(A.*(X*B))' + e;
            X_MIHT_2r = MIHT(A,B,y,r,[],2); 
            e_MIHT_2r = norm(X-X_MIHT_2r,'fro')/norm_X;
            Err_MIHT_2r(k) = Err_MIHT_2r(k)+e_MIHT_2r;
            X_MIHT_def = MIHT(A,B,y,r);
            e_MIHT_def = norm(X-X_MIHT_def,'fro')/norm_X;
            Err_MIHT_def(k) = Err_MIHT_def(k)+e_MIHT_def;
            X_NIHT = NIHT(A,B,y,r); 
            e_NIHT = norm(X-X_NIHT,'fro')/norm_X;
            Err_NIHT(k) = Err_NIHT(k)+e_NIHT;
        end
    end 
end
Err_MIHT_2r = Err_MIHT_2r/n_Meas/n_Matr;
Err_MIHT_def = Err_MIHT_def/n_Meas/n_Matr;
Err_NIHT = Err_NIHT/n_Meas/n_Matr;

t4 = toc;
save('Exp4.mat');


%% Visualization of the results of Experiment 4

try load('Exp4.mat')
catch
    load('Exp4_default.mat')
end

figure
plot((1:k)/k_max*norme_max,Err_MIHT_2r,'b--o',...
    (1:k)/k_max*norme_max,Err_MIHT_def,'r-d',...
    (1:k)/k_max*norme_max,Err_NIHT,'g-.+');
legend('MIHT (t=2r)','MIHT (default)','NIHT','Location','NorthWest') ;
title(strcat('Recovery error (averaged over', 32,num2str(n_Meas*n_Matr),' trials)',...
    '\newline','N_1=',num2str(N1), ', N_2=',num2str(N2),', r=',num2str(r),', m=',num2str(m)),'FontSize',16);
xlabel('$\|e\|_1$','Interpreter','Latex','FontSize',22);
ylabel('$\| X-X_n \|_F$','Interpreter','Latex','FontSize',22);



%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Experiment 5: Performance comparison for several algorithms using MOSEK 
% This requires MOSEK with CVX for nuclear norm minimizations 
% Here the results are stored for N = 50, r = 2 
clear all; clc;
cvx_quiet true
cvx_solver mosek
% define the problem sizes
dim_min = 50;                          % minimal dimension to be tested 
dim_max = 50;                          % maximal dimension to be tested
dim_inc = 10;                          % increment for the dimension
n_dim = floor((dim_max-dim_min)/dim_inc) + 1; % number of dimensions tested
rk_min = 2;                            % minimal rank to be tested
rk_max = 2;                            % maximal rank to be tested
rk_inc = 1;                            % increment for the rank
n_rk = floor((rk_max-rk_min)/rk_inc) + 1;     % number of ranks tested

% set numbers of random trials, success tolerance
n_Meas = 10;        % number of rank-one projections
n_Matr = 5;        % number of low-rank matrices per rank-one projection
tol_suc = 1e-3;

tic;
for i = 1:n_dim
    N = dim_min + (i-1)*dim_inc;
    N1 = N; N2 = N;
    for j = 1:n_rk
        r = rk_min + (j-1)*rk_inc;
        % define numbers of measurements
        m_inc = 4;
        m_min = 2*r*N;
        m_max = 7*r*N;
        n_m = floor((m_max-m_min)/m_inc) + 1;
        m_range{i,j} = m_min:m_inc:m_max;
        Res_MIHT_def{i,j} = zeros(1,n_m);
        Res_MIHT_2r{i,j} = zeros(1,n_m);
        Res_NIHT{i,j} = zeros(1,n_m);
        Res_NNM{i,j} = zeros(1,n_m);
        for k = 1:n_m
            m = m_min + (k-1)*m_inc;
            % tracks experiment progress 
            fprintf('Test with N=%d, r=%d, and m=%d (start: m=%d, end: m=%d) \n',...
                N, r, m, m_min, m_max);
            for meas = 1:n_Meas
                % define rank-one projections via A=[a_1|...|a_m] and B=[b_1|...|b_m]
                A = randn(N1,m)/sqrt(m);
                B = randn(N2,m)/sqrt(m);
                for matr = 1:n_Matr
                    % the low-rank matrix to be recovered
                    X = randn(N1,r)*randn(r,N2);
                    norm_X = norm(X,'fro');
                    % its measurement vector
                    y = sum(A.*(X*B))';
                    % perform the reconstructions
                    X_MIHT_def = MIHT(A,B,y,r);
                    X_MIHT_2r = MIHT(A,B,y,r,[],2);
                    X_NIHT = NIHT(A,B,y,r);
                    X_NNM = NNM(A,B,y);
                    % success if relative error smaller than tolerance
                    Res_MIHT_def{i,j}(k) = Res_MIHT_def{i,j}(k) + ...
                        ( norm(X-X_MIHT_def,'fro') < tol_suc*norm_X );
                    Res_MIHT_2r{i,j}(k) = Res_MIHT_2r{i,j}(k) + ...
                        ( norm(X-X_MIHT_2r,'fro') < tol_suc*norm_X );
                    Res_NIHT{i,j}(k) = Res_NIHT{i,j}(k) + ...
                        ( norm(X-X_NIHT,'fro') < tol_suc*norm_X );
                    Res_NNM{i,j}(k) = Res_NNM{i,j}(k) + ...
                        ( norm(X-X_NNM,'fro') < tol_suc*norm_X );
                end
            end
        end    
    end
end
t5 = toc;

save('Exp5.mat')

%% %%  Visualization of the results of Experiment 5

try load('Exp5.mat')
catch
    load('Exp5_default.mat')
end

% plot figures for each test
for i = 1:n_dim
    N = dim_min + (i-1)*dim_inc;
    for j = 1:n_rk
        r = rk_min + (j-1)*rk_inc;
        figure
        plot(m_range{i,j},Res_NNM{i,j}/n_Meas/n_Matr,'k:x',...
            m_range{i,j},Res_MIHT_2r{i,j}/n_Meas/n_Matr,'b--o',...
            m_range{i,j},Res_MIHT_def{i,j}/n_Meas/n_Matr,'r-d',...
            m_range{i,j},Res_NIHT{i,j}/n_Meas/n_Matr,'g-.+');
        legend('NNM','MIHT (t=2r)','MIHT (default)','NIHT','Location','southeast');
        title(strcat('Recovery success (averaged over', 32, num2str(n_Meas*n_Matr),' trials)',...
            '\newline','N_1=',num2str(N), ', N_2=',num2str(N), ...
            ', r=',num2str(r)),'FontSize',16);
    xlabel('Number of measurements (m)','FontSize',22);
    ylabel('Frequency of success','FontSize',22); 
    end
end
%% References
%
% 1. S. Foucart and S. Subramanian,
% "Iterative hard thresholding for low-rank recovery from rank-one projections",
% Preprint.
%
% 2. CVX Research, Inc.,
% "CVX: MATLAB software for disciplined convex programming, version 2.1",
% http://cvxr.com/cvx, 2014.


