%%
% MIHT.m
% Perform low-rank recovery from rank-one measurements
% via Modified Iterative Hard Thresholding
%
% Implements the MIHT algorithm analyzed in the article
% "Iterative hard thresholding for low-rank recovery from rank-one projections"
% by S. Foucart and S. Subramanian.
% I.e., tries to recover a matrix X of rank <=r acquired via y = A(X)+e
% from the iterations X_{n+1} = H_s[ X_n + mu_n*H_t[A'(sgn(y-A(X_n)))]]
%
% Usage: [Xn,n,Rres] = MIHT(A,B,y,r,...)
%
% A: a matrix with columns a_1,...,a_m
% B: a matrix with columns b_1,...,b_m
% y: the measurement vector with entries a_i'*X*b_i + e_i
% r: an (over)estimation of the rank of the matrix X to be recovered
%
% Other optional inputs:
% s_over_r: outer thresholding parameter, sets s = s_over_r*r (default: 1)
% t_over_r: inner thresholding parameter, sets t = t_over_r*r (default: Inf)
% gamma : estimate of Modified Rank-Restricted Isometry Ratio (default: 3)
% itmax: maximal number of iterations
% tol: tolerance for the stopping criterion Rres < tol
% stop: binary flag adding a stopping criterion (default: 1)
%   if stop=1, MIHT stops when a change of maximizer in the stepsize occurs
%   if stop=0, MIHT does not stop when such a change occurs
%
% Xn: a matrix approximating X produced by the MIHT algorithm
% n: the number of iterations performed
% Rres: the relative L1-norm of the residual

% Written by Srinivas Subramanian and Simon Foucart in April 2018
% Send comments to simon.foucart@centraliens.net


function [Xn,n,Rres] = MIHT(A,B,y,r,varargin)

% MIHT takes 4 inputs and at most 6 optional inputs
numvarargs = length(varargin);
if numvarargs > 6
    error('MIHT can have at most 6 optional inputs: s_over_r, t_over_r, gamma, itmax, tol, stop');
end
% set defaults for optional inputs:
% s_over_r = 1, so that s = r
% t_over_r = Inf, in order to discard the inner SVD performed by H_t
% gamma = 3, valid for Gaussian rank-one projections
% itmax = 1000
% tol = 1e-4
% stop = 1, so that the stopping criterion nu2 > nu1 is added
optargs = {1, Inf, 3, 1000, 1e-4, 1};
% skip new inputs if they are empty
newVals = cellfun(@(x) ~isempty(x), varargin);
% modify the default inputs with the optional inputs
optargs(newVals) = varargin(newVals);
% place optional arguments in variable names
[s_over_r,t_over_r,gamma,itmax,tol,stop] = optargs{:};

N1 = size(A,1);
N2 = size(B,1);
s = s_over_r*r;
t = t_over_r*r;
if t>=min(N1,N2)
    NoHt = 1;  % flag to discard the inner SVD performed by H_t
else
    NoHt = 0;
end

% initilaization
n = 0 ;
Xn = zeros(N1,N2);
res = y - sum(A.*(Xn*B))';
Rres = norm(res,2)/norm(y,2);

% main loop
while((n < itmax)&&(Rres > tol))
    M = A*diag(sign(res))*B';  % this is the matrix A'(sgn(y-A(X_n)))
    if NoHt
        Ht = M;  % no inner SVD is performed
    else
        [U,S,V] = svds(M,t);
        Ht = U*S*V';
    end
    nu1 = norm(Ht,'fro');
    nu2 = (1/(2*gamma)*norm(sum(A.*(Ht*B)),1)/norm(Ht,'fro'));
    [nu,i] = max([nu1,nu2]);
    if((stop==1)&&(i==2))
        break;  % terminate when the stopping criterion nu2 > nu1 is met
    end
    mu = norm(res,1)/nu^2;
    [U,S,V] = svds(Xn+mu*Ht,s);
    Xn = U*S*V';
    res = y - sum(A.*(Xn*B))';
    Rres = norm(res,2)/norm(y,2);
    n = n+1 ;
end

end
