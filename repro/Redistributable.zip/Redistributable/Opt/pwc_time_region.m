%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Reproducible file accompanying the paper
% OPTIMAL ALGORITHMS FOR COMPUTING AVERAGE TEMPERATURES
% by R. DeVore, S. Foucart, M. Hielsberg, G. Mullendore, G. Petrova, P. Wojtaszczyk
% Written by M. Hielsberg in February 2018
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Performs the optimization using piece-wise constants on the regional 
% station data for a season.  Note that this optimization includes both
% position and time.
%Input:
% region_stations - struct containing the station lats and longs, 
%                   as well as the daily temperature data
% use_summer      - True - computes the summer values, false the winter.
% year            - The year of the season to use for the optimization.
%
%Output:
% a               - The weights computed by the optimization for each input
%                   station location and time
% mu              - The optimization value. mu / scale close to 1 is ideal.
% val             - The unscaled average temperature
% sval            - The scaled average temperature, sval = val / scale.  
%                   This is the value you want.
% scale           - The area of the occupied subboxes.
% N               - = num_boxes * num_weeks (num_weeks in the season)
% M               - = num_stations * num_weeks (num_weeks in the season) 
% lats            - The lats used by this optimization
% longs           - The longs used by this optimization
% num_boxes       - The number of occupied boxes(those containing stations)
% num_stations    - The number of stations used in the optimization
% num_empty_boxes - The number of unoccupied boxes
function [a, mu, val, sval, scale, N, M, lats, longs, num_boxes, ...
          num_stations, num_empty_boxes] = ...
                pwc_time_region(region_stations, use_summer, year)

    earth_radius = 6375;

    num_empty_boxes = 0;
    % load the region
    %tx_stations = load_state_stations_daily_TAVG('TX');
    %tx_stations = load('tx_stations.mat');
    
    stations = region_stations.dailies;
    lats = region_stations.inventory.lats;
    longs = region_stations.inventory.longs;
    
    num_stations = length(lats);
    
    s_mask = false(num_stations,1);
    % mark any stations that do not contain data for the passed year
    for i=1:num_stations
        if use_summer
            if sum(stations{i}.summer_years == year) == 0
                s_mask(i) = true; % skip this station
            end
        else
            if sum(stations{i}.winter_years == year) == 0
                s_mask(i) = true; % skip this station
           end
        end
    end
    % remove the stations without data
    lats(s_mask) = [];
    longs(s_mask) = [];
    stations(s_mask) = [];
    num_stations = length(lats);   
    
    if num_stations == 0
        warning('No station contains data for this year');
        a = []; 
        mu = 0; 
        val = NaN; 
        sval = NaN;
        scale = 1;
        N = 0;
        M = 0;
        num_empty_boxes = 0;
        num_boxes = 0;
        return;
    end

    num_weeks = size(stations{1}.summer_values, 1);
    
    grid_boxes = GISTEMP_world_grid(); % 8000 subboxes
    num_boxes = length(grid_boxes);

    % remove boxes that do not contain any stations
    b_mask = true(num_boxes,1);
    for b=1:num_boxes
        box = grid_boxes{b};
    
        for i=1:num_stations
            if contains(box, lats(i), longs(i))
                b_mask(b) = false;
                break;
            end
        end        
    end
    grid_boxes(b_mask) = [];
    num_boxes = length(grid_boxes);
    
    
    station_used = false(num_stations,1);
    N = num_boxes * num_weeks;
    M = num_stations * num_weeks; 
    
    B = zeros(N,M);
    c = zeros(N,1);
    
    cnt = zeros(N,1);
   % create the data vector
    data = zeros(M,1);
    for i=1:num_stations
        if use_summer
            % add the weekly temps to the data vector
            y_idx = stations{i}.summer_years == year;
            s_idx = (num_weeks * (i-1) + 1);
            data(s_idx:(s_idx + num_weeks - 1)) = stations{i}.summer_values(:, y_idx);
        else
            % add the weekly temps to the data vector
            y_idx = stations{i}.winter_years == year;
            s_idx = (num_weeks * (i-1) + 1);
            data(s_idx:(s_idx + num_weeks - 1)) = stations{i}.winter_values(:, y_idx);
        end
    end


    
    for row=1:num_boxes
        box = grid_boxes{row}; 
        tc = zeros(num_weeks, 1);
        for col=1:num_stations
            
            if station_used(col)
                continue; %skip any station already claimed by a box - can introduce order dependence 
            end
            if contains(box, lats(col), longs(col))
                station_used(col) = true;
                
                for i=1:num_weeks % diagonal of sub block
                    r_idx = num_weeks * (row-1) + i;
                    c_idx = num_weeks * (col-1) + i;
                    
                    y_idx = find(stations{col}.summer_years == year);
                    
                    % make sure the station has data during this week
                    value = -9999;
                    if use_summer
                        value = stations{col}.summer_values(i, y_idx);
                    else
                        value = stations{col}.winter_values(i, y_idx);
                    end
                    if value ~= -9999
                        B(r_idx, c_idx) = 1;
                        tc(i) = tc(i) + 1;
                    end
                         
                    
                end
            end
        end 
        r_idx = num_weeks * (row-1) + 1;
        
        cnt(r_idx:(r_idx + num_weeks - 1)) = tc; % # of stations in each box for each week
        if sum(tc) == 0
            num_empty_boxes = num_empty_boxes + 1;
        end
        
        box_area = (pi/180) * earth_radius^2 * ...
                    abs(sind(box.lat_north)-sind(box.lat_south)) * ...
                    abs(box.lon_west-box.lon_east);

        % Assume unit area triangle shaped characteristic function for time
        % contirbution.  The first and last contribute only half.
        c(r_idx:(r_idx + num_weeks - 1)) = box_area;
        c(r_idx) = c(r_idx) * 0.5;
        c(r_idx + num_weeks - 1) = c(r_idx + num_weeks - 1) * 0.5;
    end
    
    c = c / sum(c);
    
    % Remove empty rows - no stations in those subboxes
    B(~cnt,:) = [];
    c(~cnt) = [];
    
     
    disp(['  Attempting opt with ', num2str(M), ' locations and ', num2str(size(c,1)), ' grid locations']);
    
    %% optimization 
    cvx_solver gurobi
    cvx_quiet false

    tic;
        cvx_begin

        variable a(M)
        variable s(M)

        minimize sum(s)

        subject to
        s + a >= 0;
        s - a >= 0;
        B*a == c;

        cvx_end
    toc
    
    val = dot(data,a);
    scale = sum(c);
    sval = val / scale;
    
    mu = cvx_optval / scale;
    
end





%% Returns true if the passed lat,long is inside the passed box, false otherwise
% Note that locations falling on a boundary will be included on both sides
% of the boundary
function b = contains(box, lat, long)

    if lat > box.lat_north
        b = false;
        return;
    end
    if lat < box.lat_south
        b = false;
        return;
    end
    if long > box.lon_east
        b = false;
        return;
    end
    if long < box.lon_west
        b = false;
        return;
    end
    b = true;
   
end

