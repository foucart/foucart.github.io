%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Reproducible file accompanying the paper
% OPTIMAL ALGORITHMS FOR COMPUTING AVERAGE TEMPERATURES
% by R. DeVore, S. Foucart, M. Hielsberg, G. Mullendore, G. Petrova, P. Wojtaszczyk
% Written by M. Hielsberg in February 2018
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


addpath('Precipitation');
addpath('GISTEMP');
addpath('Opt');
addpath('Agency');

% Range of years over which the opitimization(s) will occur
start_year     = 1901;
end_year       = 2013;
n_years        = end_year - start_year + 1;

% Reference year range used to compute anomalies from the temperature data
ref_start_year = 1901;
ref_end_year   = 2000;

local_path = 'Data/opt_sh_yearly_1901-2013/';

prec_data = load_precipitation('GPCC/precip.mon.total.1x1.v7.nc');


%% 1 - Run optimization for V_{spherical harmonics} at yearly resolution using 1x1 degree precipitation data (land-only data)

    % use precip.mon.total.1x1.v7.nc
    % run optimization independently for each year

    diary([local_path, 'opt_sh_yearly.txt']);
    for L=[3,6,9,12,15]
        disp(['L = ', num2str(L)]);
        t = tic;
        opt_sh_yearly = cell(n_years,1);
        idx = 1;
        month = -1;
        for year=start_year:end_year
            valid_locs = find_valid_precip(prec_data, month, year);
            if isempty(valid_locs)
                continue;
            end
            [res.a, res.mu, res.val, res.sval, res.scale, res.M, res.lats, res.longs] = sh_gistemp_locs(valid_locs, month, L);
            res.year = year;
            res.month = -1;

            disp([num2str(year), ': mu = ', num2str(res.mu)]);
            disp(['   global precip = ', num2str(res.val)]);
            disp(['   global precip (scaled) = ', num2str(res.sval)]);
            save([local_path, 'opt_sh_yearly/opt_', num2str(year), '_L=', num2str(L), '.mat'], 'res');

            opt_sh_yearly{idx} = res;

            idx = idx + 1;
        end

        % find reference period mean
        s_idx = ref_start_year - start_year + 1;
        e_idx = ref_end_year - start_year + 1;
        ref_mean = 0;
        sref_mean = 0;
        for i = s_idx:e_idx
            ref_mean = ref_mean + opt_sh_yearly{i}.val;
            sref_mean = sref_mean + opt_sh_yearly{i}.sval;
        end
        ref_mean = ref_mean / (e_idx - s_idx + 1);
        sref_mean = sref_mean / (e_idx - s_idx + 1);
        % convert temperature to anomalies from the reference period
        idx = 1;
        for year=start_year:end_year
            opt_sh_yearly{idx}.ref_mean = ref_mean;
            opt_sh_yearly{idx}.sref_mean = sref_mean;
            opt_sh_yearly{idx}.anom = opt_sh_yearly{idx}.val - ref_mean;
            opt_sh_yearly{idx}.sanom = opt_sh_yearly{idx}.sval - sref_mean;
            idx = idx + 1;
        end
 
        save([local_path, 'opt_sh_yearly_L=', num2str(L), '.mat'], ...
                                    'opt_sh_yearly', ...
                                    'start_year', ...
                                    'end_year', ...
                                    'ref_start_year', ...
                                    'ref_end_year');
        toc(t);
    end
    diary off;

