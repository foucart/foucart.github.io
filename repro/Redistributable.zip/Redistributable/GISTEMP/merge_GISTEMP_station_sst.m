%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Reproducible file accompanying the paper
% OPTIMAL ALGORITHMS FOR COMPUTING AVERAGE TEMPERATURES
% by R. DeVore, S. Foucart, M. Hielsberg, G. Mullendore, G. Petrova, P. Wojtaszczyk
% Written by M. Hielsberg in January 2018
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function valid_merged = merge_GISTEMP_station_sst(valid_stations, valid_ssts)

    if valid_ssts.month ~= valid_stations.month || valid_ssts.year ~= valid_stations.year
        error('Attempting to merge data from different months/years')
    end

    valid_merged.month = valid_ssts.month;
    valid_merged.year  = valid_ssts.year;
    valid_merged.lats  = [valid_stations.lats, valid_ssts.lats];
    valid_merged.longs = [valid_stations.longs, valid_ssts.longs];

    if isfield(valid_stations, 'yearly_avg')
        valid_merged.yearly_avg = [valid_stations.yearly_avg, valid_ssts.yearly_avg];
    else
        valid_merged.monthly_avg = [valid_stations.monthly_avg, valid_ssts.monthly_avg];
    end

end
