%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Reproducible file accompanying the paper
% OPTIMAL ALGORITHMS FOR COMPUTING AVERAGE TEMPERATURES
% by R. DeVore, S. Foucart, M. Hielsberg, G. Mullendore, G. Petrova, P. Wojtaszczyk
% Written by M. Hielsberg in January 2018
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function sbbx = load_SBBX_ERSST()

    warning('on');
    warning('This function assumes the input file contains Jan 1880 - Dec 2016 - See compute_yearly');
    
    % read bytes
    fileID = fopen('GISTEMP/gistemp1.0/tmp/input/SBBX.ERSSTv4');
    A = fread(fileID, '*char');
    fclose(fileID);

    % unpack
    fidx = 5; % skip the first 4 bytes - fortran line length
    sbbx.mo1 = cast_int32(A(fidx:(fidx+3)));                fidx = fidx + 4;
    sbbx.kq = cast_int32(A(fidx:(fidx+3)));                 fidx = fidx + 4;
    sbbx.mavg = cast_int32(A(fidx:(fidx+3)));               fidx = fidx + 4;
    sbbx.monm = cast_int32(A(fidx:(fidx+3)));               fidx = fidx + 4;
    sbbx.monm4 = cast_int32(A(fidx:(fidx+3)));              fidx = fidx + 4;
    sbbx.yrbeg = cast_int32(A(fidx:(fidx+3)));              fidx = fidx + 4;
    sbbx.missing_flag = cast_int32(A(fidx:(fidx+3)));       fidx = fidx + 4;
    sbbx.preceipitation_flag = cast_int32(A(fidx:(fidx+3)));fidx = fidx + 4;
    sbbx.title = char(A(fidx:(fidx+79)))';                  fidx = fidx + 80;
    fidx = fidx + 4; % skip the repeated fortran line length

    if sbbx.mavg == 6
        disp('Only monthly averages supported - yearly averages are computed here');
    end

    % Assumes the file is for sea data
    sbbx.celltype = 'P';
    
    % sbbx.gridding_radius not set as title does not have anything here
    
    % sbbx.meta contains all above items
    
    mo1 = sbbx.mo1;
    records = {};
    while fidx < length(A)
        [rec, fidx, mo1] = unpack_record(A, fidx, mo1);
        records = [records rec];
    end
    sbbx.records = records;
    
end


function [record, fidx, mo1] = unpack_record(A, fidx, mo1)

    line_size = cast_int32(A(fidx:fidx+3));
    header_size = 32;
    if (line_size - header_size) / 4 ~= mo1
        error('Invalide File - oh no!');
    end
    fidx = fidx + 4; % skip the first 4 bytes - fortran line length
    
    % read header
    record.mo1 = cast_int32(A(fidx:(fidx+3)));              fidx = fidx + 4;
    record.box.lat_south = cast_int32(A(fidx:(fidx+3)));    fidx = fidx + 4;
    record.box.lat_north = cast_int32(A(fidx:(fidx+3)));    fidx = fidx + 4;
    record.box.lon_west = cast_int32(A(fidx:(fidx+3)));     fidx = fidx + 4;
    record.box.lon_east = cast_int32(A(fidx:(fidx+3)));     fidx = fidx + 4;
    record.stations = cast_int32(A(fidx:(fidx+3)));         fidx = fidx + 4;
    record.station_months = cast_int32(A(fidx:(fidx+3)));   fidx = fidx + 4;
    record.d = cast_single(A(fidx:(fidx+3)));               fidx = fidx + 4;

    % read monthly data series
    nb_series = mo1 * 4;
    record.monthly = cast_single(A(fidx:(fidx+nb_series-1)));fidx = fidx + nb_series;
    record.yearly = compute_yearly(record.monthly);

    if cast_int32(A(fidx:fidx+3)) ~= line_size
        error('Invalide File - oh no!');
    end
    fidx = fidx + 4; % skip the repeated fortran line length

    % rescale the box coordinates
    record.box.lat_south = double(record.box.lat_south) / 100;
    record.box.lat_north = double(record.box.lat_north) / 100;
    record.box.lon_west = double(record.box.lon_west) / 100;
    record.box.lon_east = double(record.box.lon_east) / 100;
    
    % return the size of the next record
    mo1 = record.mo1;
end

function i = cast_int32(bytes)
    i = cast_generic(bytes, 'int32', 4);
end

function i = cast_single(bytes)
    i = cast_generic(bytes, 'single', 4);
end

function i = cast_generic(bytes, type, num_bytes)
    n = length(bytes);
    num_vals = floor(n/num_bytes);
    if num_vals < n/num_bytes
        error([type, ' cast expecting multiple of ', num2str(num_bytes), ' bytes']);
    end
    i = zeros(num_vals, 1);
    idx = num_bytes;
    for m=1:num_vals
        i(m) = typecast(uint8(bytes(idx:-1:(idx-num_bytes+1))), type);
        idx = idx + num_bytes;
    end
end

function yearly = compute_yearly(monthly)

    % assumes 1880-2016, should pull this from the title stored in the file
    num_years = 137; 
    
    yearly = ones(num_years, 1) * 9999;
    y_idx = 1;
    for i=1:12:length(monthly)
        
        end_i = min(i+11, length(monthly));
        
        year = monthly(i:end_i);
        year(abs(year) == 9999) = [];
        
        if ~isempty(year)
            yearly(y_idx) = mean(year);
        end
        y_idx = y_idx + 1; 
    end

end
