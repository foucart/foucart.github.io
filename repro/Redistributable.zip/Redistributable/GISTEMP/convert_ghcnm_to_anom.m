%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Reproducible file accompanying the paper
% OPTIMAL ALGORITHMS FOR COMPUTING AVERAGE TEMPERATURES
% by R. DeVore, S. Foucart, M. Hielsberg, G. Mullendore, G. Petrova, P. Wojtaszczyk
% Written by M. Hielsberg in January 2018
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function merged_ghcnm_data_inv_anoms = convert_ghcnm_to_anom(merged_ghcnm_data_inv, start_ref_year, end_ref_year)

    merged_ghcnm_data_inv_anoms.ids = merged_ghcnm_data_inv.ids;
    merged_ghcnm_data_inv_anoms.years = merged_ghcnm_data_inv.years;
    %merged_ghcnm_data_inv_anoms.monthly_avg = merged_ghcnm_data_inv.monthly_avg;
    merged_ghcnm_data_inv_anoms.yearly_avg = merged_ghcnm_data_inv.yearly_avg;
    merged_ghcnm_data_inv_anoms.lats = merged_ghcnm_data_inv.lats;
    merged_ghcnm_data_inv_anoms.longs = merged_ghcnm_data_inv.longs;
    merged_ghcnm_data_inv_anoms.names = merged_ghcnm_data_inv.names;
    
    used_stations = false(length(merged_ghcnm_data_inv.ids),1);
    
    [~, ia, ~] = unique(merged_ghcnm_data_inv.ids);
    wg = GISTEMP_world_grid();
    
    for b_idx = 1:length(wg)
        box = wg{b_idx};

        % get stations in this box
        box_station_indices = false(length(merged_ghcnm_data_inv.ids),1);
        for id=ia'
            if box_contains_loc(box, merged_ghcnm_data_inv.lats(id), merged_ghcnm_data_inv.longs(id))
                
                indices = strcmp(merged_ghcnm_data_inv.ids, merged_ghcnm_data_inv.ids(id));
                box_station_indices(indices) = true;
            end
        end
        
        % remove previously used stations (boundaries of boxes)
        double_used_stations = used_stations & box_station_indices;
        box_station_indices(double_used_stations) = false;
        % remove the box stations from future use
        used_stations(box_station_indices) = true;
        
        % get the mean for this box
        sum_temps = 0;
        num_temps = 0;
        for year = start_ref_year:end_ref_year

            year_indices = merged_ghcnm_data_inv.years == year;
            
            used_indices = year_indices' & box_station_indices;

            cnt = sum(used_indices);
            if cnt > 0
                sum_temps = sum_temps + sum(merged_ghcnm_data_inv.yearly_avg(used_indices));
                num_temps = num_temps + cnt;
            end

        end

        if num_temps > 0
            ref_mean = sum_temps / num_temps;
        else
            ref_mean = mean(merged_ghcnm_data_inv_anoms.yearly_avg(box_station_indices));
        end
        
        merged_ghcnm_data_inv_anoms.yearly_avg(box_station_indices) = ...
            merged_ghcnm_data_inv_anoms.yearly_avg(box_station_indices) - ref_mean;
%         plot(merged_ghcnm_data_inv.yearly_avg(box_station_indices));
%         hold on;
%         plot(merged_ghcnm_data_inv_anoms.yearly_avg(box_station_indices));
%         hold off;
    end

