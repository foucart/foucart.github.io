%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Reproducible file accompanying the paper
% OPTIMAL ALGORITHMS FOR COMPUTING AVERAGE TEMPERATURES
% by R. DeVore, S. Foucart, M. Hielsberg, G. Mullendore, G. Petrova, P. Wojtaszczyk
% Written by M. Hielsberg in April 2017
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [boxes] = load_gistemp_land_boxes(filename)

% GISTEMP/gistemp1.0/tmp/result/GHCNv3BoxesLand.1200.txt

    fid = fopen(filename, 'r');
    if (fid < 0)
        error('File not found');
    end
    
    
    % skip the header line
    fgets(fid);
    line = fgets(fid);
    file_header = sscanf(line, '%f %f %f %f');
    
    boxes.first_year = file_header(1);
    boxes.last_year = file_header(2);
    boxes.missing_data_flag = file_header(3);
    boxes.smoothing_radius = file_header(4);
    boxes.total_weight = 0;
    
    idx = 1;
    % read all boxes
    while ~feof(fid)
    
        % read box header
        line = fgets(fid);
        box_header = sscanf(line, '%f %f %f %f %f');
        
        boxes.box{idx}.south_lat = box_header(1);
        boxes.box{idx}.north_lat = box_header(2);
        boxes.box{idx}.west_long = box_header(3);
        boxes.box{idx}.east_long = box_header(4);
        boxes.box{idx}.weight = box_header(5);
        [boxes.box{idx}.lat_center, boxes.box{idx}.long_center] = box_center(box_header);
        
        boxes.total_weight = boxes.total_weight + box_header(5);
        
        % read monthly values for all years
        year = boxes.first_year;
        while ~feof(fid) 
            
            if year > boxes.last_year
                break;
            end
            
            line = fgets(fid);
            monthly = sscanf(line, '%f %f %f %f %f %f %f %f %f %f %f %f');
            
            boxes.box{idx}.years(year - boxes.first_year + 1, :) = monthly';
            
            year = year + 1;
            
        end
        % file appears to contain an additional year of data all missing
        % values - skip it.
        fgets(fid);
        
        idx = idx + 1;
        
    end
    
    fclose(fid);

    
    


end


function [c_lat, c_lon] = box_center(box)

    sinc = 0.5 * (sind(box(1)) + sind(box(2)));
    c_lat = real(asin(sinc)) * 180 / pi;
    c_lon = 0.5 * (box(3) + box(4));
end
