%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Reproducible file accompanying the paper
% OPTIMAL ALGORITHMS FOR COMPUTING AVERAGE TEMPERATURES
% by R. DeVore, S. Foucart, M. Hielsberg, G. Mullendore, G. Petrova, P. Wojtaszczyk
% Written by M. Hielsberg in January 2018
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function valid_stations = find_GISTEMP_valid_cells(merged_data_inv, month, year)

    % find the indices of the data for the passed year
    year_indices = find(merged_data_inv.years == year);

    valid_stations.month       = month;
    valid_stations.year        = year;

    if month > 0 && month < 13
        % remove indices without valid data
        year_indices(merged_data_inv.monthly_anom(month,year_indices)== -9999) = []; 
        
        % return only monthly data
        valid_stations.years       = merged_data_inv.years(year_indices);
        valid_stations.monthly_avg = merged_data_inv.monthly_anom(month, year_indices);
        %valid_stations.yearly_avg  = merged_data_inv.yearly_anom(year_indices);
        valid_stations.lats        = merged_data_inv.center_lats(year_indices);
        valid_stations.longs       = merged_data_inv.center_longs(year_indices);
    else
        % remove indices without valid data
        year_indices(merged_data_inv.yearly_anom(year_indices)== -9999) = []; 

        % return only yearly data
        valid_stations.years       = merged_data_inv.years(year_indices);
        %valid_stations.monthly_avg = merged_data_inv.monthly_anom(month, year_indices);
        valid_stations.yearly_avg  = merged_data_inv.yearly_anom(year_indices);
        valid_stations.lats        = merged_data_inv.center_lats(year_indices);
        valid_stations.longs       = merged_data_inv.center_longs(year_indices);
    end
    


end
