%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Reproducible file accompanying the paper
% OPTIMAL ALGORITHMS FOR COMPUTING AVERAGE TEMPERATURES
% by R. DeVore, S. Foucart, M. Hielsberg, G. Mullendore, G. Petrova, P. Wojtaszczyk
% Written by M. Hielsberg in October 2017
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [antarc_data, inventory] = load_GISTEMP_antarc(path)

    % GISTEMP/gistemp1.0/tmp/input/
    % antarc1.list
    % antarc1.txt
    % antarc2.list
    % antarc2.txt
    % antarc3.list
    % antarc3.txt

    
    % load station inventory (ids, names and locations)
    a1 = load_antarc_inv_list([path, 'antarc1.list']);
    a2 = load_antarc_inv_list([path, 'antarc2.list']);
    a3 = load_antarc_inv_list([path, 'antarc3.list']);

    % load the monthly and yearly averages for each station during each
    % full operational year
    a1_avg = load_antarc_monthly('GISTEMP/gistemp1.0/tmp/input/antarc1.txt');
    a2_avg = load_antarc_monthly_augmented('GISTEMP/gistemp1.0/tmp/input/antarc2.txt');
    a3_avg = load_antarc_monthly('GISTEMP/gistemp1.0/tmp/input/antarc3.txt');

    % it turns out that there are stations with different id's but the same
    % name in different files.  The GPS locations are very similar, but
    % could still be different measurements.  As such we append the ids
    % prior to merging the 1,2,3 data sets.
    
    % add the station ids to the temperature data structure
    a1_data = append_ids(a1_avg, a1);
    a2_data = append_ids(a2_avg, a2);
    a3_data = append_ids(a3_avg, a3);

    % merge inventory data
    inventory.ids =   [a1.ids,   a2.ids,   a3.ids];
    inventory.names = [a1.names, a2.names, a3.names];
    inventory.lats =  [a1.lats,  a2.lats,  a3.lats];
    inventory.longs = [a1.longs, a2.longs, a3.longs];    

    % merge monthly and yearly temperature data for all stations
    antarc_data.ids =         [a1_data.ids,         a2_data.ids,         a3_data.ids];
    antarc_data.names =       [a1_data.names,       a2_data.names,       a3_data.names];
    antarc_data.years =       [a1_data.years,       a2_data.years,       a3_data.years];
    antarc_data.monthly_avg = [a1_data.monthly_avg, a2_data.monthly_avg, a3_data.monthly_avg];
    antarc_data.yearly_avg =  [a1_data.yearly_avg,  a2_data.yearly_avg,  a3_data.yearly_avg];
    
    
    
    
    
    


end


function station_inventory = load_antarc_inv_list(filename)

    % loads an antarcX.list files

    fid = fopen(filename);
    if (fid < 0)
        error('File not found');
    end
    [bytes, num_bytes] = fread(fid, '*char');
    fclose(fid);

    num_entries = floor(num_bytes / 71); % 70 without newline

    ids = {num_entries};
    names = {1, num_entries};
    lats = zeros(1, num_entries);
    longs = zeros(1, num_entries);
    

    idx = 1;
    i = 1;
    while (i < num_bytes)

        % ID            1-11   Character
        ids{idx} = bytes(i:(i+10), 1)';
        i = i + 11 + 1;
 
        % Name          13-42
        names{idx} = strtrim(bytes(i:(i+29), 1)');
        i = i + 30 + 1;
        
        % LATITUDE     44-49   Real
        lats(idx) = str2double(bytes(i:(i+5), 1));
        i = i + 6 + 1;

        % LONGITUDE    51-57   Real
        longs(idx) = str2double(bytes(i:(i+6), 1));
        i = i + 7 + 1;
        
        % skip the rest of the line
        i = i + 12;

        i = i + 1;
        idx = idx + 1;
    end
    
    station_inventory.ids = ids;
    station_inventory.names = names;
    station_inventory.lats = lats;
    station_inventory.longs = longs;    

end

function monthly_averages = load_antarc_monthly(filename)

    % GISTEMP/gistemp1.0/tmp/input/antarc1.txt
    % GISTEMP/gistemp1.0/tmp/input/antarc3.txt
    
    monthly_averages.names = {};
    monthly_averages.years = [];
    monthly_averages.monthly_avg = [];
    monthly_averages.yearly_avg = [];
    
    fid = fopen(filename);
    if (fid < 0)
        error('File not found');
    end
    
    while ~feof(fid)
        % read line into buffer
        line = fgets(fid);
        line_sz = size(line, 2);
        if line_sz < 4
            continue;
        end
        if line(1) == '#'
            continue;
        end
        if strcmp('Get', line(1:3))
            % if not continue to next line
            continue
        end
        if line_sz < 6
            continue;
        end
        if strcmp('Title', line(1:5))
            % if not continue to next line
            continue
        end

        % Read station name - remove ' temperature' from the end
        station_name = line(1:(end - 13));
        
        % Remove any unwanted characters
        station_name = strrep(station_name, '\', '');
        
        % read all years for this station
        while ~feof(fid)
            
            line = fgets(fid);
            %line_sz = size(line, 2);
            
            if line(1) == '#'
                % break from station section
                break;
            end
            
            % read year
            year = str2double(line(1:4));
            
            % read monthly averages
            tokens = strsplit(strtrim(line(6:(end-1))), ' ');
            
            % verify that there are no missing values
            if sum(strcmp(tokens, '-')) > 0      
                continue; % missing data - move on to next year
            end
            
            % convert the text to double temperatures (in C)
            temps = str2double(tokens);
            
            monthly_averages.names = [monthly_averages.names, station_name];
            monthly_averages.years = [monthly_averages.years, year];
            monthly_averages.monthly_avg = [monthly_averages.monthly_avg, temps'];
            monthly_averages.yearly_avg = [monthly_averages.yearly_avg, mean(temps)];
           
        end
        
    end

    fclose(fid);


end

function monthly_averages = load_antarc_monthly_augmented(filename)

    % GISTEMP/gistemp1.0/tmp/input/antarc2.txt

    monthly_averages.names = {};
    monthly_averages.years = [];
    monthly_averages.monthly_avg = [];
    monthly_averages.yearly_avg = [];
    
    fid = fopen(filename);
    if (fid < 0)
        error('File not found');
    end
    
    while ~feof(fid)
        % read line into buffer
        line = strtrim(fgets(fid));
        line_sz = size(line, 2);
        
        if line_sz < 4
            continue;
        end
        if line(1) == '#'
            continue;
        end
        if strcmp('J  ', line(1:3))
            continue;
        end
        if strcmp('Get', line(1:3))
            % if not continue to next line
            continue
        end
        if strcmp('MEAN', line(1:4))
            % if not continue to next line
            continue
        end
        if line_sz < 6
            continue;
        end
        if strcmp('Title', line(1:5))
            % if not continue to next line
            continue
        end
        if strcmp('SELEC', line(1:5))
            % if not continue to next line
            continue
        end

        % Read station name
        station_name = strtrim(line(1:30));
        
        % fix station sections that do not conform to format
        mask = strfind(station_name, '   ');
        if size(mask, 2) > 0
            station_name = station_name(1:(mask(1)-1));
        end
        
        has_mean_col = false;
        
        % read all years for this station
        while ~feof(fid)
            
            line = strtrim(fgets(fid));
            line_sz = size(line, 2);
            
            if line_sz < 4
                continue;
            end
            if line(1) == '#'
                % break from station section
                break;
            end
            if line(1) == 'J'
                if strcmp(line((end-3):end), 'MEAN')
                    has_mean_col = true;
                end
                continue;
            end
            if strcmp('MEAN', line(1:4))
                % if not continue to next line
                continue
            end
            
            % read year
            year = str2double(line(1:4));
            
            % read monthly averages
            tokens = strsplit(strtrim(line(6:end)), ' ');
            
            % verify that there are no missing values - indicated by '-'
            if sum(strcmp(tokens, '-')) > 0      
                continue; % missing data - move on to next year
            end
            
            % verify that there are no missing values - indicated by ' '
            num_tokens = 12;
            if has_mean_col
                num_tokens = 13;
            end
            if size(tokens, 2) < num_tokens
                continue; % missing data or mean with incomplete data
            end
            
            % convert the text to double temperatures (in C)
            temps = str2double(tokens);
            
            monthly_averages.names = [monthly_averages.names, station_name];
            monthly_averages.years = [monthly_averages.years, year];
            monthly_averages.monthly_avg = [monthly_averages.monthly_avg, temps(1:12)'];
            monthly_averages.yearly_avg = [monthly_averages.yearly_avg, mean(temps(1:12))];
            % we use the actual mean of the 12 months as the MEAN column is
            % rounded to the nearest tenth
           
        end

        
        
        
    end
    
    
    fclose(fid);

end

function antarc_data = append_ids(antarc_data, inventory)

    num_entries = size(antarc_data.names, 2);
    for i=1:num_entries
       
        idx = find(strcmp(inventory.names, antarc_data.names(i)));
        antarc_data.ids(i) = inventory.ids(idx);
        
    end
    
end
