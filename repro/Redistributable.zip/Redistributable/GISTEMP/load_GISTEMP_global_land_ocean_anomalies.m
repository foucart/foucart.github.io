%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Reproducible file accompanying the paper
% OPTIMAL ALGORITHMS FOR COMPUTING AVERAGE TEMPERATURES
% by R. DeVore, S. Foucart, M. Hielsberg, G. Mullendore, G. Petrova, P. Wojtaszczyk
% Written by M. Hielsberg in February 2018
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function land_ocean = load_GISTEMP_global_land_ocean_anomalies(filename)

    fid = fopen(filename);
    if (fid < 0)
        error('File not found');
    end
    
    % skip header
    line = fgets(fid);
    while length(line) < 2 || ~strcmp(line(1:4), 'Year')
        line = fgets(fid);
    end
    
    land_ocean.years = [];
    land_ocean.global_avg = [];
    land_ocean.seas_djf_mean = [];
    land_ocean.seas_mam_mean = [];
    land_ocean.seas_jja_mean = [];
    land_ocean.seas_son_mean = [];
    
    while ~feof(fid)
        % read line into buffer
        line = fgets(fid);

        land_ocean.years = [land_ocean.years, str2double(line(1:4))];
        land_ocean.global_avg = [land_ocean.global_avg, str2double(line(80:85))];
        if strcmp('***', line(97:99))
            land_ocean.seas_djf_mean = [land_ocean.seas_djf_mean, -9999];
        else
            land_ocean.seas_djf_mean = [land_ocean.seas_djf_mean, str2double(line(94:99))];
        end
        land_ocean.seas_mam_mean = [land_ocean.seas_mam_mean, str2double(line(100:105))];
        land_ocean.seas_jja_mean = [land_ocean.seas_jja_mean, str2double(line(106:111))];
        land_ocean.seas_son_mean = [land_ocean.seas_son_mean, str2double(line(112:117))];
            
    end
            
    land_ocean.first_year = min(land_ocean.years);
    land_ocean.last_year = max(land_ocean.years);
    
    fclose(fid);
end
