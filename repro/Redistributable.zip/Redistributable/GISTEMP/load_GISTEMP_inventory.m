%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Reproducible file accompanying the paper
% OPTIMAL ALGORITHMS FOR COMPUTING AVERAGE TEMPERATURES
% by R. DeVore, S. Foucart, M. Hielsberg, G. Mullendore, G. Petrova, P. Wojtaszczyk
% Written by M. Hielsberg in Sept 2017
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function station_inventory = load_GISTEMP_inventory(filename)

% GISTEMP/gistemp1.0/tmp/input/v3.inv


%    id---------xname--------------------------xlat---xlon----x1---2----34----5-6-7-8-910grveg-----------GU--11
%    0123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345
%    40371148001 ALMASIPPI,MA                    49.55  -98.20  274  287R   -9FLxxno-9x-9COOL FIELD/WOODSA1   0
%    42572530000 CHICAGO/O'HARE, ILLINOIS        42.00  -87.90  205  197U 6216FLxxno-9A 1COOL CROPS      C3 125
%
%       uid                 40371148001          42572530000
%          The unique ID of the station. This is held as an 11 digit string.
%       name                ALMASIPPI,MA         CHICAGO/O'HARE, ILLINOIS
%        The station's name.
%       lat                 49.55                42.00
%        The latitude, in degrees (two decimal places).
%       lon                 -98.20               -87.90
%        The longitude, in degrees (two decimal places).
%    1  stelev              274                  205
%        The station elevation in metres.
%    2  grelev              287                  197
%        The grid elevation in metres (value taken from gridded dataset).
%    3  popcls              R                    U
%        'R' for rural,  'S' for semi-urban, 'U' for urban.
%    4  popsiz              -9                   6216
%        Population of town in thousands.
%    5  topo                FL                   FL
%        The topography.
%    6  stveg               xx                   xx
%    7  stloc               no                   no
%        Whether the station is near a lake (LA) or ocean (OC).
%    8  ocndis              -9                   -9
%    9  airstn              x                    A
%    10 towndis             -9                   1
%       grveg               COOL FIELD/WOODS     COOL CROPS
%        An indication of vegetation, from a gridded dataset. For example,
%        'TROPICAL DRY FOR'.
%    G  popcss              A                    C
%        Population class based on satellite lights (GHCN value).
%    U  us_light            1                    3
%        Urban/Rural flag based on satellite lights for US stations
%        (' ' for non-US stations).  '1' is dark, '3' is bright.
%    11 global_light        0                    125
%    Global satellite nighttime light value.  Range 0-186 (at
%    least).

    fid = fopen(filename);
    if (fid < 0)
        error('File not found');
    end
    [bytes, num_bytes] = fread(fid, '*char');
    fclose(fid);

    num_entries = floor(num_bytes / 110); % 109 without newline

    ids = {num_entries};
    names = {1, num_entries};
    lats = zeros(1, num_entries);
    longs = zeros(1, num_entries);
    

    idx = 1;
    i = 1;
    while (i < num_bytes)

        % ID            1-11   Character
        ids{idx} = bytes(i:(i+10), 1)';
        i = i + 11 + 1;
 
        % Name          13-42
        names{idx} = bytes(i:(i+29), 1)';
        i = i + 30 + 1;
        
        % LATITUDE     44-49   Real
        lats(idx) = str2double(bytes(i:(i+5), 1));
        i = i + 6 + 1;

        % LONGITUDE    51-57   Real
        longs(idx) = str2double(bytes(i:(i+6), 1));
        i = i + 7 + 1;
        
        % skip the rest of the line
        i = i + 51;

        i = i + 1;
        idx = idx + 1;
    end
    
    station_inventory.ids = ids;
    station_inventory.names = names;
    station_inventory.lats = lats;
    station_inventory.longs = longs;
    
end
