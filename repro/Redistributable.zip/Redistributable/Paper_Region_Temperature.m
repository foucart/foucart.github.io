%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Reproducible file accompanying the paper
% OPTIMAL ALGORITHMS FOR COMPUTING AVERAGE TEMPERATURES
% by R. DeVore, S. Foucart, M. Hielsberg, G. Mullendore, G. Petrova, P. Wojtaszczyk
% Written by M. Hielsberg in April 2018
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%
addpath('GISTEMP');
addpath('Opt');
addpath('Agency');
addpath('GHCND');

% Load the state station data from the daily files - this will take a while
tx_stations = load_state_stations_daily_TAVG('TX');

% run the optimization
PWC_Time_Test(tx_stations, 'texas');

% plot the locations
plot_state_stations_grid(tx_stations, 'Texas');
