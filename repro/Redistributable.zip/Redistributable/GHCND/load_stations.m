%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Reproducible file accompanying the paper
% OPTIMAL ALGORITHMS FOR COMPUTING AVERAGE TEMPERATURES
% by R. DeVore, S. Foucart, M. Hielsberg, G. Mullendore, G. Petrova, P. Wojtaszczyk
% Written by M. Hielsberg in February 2017
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function stations = load_stations(filename)

% ID         is the station identification code.  Note that the first two
%            characters denote the FIPS  country code, the third character 
%            is a network code that identifies the station numbering system 
%            used, and the remaining eight characters contain the actual 
%            station ID. 
% 
%            See "ghcnd-countries.txt" for a complete list of country codes.
% 	   See "ghcnd-states.txt" for a list of state/province/territory codes.
% 
%            The network code  has the following five values:
% 
%            0 = unspecified (station identified by up to eight 
% 	       alphanumeric characters)
% 	   1 = Community Collaborative Rain, Hail,and Snow (CoCoRaHS)
% 	       based identification number.  To ensure consistency with
% 	       with GHCN Daily, all numbers in the original CoCoRaHS IDs
% 	       have been left-filled to make them all four digits long. 
% 	       In addition, the characters "-" and "_" have been removed 
% 	       to ensure that the IDs do not exceed 11 characters when 
% 	       preceded by "US1". For example, the CoCoRaHS ID 
% 	       "AZ-MR-156" becomes "US1AZMR0156" in GHCN-Daily
%            C = U.S. Cooperative Network identification number (last six 
%                characters of the GHCN-Daily ID)
% 	   E = Identification number used in the ECA&D non-blended
% 	       dataset
% 	   M = World Meteorological Organization ID (last five
% 	       characters of the GHCN-Daily ID)
% 	   N = Identification number used in data supplied by a 
% 	       National Meteorological or Hydrological Center
% 	   R = U.S. Interagency Remote Automatic Weather Station (RAWS)
% 	       identifier
% 	   S = U.S. Natural Resources Conservation Service SNOwpack
% 	       TELemtry (SNOTEL) station identifier
%            W = WBAN identification number (last five characters of the 
%                GHCN-Daily ID)
% 
% LATITUDE   is latitude of the station (in decimal degrees).
% 
% LONGITUDE  is the longitude of the station (in decimal degrees).
% 
% ELEVATION  is the elevation of the station (in meters, missing = -999.9).
% 
% 
% STATE      is the U.S. postal code for the state (for U.S. stations only).
% 
% NAME       is the name of the station.
% 
% GSN FLAG   is a flag that indicates whether the station is part of the GCOS
%            Surface Network (GSN). The flag is assigned by cross-referencing 
%            the number in the WMOID field with the official list of GSN 
%            stations. There are two possible values:
% 
%            Blank = non-GSN station or WMO Station number not available
%            GSN   = GSN station 
% 
% HCN/      is a flag that indicates whether the station is part of the U.S.
% CRN FLAG  Historical Climatology Network (HCN).  There are three possible 
%           values:
% 
%            Blank = Not a member of the U.S. Historical Climatology 
% 	           or U.S. Climate Reference Networks
%            HCN   = U.S. Historical Climatology Network station
% 	   CRN   = U.S. Climate Reference Network or U.S. Regional Climate 
% 	           Network Station
% 
% WMO ID     is the World Meteorological Organization (WMO) number for the
%            station.  If the station has no WMO number (or one has not yet 
%            been matched to this station), then the field is blank.
     
    fid = fopen(filename);
    if (fid < 0)
        error('File not found');
    end
    [bytes, num_bytes] = fread(fid, '*char');
    fclose(fid);
    
    num_entries = floor(num_bytes / 86);
    
    ids = {1, num_entries};
    lats = zeros(1, num_entries);
    longs = zeros(1, num_entries);
    els = zeros(1, num_entries);
    states = {1, num_entries};
    names = {1, num_entries};
    gsn_flags = {1, num_entries};
    hcn_crn_flags = {1, num_entries};
    wmo_ids = {1, num_entries};
  
    
    idx = 1;
    i = 1;
    while (i < num_bytes)
       
        % ID            1-11   Character
        ids{idx} = bytes(i:(i+10), 1)';
        i = i + 11 + 1;
        
        % LATITUDE     13-20   Real
        lats(idx) = str2double(bytes(i:(i+7), 1));
        i = i + 8 + 1;
        
        % LONGITUDE    22-30   Real
        longs(idx) = str2double(bytes(i:(i+8), 1));
        i = i + 9 + 1;
        
        % ELEVATION    32-37   Real
        els(idx) = str2double(bytes(i:(i+5), 1));
        i = i + 6 + 1;
        
        % STATE        39-40   Character
        states{idx} = bytes(i:(i+1), 1)';
        i = i + 2 + 1;

        % NAME         42-71   Character
        names{idx} = bytes(i:(i+29), 1)';
        i = i + 30 + 1;

        % GSN FLAG     73-75   Character
        gsn_flags{idx} = bytes(i:(i+2), 1)';
        i = i + 3 + 1;

        % HCN/CRN FLAG 77-79   Character
        hcn_crn_flags{idx} = bytes(i:(i+2), 1)';
        i = i + 3 + 1;

        % WMO ID       81-85   Character
        wmo_ids{idx} = bytes(i:(i+4), 1)';
        i = i + 5 + 1;

        idx = idx + 1;
    end
    
    
    stations.ids = ids;
    stations.lats = lats;
    stations.longs = longs;
    stations.els = els;
    stations.states = states;
    stations.names = names;
    stations.gsn_flags = gsn_flags;
    stations.hcn_crn_flags = hcn_crn_flags;
    stations.wmo_ids = wmo_ids;
    
end
