%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Reproducible file accompanying the paper
% OPTIMAL ALGORITHMS FOR COMPUTING AVERAGE TEMPERATURES
% by R. DeVore, S. Foucart, M. Hielsberg, G. Mullendore, G. Petrova, P. Wojtaszczyk
% Written by M. Hielsberg in February 2018
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [state_stations] = load_state_stations_daily_TAVG(state)

    addpath('GHCND')

    % this function considers the winter and summer seasons, DJF and JJA
    % respectively.  However, it does so using 13 seven day periods (weeks
    % that do not necessarily corresponds to the typical Sun, Mon, etc),
    % which start on the first day of the first month in the season and end
    % 91 days later.
    numWeeks = 13;
    numDaysInWeek = 7;

    %state = 'TX';
    path = 'GHCND/';

    % load daily inventory
    inv_file = [path, 'ghcnd-stations.txt'];
    ghcnd_inv = load_stations(inv_file);


    % find stations in the state in which we are intereseted
    state_idx = find(strcmp(state, ghcnd_inv.states));

    state_inv.ids = ghcnd_inv.ids(state_idx);
    state_inv.lats = ghcnd_inv.lats(state_idx);
    state_inv.longs = ghcnd_inv.longs(state_idx);
    state_inv.els = ghcnd_inv.els(state_idx);
    state_inv.states = ghcnd_inv.states(state_idx);
    state_inv.names = ghcnd_inv.names(state_idx);
    state_inv.gsn_flags = ghcnd_inv.gsn_flags(state_idx);
    state_inv.hcn_crn_flags = ghcnd_inv.hcn_crn_flags(state_idx);
    state_inv.wmo_ids = ghcnd_inv.wmo_ids(state_idx);


    good_idx = true(1, length(state_inv.ids));
    dailies = {};
    
    idx = 1;
    % load station daily files for those stations in the state
    for id=state_inv.ids

        disp(['Loading: ', id{1}, ' (', num2str(idx), ' out of ', num2str(length(state_inv.ids)), ')']);
        
        station_file = [path, 'ghcnd_all/ghcnd_all/', id{1}, '.dly'];
        station_daily = load_daily(station_file);

        % find only the daily average temperature
        tavg_idx = ismember(station_daily.elements, 'TAVG');

        % make sure TAVG is available 
        if sum(tavg_idx) == 0
            good_idx(idx) = false;
            idx = idx + 1;
            continue;
        end
        idx = idx + 1;

        station_daily.ids = station_daily.ids(tavg_idx);
        station_daily.years = station_daily.years(tavg_idx);
        station_daily.months = station_daily.months(tavg_idx);
        station_daily.elements = station_daily.elements(tavg_idx);
        station_daily.values = station_daily.values(:,tavg_idx);
        station_daily.mflags = station_daily.mflags(:,tavg_idx);
        station_daily.qflags = station_daily.qflags(:,tavg_idx);
        station_daily.sflags = station_daily.sflags(:,tavg_idx);

        % average the temperatures for the winter and summer seasons
        station_daily.summer_years = unique(station_daily.years);
        station_daily.winter_years = station_daily.summer_years;
        station_daily.summer_values = -9999 * ones(numWeeks, length(station_daily.summer_years));
        station_daily.winter_values = -9999 * ones(numWeeks, length(station_daily.summer_years));

        y_idx = 1;
        for year=station_daily.summer_years
            m_idx = station_daily.years == year;

            month_str = num2str(station_daily.months(m_idx));
            % replace 2 digit values with 1 digit values so season_idx can be
            % used directly
            month_str = strrep(month_str, '10', 'A');
            month_str = strrep(month_str, '11', 'B');
            month_str = strrep(month_str, '12', 'C');
            month_str = month_str(~isspace(month_str));
            season_idx = strfind(month_str, '678');

            if length(season_idx) == 1
                % found season at [season_idx, season_idx+1, season_idx+2]
                values = station_daily.values(:, m_idx);

                season_values = reshape(values(:, season_idx:(season_idx+2)), [], 1);
                weekly_values = reshape(season_values(1:(numDaysInWeek*numWeeks)), numDaysInWeek, numWeeks);
                for wk=1:numWeeks
                    week = weekly_values(:,wk);
                    week(week == -9999) = []; % partial weeks are allowed
                    if ~isempty(week)
                        station_daily.summer_values(wk, y_idx) = mean(week) / 10.0; % convert to celcius
                    end
                end
            else
                % either season does not exist or it appears more than once
                % skip
            end

            y_idx = y_idx + 1;

        end

        y_idx = 1;
        for year=station_daily.winter_years(2:end)
            m_idx = station_daily.years == (year-1);
            m_idx = logical(m_idx + (station_daily.years == year));

            month_str = num2str(station_daily.months(m_idx));
            % replace 2 digit values with 1 digit values so season_idx can be
            % used directly
            month_str = strrep(month_str, '10', 'A');
            month_str = strrep(month_str, '11', 'B');
            month_str = strrep(month_str, '12', 'C');
            month_str = month_str(~isspace(month_str));
            season_idx = strfind(month_str, 'C12');

            if length(season_idx) == 1
                % found season at [season_idx, season_idx+1, season_idx+2]
                values = station_daily.values(:, m_idx);

                season_values = reshape(values(:, season_idx:(season_idx+2)), [], 1);
                weekly_values = reshape(season_values(1:(numDaysInWeek*numWeeks)), numDaysInWeek, numWeeks);
                for wk=1:numWeeks
                    week = weekly_values(:,wk);
                    week(week == -9999) = []; % partial weeks are allowed
                    if ~isempty(week)
                        station_daily.winter_values(wk, y_idx) = mean(week) / 10.0; % convert to celcius
                    end
                end
            else
                % either season does not exist or it appears more than once
                % skip
            end

            y_idx = y_idx + 1;

        end
        dailies = [dailies, station_daily];
    end

    state_inv.ids = state_inv.ids(good_idx);
    state_inv.lats = state_inv.lats(good_idx);
    state_inv.longs = state_inv.longs(good_idx);
    state_inv.els = state_inv.els(good_idx);
    state_inv.states = state_inv.states(good_idx);
    state_inv.names = state_inv.names(good_idx);
    state_inv.gsn_flags = state_inv.gsn_flags(good_idx);
    state_inv.hcn_crn_flags = state_inv.hcn_crn_flags(good_idx);
    state_inv.wmo_ids = state_inv.wmo_ids(good_idx);

    % return loaded data
    state_stations.inventory = state_inv;
    state_stations.dailies = dailies;


end

