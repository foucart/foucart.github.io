%%
% devore_matrix.m
% Returns a 0/1 matrix with low coherence
%
% Constructs the matrix found in the article
% "Deterministic constructions of compressed sensing matrices"
% by R. Devore.
%
% Usage: T = devore_matrix(p,d)
%
% p: a prime number
% d: an integer smaller than or equal to p
%
% T: a (p^2)X(p^d) matrix with 0/1 entries 

% Written Simon Foucart in May 2019
% Send comments to simon.foucart@centraliens.net

function T = devore_matrix(p,d)

if ~isprime(p)
    disp('error: the first argument must be a prime number')
    return
else
    T = zeros(p^2,p^d);
    M = value_matrix(p,d);
    for j=0:p-1
       T(j*p+1:(j+1)*p,:) = (M==j); 
    end
    
end

end