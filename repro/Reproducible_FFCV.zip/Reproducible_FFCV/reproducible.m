%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Reproducible file accompanying the paper
% SAMPLING SCHEMES AND RECOVERY ALGORITHMS
% FOR FUNCTIONS OF FEW COORDINATE VARIABLES
% by S. Foucart
% Written by S. Foucart in May 2019
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Monotonocity assumption -- adaptive case
% Example of an incrasing function of few coordinate variables
n = 10; 
N = 2^n;                             % number of coordinate variables
s = 5;                               % number of active variables 
S_aux = randperm(N); 
S = sort(S_aux(1:s))';               % set of active variables
powers = randi(4,[s,1]);
F = @(x) sum(sin(pi*x(S)/2).^powers);

%% The splitting strategy
S_rec = [];
while F(ones(N,1)) > F(zeros(N,1))
    F0 = F(zeros(N,1));
    length_R = N; R_min = 1; R_max = N;
    for round=1:n
        length_R = length_R/2;
        R_left = R_min:R_min+length_R-1;
        x_left = zeros(N,1); x_left(R_left) = ones(length_R,1);
        test_left = (F(x_left) > F0);
        R_right = R_min+length_R:R_max;
        x_right = zeros(N,1); x_right(R_right) = ones(length_R,1);
        test_right = (F(x_right) > F0);
        if test_left
            R_min = min(R_left);
            R_max = max(R_left);
        else
            R_min = min(R_right);
            R_max = max(R_right);
        end
    end
    act_var = R_min;
    S_rec = [S_rec; act_var];
    F = @(x) F(x-x(act_var)*((1:N)==act_var)');
end
% verify that the original set S of active variables
% and the recovered set S_rec of variables are the same
[S S_rec]


%% Monotonocity assumption -- nonadaptive case
% CVX is needed to solve the feasibility problem below
% Example of an increasing function of few variables
p = 13;
d = 4;
N = p^d;                             % number of coordinate variables
s = ceil(p/(d-1)) - 1;               % number of active variables 
S_aux = randperm(N); 
S = sort(S_aux(1:s))';               % set of active variables
powers = randi(4,[s,1]);
F = @(x) sum(sin(pi*x(S)/2).^powers);

%% Produce the test matrix and verify that its coherence is <=(d-1)/p
T = devore_matrix(p,d);
[max(max(T'*T-p*eye(p^d)))/p (d-1)/p]

%% Produce the test vector
m = size(T,1);
y = zeros(m,1);
F0 = F(zeros(N,1));
for i=1:m
    R_i = find( T(i,:) == 1);
    x_i = zeros(N,1); x_i(R_i) = ones(length(R_i),1);
    y(i) = ( F(x_i) > F0 );
end

%% state and solve the linear feasibility problem
I0 = find(y==0);
I1 = find(y==1);
cvx_quiet true
cvx_solver gurobi
cvx_begin
variable x(N)
minimize 1
subject to
x >= 0;
T(I0,:)*x == 0;
T(I1,:)*x >= 1;
cvx_end
S_rec = find(x>0);  % WARNING: if gurobi is not the selected, change to
% S_rec = find(x>1e-3);
% verify that the original set S of active variables
% and the recovered set S_rec of variables are the same
[S S_rec]

%%
