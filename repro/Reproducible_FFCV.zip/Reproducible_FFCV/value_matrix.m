%%
% value_matrix.m
% Returns an integer-valued matrix 
%
% Constructs the matrix with columns indexed by polynomials of degree < d,
% each column containing the values mod p of a polynomial at 0,1,...,p-1 
%
% Usage: M = value_matrix(p,d)
%
% p: an integer
% d: an integer smaller than or equal to p
%
% M: a pX(p^d) matrix with entries in {0,1,...,p-1} 

% Written Simon Foucart in May 2019
% Send comments to simon.foucart@centraliens.net

function M = value_matrix(p,d)

M_1 = zeros(p,p);
for c=0:p-1
    M_1(:,c+1) = c*ones(p,1); 
end

if d==1
    M = M_1;
else
    M_aux = value_matrix(p,d-1);
    pp = size(M_aux,2);                    % which is p^(d-1)
    for c=0:p-1
        M(:,c*pp+1:(c+1)*pp) = mod( c+diag(0:p-1)*M_aux , p);
    end
end
    
end