%L1SQREG L1-squared regularization
% l1sqreg(y,A,lambda) finds the solution of
% minimize ||z||_1^2 + lambda*||Az-y||_2^2
% Usage: [x,NormRes] = l1sqreg(y,A,lambda)
% y: column vector, A: matrix, lambda: (large) positive number
% x: column vector (solution  of the regularization), NormRes: norm of the residual
% created by S. Foucart in Dec 2016

function [x,NormRes] = l1sqreg(y,A,lambda)

[~,N] = size(A);
A_aux = [ones(1,2*N); sqrt(lambda)*A -sqrt(lambda)*A];
y_aux = [0;sqrt(lambda)*y];
v = lsqnonneg(Aaux,yaux);
x = v(1:N)-v(N+1:2*N);
NormRes = norm(y-A*x);

end