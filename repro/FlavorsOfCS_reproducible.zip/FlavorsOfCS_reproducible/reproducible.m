%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Reproducible file accompanying the paper
% FLAVORS OF COMPRESSIVE SENSING, by S. Foucart
% Proceedings of the 15th International Conference on Approximation Theory
%
% Written by S. Foucart in December 2016
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Prony-inspired recovery map (Section 1): 
% 2s Fourier measurements suffice for s-sparse recovery in the idealized case
clear all; clc;

% creation of the vector x to be recovered
N = 500; s = 18;                      % size and sparsity of x
x = zeros(N,1); 
supp = sort(randperm(N,s));           % support of x 
x(supp) = randn(s,1);                 % entries of x on its support

% creation of the 2s Fourier measurements
xhat = fft(x); 
y = xhat(1:2*s);                      % the measurement vector y

% the core of the recovery procedure
p_hat = zeros(N,1);                   % vector to hold the Fourier transform of p
p_hat(1) = 1;                         % the constant term in p is one
M = toeplitz(y(s:2*s-1),y(s:-1:1));   % matrix of the Toeplitz system
p_hat(2:s+1) = -M\y(s+1:2*s);         % solve the system for the unknown entries of p_hat
p = ifft(p_hat);                      % deduce p from p_hat
[~,ind] = sort(abs(p)); 
supp_recovered = sort(ind(1:s));      % get the recovered support 

% on-screen comparison of the original and recovered supports 
st = sprintf([repmat('%d ',1,s) '\n' repmat('%d ',1,s)], [supp supp_recovered']);
sprintf(strcat('Prony-inspired recovery map - idealized case:', '\n',...
    'notice that the original and recovered supports coincide', '\n', st))

%% Prony-inspired recovery map (Section 1):
% non-robustness to measurement error

% perturb the measurement vector
eps = 1e-4;                           % noise level
y_pert = y + eps*randn(2*s,1);

% run the same recovery procedure with the perturbed measurements
p_hat = zeros(N,1);                   
p_hat(1) = 1;                         
M = toeplitz(y_pert(s:2*s-1),y_pert(s:-1:1));   
p_hat(2:s+1) = -M\y_pert(s+1:2*s);         
p = ifft(p_hat);                      
[~,ind] = sort(abs(p)); 
supp_pert = sort(ind(1:s));       

% on-screen comparison of the original and recovered supports 
st = sprintf([repmat('%d ',1,s) '\n' repmat('%d ',1,s)], [supp supp_pert']);
sprintf(strcat('Prony-inspired recovery map - presence of measurement error:', '\n',...
    'notice that the original and recovered supports DO NOT coincide', '\n', st))

%%
%% Orthogonal matching pursuit (Section 4):
% comparing how many OMP iterations are required for different vector 'shapes' 

clear all; clc;
randn('state',5)

% parameters of the problem
N = 1000;                             % size of x
s_min = 18; s_max = 48;               % range of sparsities
s_step = 3;                           % step-size for the sparsity
m = 300;                              % number of measurements
NbTests = 200;                        % number of random trials

% arrays containing the number of iterations performed
NbIters_flat = zeros(NbTests,s_max);
NbIters_pflat = zeros(NbTests,s_max);
NbIters_lin = zeros(NbTests,s_max);
NbIters_quad = zeros(NbTests,s_max);
NbIters_gauss = zeros(NbTests,s_max);

for s = s_min:s_step:s_max;
    for t=1:NbTests
        A = randn(m,N)/sqrt(m);       % Gaussian measurement matrix
% 'flat' sparse vectors
        x_flat = zeros(N,1);
        x_flat(1:s) = ones(s,1);
        x_flat = x_flat/norm(x_flat);
        y_flat = A*x_flat; 
        n = 0; S = []; x = zeros(N,1);
        while ~isempty(setdiff(1:s,S))
            [~,j] = max(abs(A'*(y_flat-A*x)));
            S = sort([S j]);
            x(S) = A(:,S)\y_flat;
            n = n+1;
        end
        NbIters_flat(t,s) = n;
% 'piecewise flat' sparse vectors
        x_pflat= zeros(N,1);
        x_pflat(1:s) = ones(s,1) + mod(1:s,2)';
        x_pflat = x_pflat/norm(x_pflat);
        y_pflat = A*x_pflat;
        n = 0; S = []; x = zeros(N,1);
        while ~isempty(setdiff(1:s,S))
            [~,j] = max(abs(A'*(y_pflat-A*x)));
            S = sort([S j]);
            x(S) = A(:,S)\y_pflat;
            n = n+1;
        end
        NbIters_pflat(t,s) = n;
% 'linear' sparse vectors
        x_lin = zeros(N,1);
        x_lin(1:s) = 1:s;
        x_lin = x_lin/norm(x_lin);
        y_lin = A*x_lin;
        n = 0; S = []; x = zeros(N,1);
        while ~isempty(setdiff(1:s,S))
            [~,j] = max(abs(A'*(y_lin-A*x)));
            S = sort([S j]);
            x(S) = A(:,S)\y_lin;
            n = n+1;
        end
        NbIters_lin(t,s) = n;
% 'quadratic' sparse vectors
        x_quad = zeros(N,1);
        x_quad(1:s) = (1:s).^2;
        x_quad = x_quad/norm(x_quad);
        y_quad = A*x_quad;
        n = 0; S = []; x = zeros(N,1);
        while ~isempty(setdiff(1:s,S))
            [~,j] = max(abs(A'*(y_quad-A*x)));
            S = sort([S j]);
            x(S) = A(:,S)\y_quad;
            n = n+1;
        end
        NbIters_quad(t,s) = n;
 % 'Gaussian' sparse vectors
        x_gauss = zeros(N,1);
        x_gauss(1:s) = randn(s,1);
        x_gauss = x_gauss/norm(x_gauss);
        y_gauss = A*x_gauss;
        n = 0; S = []; x = zeros(N,1);
        while ~isempty(setdiff(1:s,S))
            [~,j] = max(abs(A'*(y_gauss-A*x)));
            S = sort([S j]);
            x(S) = A(:,S)\y_gauss;
            n = n+1;
        end
        NbIters_gauss(t,s) = n;
    end
end

% visualization of the results (production of Figure 1)
figure(1);
plot(s_min:s_step:s_max,max(NbIters_flat(:,s_min:s_step:s_max)),'-r+',...
    s_min:s_step:s_max,max(NbIters_pflat(:,s_min:s_step:s_max)),'-go',...
    s_min:s_step:s_max,max(NbIters_lin(:,s_min:s_step:s_max)),'-b*',...
    s_min:s_step:s_max,max(NbIters_gauss(:,s_min:s_step:s_max)),'-kd',...
    s_min:s_step:s_max,max(NbIters_quad(:,s_min:s_step:s_max)),'-ms')
legend('flat','pieceswise flat','linear','Gaussian','quadratic','Location','northwest')
xlabel('Sparsity level s')
ylabel('Number of iterations')
title('N=1000, m=300')
pbaspect([8 5 1])

%%
%% L1-squared regularization (Subsection 5.3)
% Sparse recovery using only MATLAB functions

clear all; clc;

% creation of the vector x to be recovered
N = 1000; s = 50;                     % size and sparsity of x
x = zeros(N,1); 
supp = sort(randperm(N,s));           % support of x 
x(supp) = randn(s,1);                 % entries of x on its support

% creation of the measurement matrix and the measurement vector
m = 300;                              % number of measurements
A = randn(m,N)/sqrt(m);               % Gaussian matrix
eps = 1e-4;                           % noise level
y = A*x + eps*randn(m,1);             % measurement vector

% L1-squared regularization via nonnegative least squares (NNLS)
lambda = 1e6;                         % regularization parameter
A_aux = [ones(1,2*N); ...
    sqrt(lambda)*A -sqrt(lambda)*A];  % auxiliary matrix 
y_aux = [0;sqrt(lambda)*y];           % auxiliary measurement vector
v = lsqnonneg(A_aux,y_aux);           % NNLS solution
x_recovered = v(1:N)-v(N+1:2*N);      % solution of the regularized problem

% on-screen dispaly of the relative recovery error
sprintf('The relative recovery error is %d ', norm(x-x_recovered)/norm(x))

%%