%SUPPCOL Column support
% SUPPCOL(M) returns the column support of M
% Usage: S = suppcol(M,eps,p)
% M: a matrix, eps: a small positive number, p: a positive number
% S: the set of column indices where ||col_j(M)||_p>eps, arranged in a row vector
% SF (created 25/05/2012, modified 25/05/2012)
function S = suppcol(M,eps,p)
if nargin < 3
   p=inf;
end
if nargin < 2
   eps = 1e-5; 
end
n=size(M,2);
x=zeros(1,n);
for j=1:n
   x(j)=norm(M(:,j),p); 
end
S = find(abs(x)>eps);
end