%BINOMIAL Binomial coefficient
% BINOMIAL(n,k) returns the binomial coefficient of n and k when n>=k>=0, and zeros otherwise
% Usage: nck = binomial(n,k)
% n: integer, k: integer
% nck: the integer equal to the binomial coefficient of n and k
% SF (created 25/05/2012, modified 25/05/2012)
function nck = binomial(n,k)
if ( n < k || k < 0)
    nck = 0;
else 
    nck = nchoosek(n,k);
end
end