%L1REGNONNEG Nonnegative L1-regularisation
% l1regnonneg(y,A,lambda) finds the solution of min
% ||z||_1^2+lambda^2*||Az-y||_2^2 subject to z >= 0
% Usage: [x,NormRes] = l1regnonneg(y,A,lambda)
% y: column vector, A: matrix, lambda: (large) positive number
% x: column vector (solution  of the regularization), NormRes: norm of the residual
% SF (created 30/05/2012, modified 30/05/2012)

function [x,NormRes] = l1regnonneg(y,A,lambda)

[~,N]=size(A);
Aaux=[ones(1,N); lambda*A];
yaux=[0; lambda*y];
[x,NormRes]=lsqnonneg(Aaux,yaux);

end