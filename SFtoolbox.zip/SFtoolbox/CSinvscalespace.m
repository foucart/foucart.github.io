%CSINVSCALESPACE Adaptive inverse scale space for compressive sensing
%CSinvscalespace(A, f) finds the solution to
%minimize ||z||_1 subject to A*z=f
%sent by Micheal Moeller on 10 Jan 2012

function [u, p,i] = CSinvscalespace(A, f, varargin)

%%%%% set variables  %%%%%
[iter, ploton,noisethresh] = setvariables(varargin);
m=size(A,2);
Atansf = A'*f;
numerr=10^(-6);
% first time step
t1 = 1./max(abs(Atansf));
% first subgradient
p = t1*Atansf;
%index set
I = (abs(p)>1-numerr);  
i=1;
stopcrit=0;

while (i<=iter) && (~stopcrit)
    
    %%% solve the least squares problem only with the components in I %%%
    B = full(A(:,logical(I))); 
    
	%%% new non-negative least squares %%%
    temp=sign(p(I)');
    B = B.*repmat(temp, [size(B,1), 1]); %change signs of the columns of B
    utemp = nonneglsq(B, f); %compute non-negative least squares
   % utemp = lsqnonneg(B, f);
    utemp = utemp.*temp';  % redo the change of sign
    
    %%% save result in u %%%
    u = zeros(m,1);
    u(I) = utemp;
    
    %%%%%% determine the next time step t where the value of the %
    % subgradient is 1 next time                                 %
    %determine slope
    Au= A*u;
    s = (Atansf - A'*(Au)); 
    
    %omit slopes that are essintially 0
    zeroslope = (abs(s)<10^(-10));
    stemp = s(logical(1-zeroslope));
    ptemp = p(logical(1-zeroslope)); 
    
    %determine y-intersection
    c = ptemp - t1*stemp; 
    % ttemp1 are the times where the linear equations reach 1
    ttemp1 = (1-c)./stemp;
    %discard times which are smaller than t^k
    ttemp1((ttemp1<t1+numerr))=[];
    % ttemp2 are the times where the linear equations reach -1
    ttemp2 = (-1-c)./stemp;
    %discard times which are smaller than t^k
    ttemp2((ttemp2<t1+numerr))=[];
    
    % stop if there are no more time steps, otherwise get next step %
    if isempty(ttemp1) && isempty(ttemp2)
        stopcrit = 1;
    else
        %find the minimum time among all possible times
        t2 = min([min(ttemp1), min(ttemp2)]); 

        %update subgradient
        p = p + (t2-t1)*s;
        
        %update index set
        I = (abs(p)>1-numerr);
        t1=t2;
    end
    
    %plot intermediate result and pause
    if (ploton==1)
        subplot(2, 1, 1), plot(p, 'LineWidth',2), title(['Subgradient at iteration ', num2str(i)]);
        subplot(2, 1, 2), plot(u, 'LineWidth',2), title(['Solution at iteration ', num2str(i)]); pause;
    end
    
    energ = sum((Au-f).^2);
     if (energ)<noisethresh  %(A*u-f)
         stopcrit=1;
     end
    i=i+1;
end
i=i-1;
if i==iter;
    disp(['The algorithm was stopped after ', num2str(iter),' iterations and might not have fully converged.']);
end
