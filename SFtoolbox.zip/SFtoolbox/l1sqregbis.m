%L1SQREGBIS L1-squared regularization
% l1sqregbis(y,A,lambda) finds (?) the solution of
% minimize ||z||_1^2+lambda^2*||Az-y||_2^2
% Usage: [x,NormRes] = l1sqregbis(y,A,lambda)
% y: column vector, A: matrix, lambda: (large) positive number
% x: column vector (solution  of the regularization), NormRes: norm of the residual
% SF (created 3 Aug 2012, modified 3 Aug 2012)
% the differnce with l1sqreg is that nonneglsq (due to Moeller) is used
% here rather than lsqnonneg (from MATLAB)

function [x,NormRes] = l1sqregbis(y,A,lambda)

[~,N]=size(A);
Aaux=[ones(1,2*N);lambda*A -lambda*A];
yaux=[0;lambda*y];
v=nonneglsq(Aaux,yaux);
x=v(1:N)-v(N+1:2*N);
NormRes=norm(y-A*x);

end