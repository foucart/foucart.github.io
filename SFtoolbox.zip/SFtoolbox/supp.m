%SUPP Support
% SUPP(x) returns the support of x
% Usage: S = supp(x)
% x: a row or column vector, eps: a small positive number
% S: the set of indices where |x_i|>eps, arranged in a row vector if x is a
% row vector, in a column column vector if x is a column vector
% SF (created 25/05/2012, modified 25/05/2012)
function S = supp(x,eps)
if nargin < 2
   eps = 1e-5; 
end
S = find(abs(x)>eps);
end