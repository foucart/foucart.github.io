%NORM0ROW Row L0-norm
% NORM0ROW(M) returns the row L0-norm of M
% Usage: s = norm0row(M,eps,p)
% M: a matrix, eps: a small positive number, p: a positive number
% S: the number of row indices where ||row_i(M)||_p>eps
% SF (created 25/05/2012, modified 25/05/2012)
function s = norm0row(M,eps,p)
if nargin < 3
   p=inf;
end
if nargin < 2
   eps = 1e-5; 
end
m=size(M,1);
x=zeros(m,1);
for i=1:m
   x(i)=norm(M(i,:),p); 
end
s = size(find(abs(x)>eps),1);
end