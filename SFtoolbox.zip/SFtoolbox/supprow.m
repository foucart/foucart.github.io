%SUPPROW Row support
% SUPPROW(M) returns the row support of M
% Usage: S = supprow(M,eps,p)
% M: a matrix, eps: a small positive number, p: a positive number
% S: the set of row indices where ||row_i(M)||_p>eps, arranged in a column vector
% SF (created 25/05/2012, modified 25/05/2012)
function S = supprow(M,eps,p)
if nargin < 3
   p=inf;
end
if nargin < 2
   eps = 1e-5; 
end
m=size(M,1);
x=zeros(m,1);
for i=1:m
   x(i)=norm(M(i,:),p); 
end
S = find(abs(x)>eps);
end