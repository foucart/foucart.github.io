%Auxiliary script for Adaptive Inverse Scale Space
function [iter, ploton,noisethresh] = setvariables(varargin)


%%%%%% Default variables %%%%%
iter = 5000; %maximum number of iterations
ploton = 0; %default is not to plot the intermediate results
noisethresh=10^(-12); %if ||(f-Au)||^2 is below this threshold the algorithm stopps
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%% Check if user changed default variables %%%%% 
skip=0;
test = varargin{:};
for i=1:length(test) 
    if (skip>0)
        skip = skip-1;
        continue;
    end
    switch char(test(i))
        case 'iter'
            iter = cell2mat(test(i + 1));
            skip = 1;
        case 'noise'
            noisethresh=cell2mat(test(i + 1));
            skip = 1;    
        case 'ploton'
            ploton = cell2mat(test(i + 1));
            skip = 1;
        otherwise
            error('Unknown parameter %s', char(test(i)));
    end
end