%L2REG L2 regularisation
% l2reg(y,A,lambda) finds the solution of 
% min ||z||_2^2+lambda^2*||Az-y||_2^2
% Usage: [x,NormRes] = l2reg(y,A,lambda)
% y: column vector, A: matrix, lambda: (large) positive number
% x: column vector (solution  of the regularization), NormRes: norm of the residual
% SF (created 30/05/2012, modified 30/05/2012)

function [x,NormRes] = l2reg(y,A,lambda)

[~,N]=size(A);
Aaux=[eye(N); lambda*A];
yaux=[zeros(N,1); lambda*y];
x=Aaux\yaux;
NormRes=norm(y-A*x);

end