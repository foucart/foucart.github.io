%IHT Iterartive Hard Thresholding
% IHT(y,A,s) runs the Iterative Hard Thresholding started with x0=0
% Usage: [x,S,NormRes,NbIter] = iht(y,A,s,x0,MaxNbIter,TolRes)
% y: column vector, A: matrix, s: integer, x0: initial vector (optional, default=0), 
% MaxNbIter: number of iterations not to be exceeded (optional, default=1000), TolRes:
% threshold value for the L2-norm of the residual under which the alsogithm
% is stopped (optional, default=1e-4)
% x: column vector, S: support of x, NormRes: the norm of the residual,
% NbIter: the number of performed iterations
% SF (created 27/05/2012, modified 27/05/2012)
% NOTE: the matrix A is column-normalized before IHT is run
function [x,S,NormRes,NbIter] = iht(y,A,s,x0,MaxNbIter,TolRes)

[~,N]=size(A);
if nargin < 6
   TolRes=1e-4; 
end
if nargin < 5
   MaxNbIter=1000;
end
if nargin < 4
   x0=zeros(N,1); 
end

[A,d]=nzedcol(A);
x = x0;
res = y-A*x;
NormRes = norm(res);
NbIter=0;

while ( NbIter < MaxNbIter && NormRes > TolRes )
    u = x+A'*res;
    [~,sorted_idx] = sort(abs(u),'descend');
    S = sorted_idx(1:s);
    x=zeros(N,1); x(S)=u(S);
    res = y-A*x;
    NormRes=norm(res);
    NbIter = NbIter+1;
end

x=diag(1./d)*x;

end