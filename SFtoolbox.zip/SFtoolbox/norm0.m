%NORM0 L0-norm
% NORM0(x) returns the L0-norm of x
% Usage: s = norm0(x,eps)
% x: a row or column vector, eps: a small positive number
% s: the number of indices where |x_i|>eps
% SF (created 25/05/2012, modified 25/05/2012)
function s = norm0(x,eps)
if nargin < 2
   eps = 1e-5; 
end
if size(x,1) > 1
    s = size(find(abs(x)>eps),1);
else
    s = size(find(abs(x)>eps),2);
end
end