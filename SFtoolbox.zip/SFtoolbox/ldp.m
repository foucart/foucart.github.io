%LDP Least distance programming
% ldp(A,y) finds the solution of 
% min ||z||_2 subject to Az >= y
% Usage: [x,Normx] = ldp(A,y)
% A: matrix, y: column vector
% x: column vector (minimizer), Normx: euclidean norm of x
% SF (created 3 Aug 2012, modified 3 Aug 2012)
% the method is the one from p.165 of
% Lawson and Hanson, "Solving Least Squares Problems", Prentice-Hall, 1974
% it uses the MATLAB function lsqnonneg

function [x,Normx] = ldp(A,y)

[~,n]=size(A);
E=[A y]'; f=[zeros(n,1);1];
[~,~,r]=lsqnonneg(E,f);
rlast=r(n+1);
if rlast==0
    disp('Warning: the problem is unfeasible')
else 
    x=-r(1:n)/rlast;
    Normx=norm(x);
end

end