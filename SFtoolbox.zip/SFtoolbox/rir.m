%RIR Restricted isometry ratio
% RIR(A,s) returns the s-th order restricted isometry ratio of the matrix A
% Usage: gamma = rir(A,s)
% A: matrix, s: integer
% gamma: nonnegative number, defined the ratio beta/alpha, where alpha and
% beta are the best constants such that, for any s-sparse vector x: 
% alpha |x|^2 <= |A x|^2 <= beta |x|^2 
% SF (created 25/07/2012, modified 25/07/2012)

function [gamma,alpha,beta] = rir(A,s)
N = size(A,2);
Subsets = nchoosek(1:N,s);
a = Inf; b = 0;
for k = 1:size(Subsets,1)
    S = Subsets(k,:); AS = A(:,S); 
    SingVals = svd(AS);
    a = min(a,min(SingVals));
    b = max(b,max(SingVals));
end
alpha = a^2; beta = b^2;
gamma = beta/alpha;
end