%NZEDCOL Column normalization
% NZEDCOL(A) returns the matrix whose columns are the columns of A
% normalized to have norm one
% Usage: B = nzedcol(A)
% A: matrix, p: positive number or inf (optional, default: p=2)
% B: the matrix obtained from A by column normalization, d: the row
% vector with entries equal to the norms of the columns of A
% SF (created 25/05/2012, modified 25/05/2012)
function [B,d] = nzedcol(A,p)
if nargin < 2
   p = 2; 
end
N = size(A,2);
d = zeros(1,N);
for j=1:N
    d(j) = norm(A(:,j),p);
end
B = A*diag(1./d);
end