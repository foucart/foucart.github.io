%Similar to MATLAB lsqnonneg
%part of adaptive inverse scale space
%sent by Micheal Moeller on 10 Jan 2012
function u = nonneglsq(A,f)
n=size(A,2);
u = A\f;
numerr=100*eps*norm(A,1)*length(A);
test = any(u<-numerr);
stopcrit=0;
u(u<0)=0;
if test 
    indset = logical(u<numerr);
    while ~stopcrit
        %compute temporary solution
        utemp = zeros(n,1);
        utemp(~indset) = A(:,~indset)\f;
        while any(utemp(~indset)<=numerr)
            indsettemp = (utemp<=numerr) & ~indset;
            t = min(u(indsettemp)./(u(indsettemp)-utemp(indsettemp)));
            u = u + t*(utemp-u);
            indset = (u<=numerr)&(~indset) | indset;
            utemp = zeros(n,1);
            utemp(~indset)=A(:,~indset)\f;
        end
        u = utemp;
        u(u<0)=0;
       resid = (f-A*u);
       mingradenerg = A'*resid;
       [~, ind] = max(mingradenerg.*indset);
       indset(ind)=false;
       if (max((mingradenerg(~indset)))<numerr)
           stopcrit=1;
       end
    end
end
