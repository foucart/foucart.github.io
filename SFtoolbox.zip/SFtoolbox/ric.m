%RIC Restricted isometry constant
% RIC(A,s) returns the s-th order restricted isometry constant of the matrix A
% Usage: delta = ric(A,s)
% A: matrix, s: integer
% delta: nonnegative number, defined as max_S ||A_S^*A_S-I||_2
% SF (created 25/07/2012, modified 25/07/2012)
function delta = ric(A,s)
N = size(A,2);
Subsets = nchoosek(1:N,s);
delta = 0;
for k = 1:size(Subsets,1)
    S = Subsets(k,:); AS = A(:,S);
    delta = max(delta,norm(AS'*AS-eye(s)));
end
end