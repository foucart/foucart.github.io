%NORM0COL Column L0-norm
% NORM0COL(M) returns the column L0-norm of M
% Usage: s = norm0col(M,eps,p)
% M: a matrix, eps: a small positive number, p: a positive number
% S: the number of column indices where ||col_j(M)||_p>eps
% SF (created 25/05/2012, modified 25/05/2012)
function s = norm0col(M,eps,p)
if nargin < 3
   p=inf;
end
if nargin < 2
   eps = 1e-5; 
end
n=size(M,2);
x=zeros(1,n);
for j=1:n
   x(j)=norm(M(:,j),p); 
end
s = size(find(abs(x)>eps),2);
end