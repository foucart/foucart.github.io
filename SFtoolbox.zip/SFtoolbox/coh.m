%COH Coherence
% COH(A) returns the coherence of the matrix A
% Usage: mu = coh(A)
% A: matrix
% mu: number in [0,1], defined as max |<a_i,a_j>|/(||a_i|| ||a_j||)
% SF (created 25/05/2012, modified 25/05/2012)
function mu = coh(A)
B = nzedcol(A);
N = size(A,2);
mu = max(max(abs(B'*B-eye(N))));
end